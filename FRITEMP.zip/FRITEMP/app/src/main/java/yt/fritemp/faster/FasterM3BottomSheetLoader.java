package yt.fritemp.faster;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.progressindicator.CircularProgressIndicator;

public class FasterM3BottomSheetLoader {
    private final BottomSheetDialog bottomSheetDialog;
    private final TextView loadingMessage;
    private final CircularProgressIndicator progressIndicator;
    private OnOutsideClickListener onOutsideClickListener;
    private boolean isDialogDismissed = false;

    public interface OnOutsideClickListener {
        void onOutsideClick();
    }

    public FasterM3BottomSheetLoader(@NonNull Activity activity) {
        bottomSheetDialog = new BottomSheetDialog(activity, com.google.android.material.R.style.ThemeOverlay_Material3_BottomSheetDialog);
        View view = LayoutInflater.from(activity).inflate(R.layout.loading_bottom_sheet, null);
        bottomSheetDialog.setContentView(view);

        loadingMessage = view.findViewById(R.id.loading_text);
        progressIndicator = view.findViewById(R.id.progress_indicator);

        progressIndicator.setIndicatorColor(
                ContextCompat.getColor(activity, R.color.color1),
                ContextCompat.getColor(activity, R.color.color2),
                ContextCompat.getColor(activity, R.color.color3)
        );

        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.setCanceledOnTouchOutside(true);

        bottomSheetDialog.setOnDismissListener(dialog -> {
            if (!isDialogDismissed && onOutsideClickListener != null) {
                onOutsideClickListener.onOutsideClick();
            }
        });
    }

    public void setOnOutsideClickListener(OnOutsideClickListener listener) {
        this.onOutsideClickListener = listener;
    }

    public void show(String message) {
        loadingMessage.setText(message);
        bottomSheetDialog.show();
        isDialogDismissed = false;
    }

    public void updateMessage(String newMessage) {
        loadingMessage.setText(newMessage);
    }

    public void resume() {
        if (!bottomSheetDialog.isShowing()) {
            bottomSheetDialog.show();
        }
    }

    public void dismiss() {
        isDialogDismissed = true;
        if (bottomSheetDialog.isShowing()) {
            bottomSheetDialog.dismiss();
        }
    }

    public void setCancelableOnOutsideClick(boolean cancelable) {
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setCanceledOnTouchOutside(cancelable);
    }
}
