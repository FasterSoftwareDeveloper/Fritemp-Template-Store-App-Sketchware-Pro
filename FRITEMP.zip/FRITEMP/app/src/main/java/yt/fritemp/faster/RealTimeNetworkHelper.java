package yt.fritemp.faster;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class RealTimeNetworkHelper {

    public enum ConnectionStatus {
        NO_NETWORK,
        CONNECTED_NO_INTERNET,
        CONNECTED_WITH_INTERNET
    }

    public interface OnStatusChangeListener {
        void onStatusChanged(ConnectionStatus status);
    }

    private final Context context;
    private final OnStatusChangeListener listener;
    private final ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    public RealTimeNetworkHelper(Context ctx, OnStatusChangeListener listener) {
        this.context = ctx.getApplicationContext();
        this.listener = listener;
        this.connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    public void register() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    checkNetworkStatus();
                }

                @Override
                public void onLost(Network network) {
                    checkNetworkStatus();
                }
            };

            NetworkRequest request = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();

            connectivityManager.registerNetworkCallback(request, networkCallback);
        }

        checkNetworkStatus();
    }

    public void unregister() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && networkCallback != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }
    }

    private void checkNetworkStatus() {
        new Thread(() -> {
            ConnectionStatus status;

            if (!isNetworkConnected()) {
                status = ConnectionStatus.NO_NETWORK;
            } else if (hasInternetAccess()) {
                status = ConnectionStatus.CONNECTED_WITH_INTERNET;
            } else {
                status = ConnectionStatus.CONNECTED_NO_INTERNET;
            }

            new android.os.Handler(context.getMainLooper()).post(() -> {
                listener.onStatusChanged(status);
            });
        }).start();
    }

    private boolean isNetworkConnected() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = connectivityManager.getActiveNetwork();
            if (network == null) return false;

            NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(network);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }
        return false;
    }

    private boolean hasInternetAccess() {
        try {
            HttpURLConnection connection = (HttpURLConnection) 
                    new URL("https://clients3.google.com/generate_204").openConnection();
            connection.setConnectTimeout(1500);
            connection.setReadTimeout(1500);
            connection.connect();
            return connection.getResponseCode() == 204;
        } catch (IOException e) {
            return false;
        }
    }
}
