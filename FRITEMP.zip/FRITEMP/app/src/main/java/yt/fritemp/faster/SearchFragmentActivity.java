package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.chip.*;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;


public class SearchFragmentActivity extends Fragment {
	
	private HashMap<String, Object> searchRqMap = new HashMap<>();
	private HashMap<String, Object> userMap = new HashMap<>();
	private HashMap<String, Object> userRqMap = new HashMap<>();
	private PeekAndPop peekAndPop;
	private double peekPosition = 0;
	private double peekPosition2 = 0;
	
	private ArrayList<HashMap<String, Object>> suggestionMp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> searchListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> userListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ListView listview2;
	private GridView gridview1;
	private ListView listview1;
	private TextInputLayout textinput_search;
	private EditText edittext_search;
	private LinearLayout linear37;
	private TextView textview1;
	private TextView textview2;
	private Chip linear_chip1;
	private Chip linear_chip2;
	
	private SharedPreferences save;
	private RequestNetwork searchRq;
	private RequestNetwork.RequestListener _searchRq_request_listener;
	private RequestNetwork userRq;
	private RequestNetwork.RequestListener _userRq_request_listener;
	private Intent viewIntent = new Intent();
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.search_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear1 = _view.findViewById(R.id.linear1);
		linear2 = _view.findViewById(R.id.linear2);
		linear3 = _view.findViewById(R.id.linear3);
		listview2 = _view.findViewById(R.id.listview2);
		gridview1 = _view.findViewById(R.id.gridview1);
		listview1 = _view.findViewById(R.id.listview1);
		textinput_search = _view.findViewById(R.id.textinput_search);
		edittext_search = _view.findViewById(R.id.edittext_search);
		linear37 = _view.findViewById(R.id.linear37);
		textview1 = _view.findViewById(R.id.textview1);
		textview2 = _view.findViewById(R.id.textview2);
		linear_chip1 = _view.findViewById(R.id.linear_chip1);
		linear_chip2 = _view.findViewById(R.id.linear_chip2);
		save = getContext().getSharedPreferences("save", Activity.MODE_PRIVATE);
		searchRq = new RequestNetwork((Activity) getContext());
		userRq = new RequestNetwork((Activity) getContext());
		
		edittext_search.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.equals("")) {
					listview1.setVisibility(View.VISIBLE);
					listview2.setVisibility(View.GONE);
					gridview1.setVisibility(View.GONE);
					_TransitionManager(linear1, 300);
				} else {
					if (linear_chip1.isChecked()) {
						searchRqMap = new HashMap<>(); 
						searchRqMap.put("apikey", getString(R.string.database_api_key));
						searchRq.setHeaders(searchRqMap);
						searchRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "title" + "=ilike.*" + _charSeq + "*" + "&" + "template type" + "=eq." + "landscape" + "&", "A", _searchRq_request_listener);
					} else {
						searchRqMap = new HashMap<>(); 
						searchRqMap.put("apikey", getString(R.string.database_api_key));
						searchRq.setHeaders(searchRqMap);
						searchRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "title" + "=ilike.*" + _charSeq + "*" + "&" + "template type" + "=eq." + "portrait" + "&", "B", _searchRq_request_listener);
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		linear_chip1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_chip1.setChecked(true);
				linear_chip2.setChecked(false);
			}
		});
		
		linear_chip2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_chip1.setChecked(false);
				linear_chip2.setChecked(true);
			}
		});
		
		_searchRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				searchListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				if (edittext_search.getText().toString().equals("")) {
					listview1.setVisibility(View.VISIBLE);
					listview2.setVisibility(View.GONE);
					gridview1.setVisibility(View.GONE);
					_TransitionManager(linear1, 300);
				} else {
					if (_response.equals("[]")) {
							listview1.setVisibility(View.VISIBLE);
						listview2.setVisibility(View.GONE);
						gridview1.setVisibility(View.GONE);
						_TransitionManager(linear1, 300);
					} else {
							if (_tag.equals("A")) {
							listview1.setVisibility(View.GONE);
							listview2.setVisibility(View.VISIBLE);
							gridview1.setVisibility(View.GONE);
							listview2.setAdapter(new Listview2Adapter(searchListMap));
							((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
							_TransitionManager(linear1, 300);
						} else {
							listview1.setVisibility(View.GONE);
							listview2.setVisibility(View.GONE);
							gridview1.setVisibility(View.VISIBLE);
							gridview1.setAdapter(new Gridview1Adapter(searchListMap));
							_TransitionManager(linear1, 300);
						}
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_userRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					try {
						userListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						userMap = userListMap.get((int)0);
					} catch (Exception e) {
						 
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Gaming");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Vlogs");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Tech Reviews");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Lifestyle");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Travel");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Education");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Music Videos");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Cinematic Edits");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Business & Corporate");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Sports Highlights");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Fashion & Beauty");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Food & Cooking");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Motivational");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "News & Politics");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Comedy & Memes");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Wedding & Events");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Fitness & Gym");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Real Estate");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Product Reviews");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "TikTok & Shorts");
			    suggestionMp.add(_item);
		}
		
		listview1.setAdapter(new Listview1Adapter(suggestionMp));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(listview1);
			}
		}
		//End: "over scroll checker"
		userRqMap = new HashMap<>(); 
		userRqMap.put("apikey", getString(R.string.database_api_key));
		userRq.setHeaders(userRqMap);
		userRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&", "", _userRq_request_listener);
		linear_chip1.setText("Landscape Templates");
		linear_chip2.setText("Portrait Templates");
		linear_chip1.setChecked(true);
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.landscape, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userMap.get("account type").toString().equals("premium")) {
					textview_title.setText("Unlocked");
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(searchListMap.get((int)peekPosition).get("category").toString());
							peekText2.setText(searchListMap.get((int)peekPosition).get("media type").toString());
							peekText3.setText(searchListMap.get((int)peekPosition).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
			
			return _view;
		}
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.portrait, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userMap.get("account type").toString().equals("premium")) {
					textview_title.setText("Unlocked");
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition2 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(searchListMap.get((int)peekPosition2).get("category").toString());
							peekText2.setText(searchListMap.get((int)peekPosition2).get("media type").toString());
							peekText3.setText(searchListMap.get((int)peekPosition2).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
			
			return _view;
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.category, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			final com.google.android.material.button.MaterialButton button2 = _view.findViewById(R.id.button2);
			
			textview_title.setText(_data.get((int)_position).get("hi").toString());
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					edittext_search.setText(_data.get((int)_position).get("hi").toString());
				}
			});
			
			return _view;
		}
	}
}
