package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.airbnb.lottie.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.*;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;


public class AuthenticationActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
RealTimeNetworkHelper networkHelper;

private FasterM3BottomSheetLoader fmbsd2;
	
	private Timer _timer = new Timer();
	
	private boolean signin_mode = false;
	private String mode = "";
	private HashMap<String, Object> SingUpMap = new HashMap<>();
	private HashMap<String, Object> CheckDataMap = new HashMap<>();
	private HashMap<String, Object> errorSignUpResponseMap = new HashMap<>();
	private HashMap<String, Object> authenticationHeadersMap = new HashMap<>();
	private HashMap<String, Object> authenticationValueMap = new HashMap<>();
	private boolean emailTextCheck = false;
	private boolean nameTextCheck = false;
	private boolean socialTextCheck = false;
	private boolean question2TextCheck = false;
	private boolean question1TextCheck = false;
	private boolean passwordTextCheck = false;
	private HashMap<String, Object> SignInMap = new HashMap<>();
	private HashMap<String, Object> SignInResponseMap = new HashMap<>();
	private HashMap<String, Object> errorSignInResponseMap = new HashMap<>();
	private HashMap<String, Object> confirmEmailMap = new HashMap<>();
	private HashMap<String, Object> confirmEmailResMap = new HashMap<>();
	private HashMap<String, Object> confirmEmailErrorMap = new HashMap<>();
	private HashMap<String, Object> user = new HashMap<>();
	private HashMap<String, Object> signUpResponseMap = new HashMap<>();
	private String get_uid = "";
	private HashMap<String, Object> ForgotPassMap = new HashMap<>();
	private HashMap<String, Object> ForgotPasswordResponseMap = new HashMap<>();
	private HashMap<String, Object> ForgotPassErrorMap = new HashMap<>();
	private HashMap<String, Object> ForgotPassMap2 = new HashMap<>();
	private HashMap<String, Object> ForgotPassMap3 = new HashMap<>();
	private String get_email = "";
	private String savedToken = "";
	private HashMap<String, Object> SignUpMap = new HashMap<>();
	private HashMap<String, Object> updatePasswordMap = new HashMap<>();
	private String newpasStore = "";
	private HashMap<String, Object> updatePasswordErrorRessMap = new HashMap<>();
	private HashMap<String, Object> countryMap = new HashMap<>();
	private String countryName = "";
	
	private ArrayList<HashMap<String, Object>> countryListMap = new ArrayList<>();
	
	private LinearLayout linear_selector;
	private ScrollView vscroll1;
	private RelativeLayout relativelayout1;
	private TextView textview1;
	private TextView textview2;
	private MaterialButton button_select_signin;
	private MaterialButton button2;
	private TextView textview5;
	private TextView textview_dot;
	private TextView textview7;
	private MaterialButton button3;
	private TextView textview_top;
	private RelativeLayout relativelayout2;
	private ImageView imageview1;
	private LottieAnimationView lottie1;
	private LinearLayout linear_authentication;
	private TextView textview_top_authentication;
	private TextInputLayout textinput_name;
	private TextInputLayout textinput_email;
	private TextInputLayout textinput_socialLink;
	private TextInputLayout textinput_question1;
	private TextInputLayout textinput_question2;
	private TextInputLayout textinput_password;
	private LinearLayout linear1;
	private EditText et1;
	private EditText et2;
	private EditText et3;
	private AutoCompleteTextView autocomplete_question1;
	private EditText et5;
	private EditText et6;
	private Button button_back;
	private LinearLayout linear2;
	private Button button_authentication;
	
	private RequestNetwork Rq_create_account;
	private RequestNetwork.RequestListener _Rq_create_account_request_listener;
	private RequestNetwork auth;
	private RequestNetwork.RequestListener _auth_request_listener;
	private Calendar date_get = Calendar.getInstance();
	private TimerTask timer;
	private SharedPreferences save;
	private Intent intent = new Intent();
	private Intent privacyLink = new Intent();
	private RequestNetwork countryRq;
	private RequestNetwork.RequestListener _countryRq_request_listener;
	private Intent termsIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.authentication);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear_selector = findViewById(R.id.linear_selector);
		vscroll1 = findViewById(R.id.vscroll1);
		relativelayout1 = findViewById(R.id.relativelayout1);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		button_select_signin = findViewById(R.id.button_select_signin);
		button2 = findViewById(R.id.button2);
		textview5 = findViewById(R.id.textview5);
		textview_dot = findViewById(R.id.textview_dot);
		textview7 = findViewById(R.id.textview7);
		button3 = findViewById(R.id.button3);
		textview_top = findViewById(R.id.textview_top);
		relativelayout2 = findViewById(R.id.relativelayout2);
		imageview1 = findViewById(R.id.imageview1);
		lottie1 = findViewById(R.id.lottie1);
		linear_authentication = findViewById(R.id.linear_authentication);
		textview_top_authentication = findViewById(R.id.textview_top_authentication);
		textinput_name = findViewById(R.id.textinput_name);
		textinput_email = findViewById(R.id.textinput_email);
		textinput_socialLink = findViewById(R.id.textinput_socialLink);
		textinput_question1 = findViewById(R.id.textinput_question1);
		textinput_question2 = findViewById(R.id.textinput_question2);
		textinput_password = findViewById(R.id.textinput_password);
		linear1 = findViewById(R.id.linear1);
		et1 = findViewById(R.id.et1);
		et2 = findViewById(R.id.et2);
		et3 = findViewById(R.id.et3);
		autocomplete_question1 = findViewById(R.id.autocomplete_question1);
		et5 = findViewById(R.id.et5);
		et6 = findViewById(R.id.et6);
		button_back = findViewById(R.id.button_back);
		linear2 = findViewById(R.id.linear2);
		button_authentication = findViewById(R.id.button_authentication);
		Rq_create_account = new RequestNetwork(this);
		auth = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		countryRq = new RequestNetwork(this);
		
		button_select_signin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textinput_name.setVisibility(View.GONE);
				textinput_socialLink.setVisibility(View.GONE);
				textinput_question1.setVisibility(View.GONE);
				textinput_question2.setVisibility(View.GONE);
				button_authentication.setText("Sign in");
				textview_top_authentication.setText("Welcome back! login your existing account!");
				    ObjectAnimator fadeOut = ObjectAnimator.ofFloat(linear_selector, "alpha", 1f, 0f);
				    fadeOut.setDuration(500);
				    fadeOut.addListener(new AnimatorListenerAdapter() {
					        @Override
					        public void onAnimationEnd(Animator animation) {
						            linear_selector.setVisibility(View.GONE);
						            linear_authentication.setVisibility(View.VISIBLE);
						            ObjectAnimator moveY = ObjectAnimator.ofFloat(linear_authentication, "translationY", 500f, 0f);
						            ObjectAnimator scaleX = ObjectAnimator.ofFloat(linear_authentication, "scaleX", 0.8f, 1f);
						            ObjectAnimator scaleY = ObjectAnimator.ofFloat(linear_authentication, "scaleY", 0.8f, 1f);
						            ObjectAnimator alpha = ObjectAnimator.ofFloat(linear_authentication, "alpha", 0f, 1f);
						            moveY.setDuration(1000);
						            scaleX.setDuration(1000);
						            scaleY.setDuration(1000);
						            alpha.setDuration(1000);
						            AnimatorSet appearSet = new AnimatorSet();
						            appearSet.playTogether(moveY, scaleX, scaleY, alpha);
						            appearSet.start();
						        }
					    });
				    fadeOut.start();
				signin_mode = true;
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				textinput_name.setVisibility(View.VISIBLE);
				textinput_socialLink.setVisibility(View.VISIBLE);
				textinput_question1.setVisibility(View.VISIBLE);
				textinput_question2.setVisibility(View.VISIBLE);
				button_authentication.setText("Sign up");
				textview_top_authentication.setText("Create your new account! And fill some questions!");
				    ObjectAnimator fadeOut = ObjectAnimator.ofFloat(linear_selector, "alpha", 1f, 0f);
				    fadeOut.setDuration(500);
				    fadeOut.addListener(new AnimatorListenerAdapter() {
					        @Override
					        public void onAnimationEnd(Animator animation) {
						            linear_selector.setVisibility(View.GONE);
						            linear_authentication.setVisibility(View.VISIBLE);
						            ObjectAnimator moveY = ObjectAnimator.ofFloat(linear_authentication, "translationY", 500f, 0f);
						            ObjectAnimator scaleX = ObjectAnimator.ofFloat(linear_authentication, "scaleX", 0.8f, 1f);
						            ObjectAnimator scaleY = ObjectAnimator.ofFloat(linear_authentication, "scaleY", 0.8f, 1f);
						            ObjectAnimator alpha = ObjectAnimator.ofFloat(linear_authentication, "alpha", 0f, 1f);
						            moveY.setDuration(1000);
						            scaleX.setDuration(1000);
						            scaleY.setDuration(1000);
						            alpha.setDuration(1000);
						            AnimatorSet appearSet = new AnimatorSet();
						            appearSet.playTogether(moveY, scaleX, scaleY, alpha);
						            appearSet.start();
						        }
					    });
				    fadeOut.start();
				signin_mode = false;
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				termsIntent.setAction(Intent.ACTION_VIEW);
				termsIntent.setData(Uri.parse(getString(R.string.termsUrl)));
				startActivity(termsIntent);
			}
		});
		
		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				privacyLink.setAction(Intent.ACTION_VIEW);
				privacyLink.setData(Uri.parse(getString(R.string.privacyUrl)));
				startActivity(privacyLink);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final
				com.google.android.material.bottomsheet.BottomSheetDialog changePass = new com.google.android.material.bottomsheet.BottomSheetDialog(AuthenticationActivity.this);
				View changePassDesign = getLayoutInflater().inflate(R.layout.forgotpassword_bottomsheet, null);
				changePass.setContentView(changePassDesign);
				changePass.getWindow().getDecorView().setBackgroundColor(0);
				final Button linear_close = changePassDesign.findViewById(R.id.linear_close);
				final TextInputLayout textinput_email = changePassDesign.findViewById(R.id.textinput_email);
				final TextInputLayout textinput_code = changePassDesign.findViewById(R.id.textinput_code);
				final TextInputLayout textinput_newpass = changePassDesign.findViewById(R.id.textinput_newpass);
				final TextInputLayout textinputlayout_question2 = changePassDesign.findViewById(R.id.textinputlayout_question2);
				final TextInputLayout textinputlayout_old_pass = changePassDesign.findViewById(R.id.textinputlayout_old_pass);
				final EditText edittext_email = changePassDesign.findViewById(R.id.edittext_email);
				final EditText edittext_code = changePassDesign.findViewById(R.id.edittext_code);
				final EditText edittext_newpass = changePassDesign.findViewById(R.id.edittext_newpass);
				final LinearLayout linear_succ = changePassDesign.findViewById(R.id.linear_succ);
				final Button button_submit = changePassDesign.findViewById(R.id.button_submit);
				final LinearLayout linear_bt = changePassDesign.findViewById(R.id.linear_bt);
				final LinearLayout linear_body = changePassDesign.findViewById(R.id.linear_body);
				textinput_code.setVisibility(View.GONE);
				textinput_newpass.setVisibility(View.GONE);
				linear_succ.setVisibility(View.GONE);
				textinputlayout_question2.setVisibility(View.GONE);
				textinputlayout_old_pass.setVisibility(View.GONE);
				mode = "fast";
				linear_close.setOnClickListener(v -> {
					changePass.dismiss();
							        });
				button_submit.setOnClickListener(v -> {
					if (mode.equals("fast")) {
						if (edittext_email.getText().toString().isEmpty()) {
							com.google.android.material.snackbar.Snackbar.make(linear_body, "You must provide an email address!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
						} else {
							button_submit.setEnabled(false);
							get_email = edittext_email.getText().toString();
							OkHttpClient client = new OkHttpClient();
							
							try {
								    JSONObject ForgotPassMap = new JSONObject();
								    ForgotPassMap.put("email", edittext_email.getText().toString());
								
								    RequestBody body = RequestBody.create(MediaType.parse("application/json"), ForgotPassMap.toString());
								
								    Request request = new Request.Builder()
								            .url(getString(R.string.database_url) + "/auth/v1/recover")
								            .addHeader("apikey", getString(R.string.database_api_key))
								            .addHeader("Content-Type", "application/json")
								            .post(body)
								            .build();
								
								    client.newCall(request).enqueue(new Callback() {
									@Override
									public void onFailure(Call call, IOException e) {
										final String errorMessage = e.getMessage();
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Response failed. Check your internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
												button_submit.setEnabled(true);
											}
										});
									}
									@Override
									public void onResponse(Call call, Response response) throws IOException {
										final boolean isSuccessful = response.isSuccessful();
										final String responseBody = response.body().string();
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												if (isSuccessful) {
													_TransitionManager(linear_body, 300);
													textinput_email.setVisibility(View.GONE);
													textinput_code.setVisibility(View.VISIBLE);
													mode = "second";
													button_submit.setEnabled(true);
												} else {
													ForgotPassErrorMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
													com.google.android.material.snackbar.Snackbar.make(linear_body, ForgotPassErrorMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
														@Override
														public void onClick(View _view) {
															 
														}
													}).show();
													button_submit.setEnabled(true);
												}
											}
										});
									}
								});
							} catch (Exception e) {
								 
							}
						}
					} else {
						if (mode.equals("second")) {
							if (edittext_code.getText().toString().length() < 6) {
								com.google.android.material.snackbar.Snackbar.make(linear_body, "otp must be 6 digit!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							} else {
								button_submit.setEnabled(false);
								try {
									OkHttpClient client = new OkHttpClient();
									
									    JSONObject ForgotPassMap2 = new JSONObject();
									    ForgotPassMap2.put("email", get_email);
									    ForgotPassMap2.put("token", edittext_code.getText().toString());
									    ForgotPassMap2.put("type", "recovery");
									
									    RequestBody body = RequestBody.create(MediaType.parse("application/json"), ForgotPassMap2.toString());
									
									    Request request = new Request.Builder()
									            .url(getString(R.string.database_url) + "/auth/v1/verify")
									            .addHeader("apikey", getString(R.string.database_api_key))
									            .addHeader("Content-Type", "application/json")
									            .post(body)
									            .build();
									
									    client.newCall(request).enqueue(new Callback() {
										@Override
										public void onFailure(Call call, IOException e) {
											final String errorMessage = e.getMessage();
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													com.google.android.material.snackbar.Snackbar.make(linear_body, "Response failed. Check your internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
														@Override
														public void onClick(View _view) {
															 
														}
													}).show();
													button_submit.setEnabled(true);
												}
											});
										}
										@Override
										public void onResponse(Call call, Response response) throws IOException {
											final boolean isSuccessful = response.isSuccessful();
											final String responseBody = response.body().string();
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													if (isSuccessful) {
														_TransitionManager(linear_body, 300);
														ForgotPasswordResponseMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
														get_uid = ForgotPasswordResponseMap.get("user").toString().substring((int)(4), (int)(40));
														textinput_code.setVisibility(View.GONE);
														textinput_newpass.setVisibility(View.VISIBLE);
														mode = "third";
														button_submit.setEnabled(true);
													} else {
														ForgotPassErrorMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
														com.google.android.material.snackbar.Snackbar.make(linear_body, ForgotPassErrorMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
														button_submit.setEnabled(true);
													}
												}
											});
										}
									});
								} catch (Exception e) {
									 
								}
							}
						} else {
							if (mode.equals("third")) {
								if (edittext_newpass.getText().toString().matches(".*[@#$&%].*")) {
									if (edittext_newpass.getText().toString().matches(".*[0-9].*")) {
										if (edittext_newpass.getText().toString().length() < 8) {
											com.google.android.material.snackbar.Snackbar.make(linear_body, "Minimum 8 characters!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										} else {
											button_submit.setEnabled(false);
											newpasStore = edittext_newpass.getText().toString();
											try {
												OkHttpClient client = new OkHttpClient();
												
												    JSONObject ForgotPassMap3 = new JSONObject();
												    ForgotPassMap3.put("password", newpasStore);
												
												    RequestBody body = RequestBody.create(MediaType.parse("application/json"), ForgotPassMap3.toString());
												
												    Request request = new Request.Builder()
												            .url(getString(R.string.database_url) + "/auth/v1/admin/users/" + get_uid)
												            .addHeader("apikey", getString(R.string.SecretKey))
												            .addHeader("Content-Type", "application/json")
												            .addHeader("Authorization", "Bearer " + getString(R.string.SecretKey))
												            .put(body)
												            .build();
												
												    client.newCall(request).enqueue(new Callback() {
													@Override
													public void onFailure(Call call, IOException e) {
														final String errorMessage = e.getMessage();
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																com.google.android.material.snackbar.Snackbar.make(linear_body, "Response failed. Check your internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																	@Override
																	public void onClick(View _view) {
																		 
																	}
																}).show();
																button_submit.setEnabled(true);
															}
														});
													}
													@Override
													public void onResponse(Call call, Response response) throws IOException {
														final boolean isSuccessful = response.isSuccessful();
														final String responseBody = response.body().string();
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																if (isSuccessful) {
																	updatePasswordMap = new Gson().fromJson("{" + "\"" + "password" + "\":\"" + newpasStore + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
																	OkHttpClient client = new OkHttpClient();
																	Request request = new Request.Builder()
																	    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + get_uid)
																	    .addHeader("apikey", getString(R.string.database_api_key))
																	    .patch(RequestBody.create(
																	        MediaType.parse("application/json; charset=utf-8"),
																	        new Gson().toJson(updatePasswordMap)
																	    ))
																	    .build();
																	client.newCall(request).enqueue(new Callback() {
																		    @Override
																		    public void onFailure(Call call, IOException e) {
																			        final String errorMessage = e.getMessage();
																			        new Handler(Looper.getMainLooper()).post(new Runnable() {
																				            @Override
																				            public void run() {
																					                 
																					            }
																				        });
																			    }
																		    @Override
																		    public void onResponse(Call call, Response response) throws IOException {
																			        final String responseMessage = response.body().string(); 
																			        if (response.isSuccessful()) {
																				            new Handler(Looper.getMainLooper()).post(new Runnable() {
																					                @Override
																					                public void run() {
																						                    _TransitionManager(linear_body, 300);
																						textinput_newpass.setVisibility(View.GONE);
																						linear_bt.setVisibility(View.GONE);
																						linear_succ.setVisibility(View.VISIBLE);
																						mode = "";
																						button_submit.setEnabled(true);
																						                }
																					            });
																				        } else {
																				            new Handler(Looper.getMainLooper()).post(new Runnable() {
																					                @Override
																					                public void run() {
																						                    updatePasswordErrorRessMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
																						com.google.android.material.snackbar.Snackbar.make(linear_body, updatePasswordErrorRessMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																							@Override
																							public void onClick(View _view) {
																								 
																							}
																						}).show();
																						                }
																					            });
																				        }
																			    }
																	});
																} else {
																	button_submit.setEnabled(true);
																	ForgotPassErrorMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
																	com.google.android.material.snackbar.Snackbar.make(linear_body, "", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																		@Override
																		public void onClick(View _view) {
																			 
																		}
																	}).show();
																}
															}
														});
													}
												});
											} catch (Exception e) {
												 
											}
										}
									} else {
										com.google.android.material.snackbar.Snackbar.make(linear_body, "Password must contain at least one number (0-9)!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
									}
								} else {
									com.google.android.material.snackbar.Snackbar.make(linear_body, "Password must contain at least one special character (@, #, $, &, %)!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								}
							}
						}
					}
							        });
				changePass.setCancelable(false);
				changePass.show();
			}
		});
		
		et1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_name.setErrorEnabled(true);
					textinput_name.setError("Please enter your full name");
					nameTextCheck = false;
				} else {
					textinput_name.setErrorEnabled(false);
					nameTextCheck = false;
					if (_charSeq.length() > textinput_name.getCounterMaxLength()) {
						textinput_name.setErrorEnabled(true);
						textinput_name.setError("Text exceeds maximum length!");
						nameTextCheck = false;
					} else {
						textinput_name.setErrorEnabled(false);
						nameTextCheck = true;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		et2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_email.setErrorEnabled(true);
					textinput_email.setError("Please enter a valid email!");
					emailTextCheck = false;
				} else {
					textinput_email.setErrorEnabled(false);
					emailTextCheck = false;
					if (_charSeq.contains(" ")) {
						textinput_email.setErrorEnabled(true);
						textinput_email.setError("Spaces cannot be given!");
						emailTextCheck = false;
					} else {
						textinput_email.setErrorEnabled(false);
						emailTextCheck = false;
						if (_charSeq.contains("@gmail.com")) {
							textinput_email.setErrorEnabled(false);
							emailTextCheck = true;
						} else {
							textinput_email.setErrorEnabled(true);
							textinput_email.setError(" @gmail.com is required!");
							emailTextCheck = false;
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		et3.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_socialLink.setErrorEnabled(true);
					textinput_socialLink.setError("Please enter a social media url!");
					socialTextCheck = false;
				} else {
					textinput_socialLink.setErrorEnabled(false);
					socialTextCheck = false;
					if (_charSeq.contains(" ")) {
						textinput_socialLink.setErrorEnabled(true);
						textinput_socialLink.setError("Spaces cannot be given!");
						socialTextCheck = false;
					} else {
						textinput_socialLink.setErrorEnabled(false);
						socialTextCheck = false;
						if (_charSeq.contains("https://") || _charSeq.contains("http://")) {
							textinput_socialLink.setErrorEnabled(true);
							textinput_socialLink.setError("Domain invalid! Don't use http or https.");
							socialTextCheck = false;
						} else {
							textinput_socialLink.setErrorEnabled(false);
							socialTextCheck = false;
							if (_charSeq.contains(".")) {
								textinput_socialLink.setErrorEnabled(false);
								socialTextCheck = true;
							} else {
								textinput_socialLink.setErrorEnabled(true);
								textinput_socialLink.setError("Domain invalid!");
								socialTextCheck = false;
							}
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		autocomplete_question1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_question1.setErrorEnabled(true);
					textinput_question1.setError("Please fill the question!");
					question1TextCheck = false;
				} else {
					textinput_question1.setErrorEnabled(false);
					question1TextCheck = true;
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		et5.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_question2.setErrorEnabled(true);
					textinput_question2.setError("Please fill the question!");
					question2TextCheck = false;
				} else {
					textinput_question2.setErrorEnabled(false);
					question2TextCheck = false;
					if (_charSeq.contains(" ")) {
						textinput_question2.setErrorEnabled(true);
						textinput_question2.setError("Spaces cannot be given!");
						question2TextCheck = false;
					} else {
						textinput_question2.setErrorEnabled(false);
						question2TextCheck = true;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		et6.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_password.setErrorEnabled(true);
					textinput_password.setError("Please a strong password!");
					passwordTextCheck = false;
				} else {
					textinput_password.setErrorEnabled(false);
					passwordTextCheck = false;
					if (_charSeq.contains(" ")) {
						textinput_password.setErrorEnabled(true);
						textinput_password.setError("Spaces cannot be given!");
						passwordTextCheck = false;
					} else {
						textinput_password.setErrorEnabled(false);
						passwordTextCheck = false;
						if (_charSeq.matches(".*[@#$&%].*")) {
							textinput_password.setErrorEnabled(false);
							passwordTextCheck = false;
							if (_charSeq.matches(".*[0-9].*")) {
								textinput_password.setErrorEnabled(false);
								passwordTextCheck = false;
								if (_charSeq.length() < 8) {
									textinput_password.setErrorEnabled(true);
									textinput_password.setError("Minimum 8 characters!");
									passwordTextCheck = false;
								} else {
									textinput_password.setErrorEnabled(false);
									passwordTextCheck = true;
								}
							} else {
								textinput_password.setErrorEnabled(true);
								textinput_password.setError("Password must contain at least one number (0-9)!");
								passwordTextCheck = false;
							}
						} else {
							textinput_password.setErrorEnabled(true);
							textinput_password.setError("Password must contain at least one special character (@, #, $, &, %)!");
							passwordTextCheck = false;
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button_back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				    ObjectAnimator fadeOut = ObjectAnimator.ofFloat(linear_authentication, "alpha", 1f, 0f);
				    fadeOut.setDuration(500);
				    fadeOut.addListener(new AnimatorListenerAdapter() {
					        @Override
					        public void onAnimationEnd(Animator animation) {
						            linear_authentication.setVisibility(View.GONE);
						            linear_selector.setVisibility(View.VISIBLE);
						            ObjectAnimator moveY = ObjectAnimator.ofFloat(linear_selector, "translationY", 500f, 0f);
						            ObjectAnimator scaleX = ObjectAnimator.ofFloat(linear_selector, "scaleX", 0.8f, 1f);
						            ObjectAnimator scaleY = ObjectAnimator.ofFloat(linear_selector, "scaleY", 0.8f, 1f);
						            ObjectAnimator alpha = ObjectAnimator.ofFloat(linear_selector, "alpha", 0f, 1f);
						            moveY.setDuration(1000);
						            scaleX.setDuration(1000);
						            scaleY.setDuration(1000);
						            alpha.setDuration(1000);
						            AnimatorSet appearSet = new AnimatorSet();
						            appearSet.playTogether(moveY, scaleX, scaleY, alpha);
						            appearSet.start();
						        }
					    });
				    fadeOut.start();
				_clearData();
			}
		});
		
		button_authentication.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (emailTextCheck && passwordTextCheck) {
					if (signin_mode) {
						FasterM3BottomSheetLoader fmbsd1 = new FasterM3BottomSheetLoader(AuthenticationActivity.this);
						fmbsd1.setCancelableOnOutsideClick(false);
						fmbsd1.show("Checking your provided information....");
						try {
							OkHttpClient client = new OkHttpClient();
							
							    JSONObject SignInMap = new JSONObject();
							    SignInMap.put("email", et2.getText().toString());
							    SignInMap.put("password", et6.getText().toString());
							
							    RequestBody body = RequestBody.create(MediaType.parse("application/json"), SignInMap.toString());
							
							    Request request = new Request.Builder()
							            .url(getString(R.string.database_url) + "/auth/v1/token?grant_type=password")
							            .addHeader("apikey", getString(R.string.database_api_key))
							            .addHeader("Content-Type", "application/json")
							            .post(body)
							            .build();
							
							client.newCall(request).enqueue(
							new Callback() {
								@Override
								public void onFailure(Call call, IOException e) {
									final String errorMessage = e.getMessage();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											com.google.android.material.snackbar.Snackbar.make(linear_authentication, "Oh no! the request is failed to send.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
											fmbsd1.dismiss();
										}
									});
								}
								@Override
								public void onResponse(Call call, Response response) throws IOException {
									final boolean isSuccessful = response.isSuccessful();
									final String responseBody = response.body().string();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (isSuccessful) {
												SignInResponseMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
												fmbsd1.dismiss();
												save.edit().putString("refresh_token", SignInResponseMap.get("refresh_token").toString()).commit();
												save.edit().putString("access_token", SignInResponseMap.get("access_token").toString()).commit();
												save.edit().putString("authentication", "yes").commit();
												save.edit().putString("user id", SignInResponseMap.get("user").toString().substring((int)(4), (int)(40))).commit();
												save.edit().putString("email", et2.getText().toString()).commit();
												save.edit().putString("password", et6.getText().toString()).commit();
												intent.setClass(getApplicationContext(), DashboardActivity.class);
												ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(AuthenticationActivity.this, R.anim.fade_in, R.anim.fade_out);
												startActivity(intent, intentOp.toBundle());

												finish();
											} else {
												errorSignInResponseMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
												com.google.android.material.snackbar.Snackbar.make(linear_authentication, errorSignInResponseMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
												fmbsd1.dismiss();
											}
										}
									});
								}
							});
						} catch (Exception e) {
							 
						}
					} else {
						if (nameTextCheck && (emailTextCheck && (socialTextCheck && (question1TextCheck && (question2TextCheck && passwordTextCheck))))) {
							fmbsd2 = new FasterM3BottomSheetLoader(AuthenticationActivity.this);
							fmbsd2.setCancelableOnOutsideClick(false);
							fmbsd2.show("Checking email....");
							CheckDataMap = new HashMap<>(); 
							CheckDataMap.put("apikey", getString(R.string.database_api_key));
							Rq_create_account.setHeaders(CheckDataMap);
							Rq_create_account.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "email" + "=eq." + et2.getText().toString(), "A", _Rq_create_account_request_listener);
						}
					}
				}
			}
		});
		
		_Rq_create_account_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								timer.cancel();
								if (_response.equals("[]")) {
									fmbsd2.updateMessage("Creating your account....");
									// Start: "Note: This blocks is work 1 block"
									try {
										  OkHttpClient client = new OkHttpClient();
										
										    JSONObject SignUpMap = new JSONObject();
										    SignUpMap.put("email", et2.getText().toString());
										    SignUpMap.put("password", et6.getText().toString());
										
										    RequestBody body = RequestBody.create(MediaType.parse("application/json"), SignUpMap.toString());
										
										    Request request = new Request.Builder()
										            .url(getString(R.string.database_url) + "/auth/v1/signup")
										            .addHeader("apikey", getString(R.string.database_api_key))
										            .addHeader("Content-Type", "application/json")
										            .post(body)
										            .build();
										
										    client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												final String errorMessage = e.getMessage();
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_authentication, "Oh no! the request is failed to send.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
														fmbsd2.dismiss();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												final boolean isSuccessful = response.isSuccessful();
												final String responseBody = response.body().string();
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														if (isSuccessful) {
															signUpResponseMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
															if (signUpResponseMap.get("identities").toString().trim().equals("[]")) {
																com.google.android.material.snackbar.Snackbar.make(linear_authentication, "This email address is already used!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																	@Override
																	public void onClick(View _view) {
																		 
																	}
																}).show();
																fmbsd2.dismiss();
															} else {
																get_uid = signUpResponseMap.get("id").toString();
																date_get = Calendar.getInstance();
																authenticationValueMap = new HashMap<>();
																authenticationHeadersMap = new HashMap<>();
																authenticationHeadersMap.put("apikey", getString(R.string.database_api_key));
																authenticationHeadersMap.put("Content-Type", "application/json");
																authenticationValueMap.put("uid", get_uid);
																authenticationValueMap.put("name", et1.getText().toString().trim());
																authenticationValueMap.put("email", et2.getText().toString().trim());
																authenticationValueMap.put("password", et6.getText().toString().trim());
																authenticationValueMap.put("device id", FasterUtils.getDeviceId(AuthenticationActivity.this));
																authenticationValueMap.put("country", countryName);
																authenticationValueMap.put("account type", "free");
																authenticationValueMap.put("register date", new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a").format(date_get.getTime()));
																authenticationValueMap.put("social media", et3.getText().toString().trim());
																authenticationValueMap.put("question1", autocomplete_question1.getText().toString().trim());
																authenticationValueMap.put("question2", et5.getText().toString().trim());
																authenticationValueMap.put("deposit balance", "0.00");
																authenticationValueMap.put("notification token", save.getString("notification token", ""));
																authenticationValueMap.put("risk type", "none");
																authenticationValueMap.put("mobile number", "none");
																authenticationValueMap.put("logo url", "none");
																authenticationValueMap.put("expired date", "none");
																authenticationValueMap.put("imageDeleteToken", "none");
																auth.setHeaders(authenticationHeadersMap); auth.setParams(authenticationValueMap, RequestNetworkController.REQUEST_PARAM); auth.startRequestNetwork(RequestNetworkController.POST, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata", "New Account", _auth_request_listener);
															}
															_emailConfirmation();
														} else {
															errorSignUpResponseMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
															com.google.android.material.snackbar.Snackbar.make(linear_authentication, errorSignUpResponseMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
															fmbsd2.dismiss();
														}
													}
												});
											}
										});
									} catch (Exception e) {
										 
									}
									//End: "Note: This blocks is work 1 block"
								} else {
									com.google.android.material.snackbar.Snackbar.make(linear_authentication, "This email address is already used!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									fmbsd2.dismiss();
								}
							}
						});
					}
				};
				_timer.schedule(timer, (int)(2000));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_auth_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				fmbsd2.dismiss();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				com.google.android.material.snackbar.Snackbar.make(linear_authentication, "something went wrong", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			}
		};
		
		_countryRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					countryMap = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					countryName = countryMap.get("country").toString();
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		linear_authentication.setVisibility(View.GONE);
		linear_selector.setVisibility(View.VISIBLE);
		autocomplete_question1.setInputType(InputType.TYPE_NULL);
		String[] type = new String[] {"Play Store","Browser Search","YouTube","I heard from someone"};
		        ArrayAdapter<String> adapter =
		                new ArrayAdapter<>(
		                        this,
		                        R.layout.spinner_cus,
		                        R.id.textview1,
		                        type);
		
		        autocomplete_question1.setAdapter(adapter);
		signin_mode = false;
		nameTextCheck = false;
		emailTextCheck = false;
		socialTextCheck = false;
		question1TextCheck = false;
		question2TextCheck = false;
		passwordTextCheck = false;
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				if (linear_authentication.getVisibility() == View.VISIBLE) {
					button_back.performClick();
				} else {
					finishAffinity();
				}
			}
		});

		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(AuthenticationActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(AuthenticationActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
		countryRq.startRequestNetwork(RequestNetworkController.GET, "https://ipwho.is/", "", _countryRq_request_listener);
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
		try {
			timer.cancel();
		} catch (Exception e) {
			 
		}
	}
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _emailConfirmation() {
		final
		com.google.android.material.bottomsheet.BottomSheetDialog confirmEmail = new com.google.android.material.bottomsheet.BottomSheetDialog(AuthenticationActivity.this);
		View confirmEmailDesign = getLayoutInflater().inflate(R.layout.forgotpassword_bottomsheet, null);
		confirmEmail.setContentView(confirmEmailDesign);
		confirmEmail.getWindow().getDecorView().setBackgroundColor(0);
		final Button linear_close = confirmEmailDesign.findViewById(R.id.linear_close);
		final TextInputLayout textinput_email = confirmEmailDesign.findViewById(R.id.textinput_email);
		final TextInputLayout textinput_code = confirmEmailDesign.findViewById(R.id.textinput_code);
		final TextInputLayout textinput_newpass = confirmEmailDesign.findViewById(R.id.textinput_newpass);
		final TextInputLayout textinputlayout_old_pass = confirmEmailDesign.findViewById(R.id.textinputlayout_old_pass);
		final TextInputLayout textinputlayout_question2 = confirmEmailDesign.findViewById(R.id.textinputlayout_question2);
		final EditText edittext_code = confirmEmailDesign.findViewById(R.id.edittext_code);
		final LinearLayout linear_succ = confirmEmailDesign.findViewById(R.id.linear_succ);
		final Button button_submit = confirmEmailDesign.findViewById(R.id.button_submit);
		final LinearLayout linear_bt = confirmEmailDesign.findViewById(R.id.linear_bt);
		final LinearLayout linear_body = confirmEmailDesign.findViewById(R.id.linear_body);
		final TextView textview_massage = confirmEmailDesign.findViewById(R.id.textview_massage);
		final TextView textview_top = confirmEmailDesign.findViewById(R.id.textview_top);
		textinputlayout_old_pass.setVisibility(View.GONE);
		textinputlayout_question2.setVisibility(View.GONE);
		textinput_newpass.setVisibility(View.GONE);
		linear_succ.setVisibility(View.GONE);
		textinput_email.setVisibility(View.GONE);
		textview_top.setText("Confirm your email!");
		textview_massage.setText("Email is has been confirmed that that's you. Now login your account with same email & password!");
		linear_close.setOnClickListener(v -> {
			confirmEmail.dismiss();
					        });
		button_submit.setOnClickListener(v -> {
			if (edittext_code.getText().toString().length() < 6) {
				com.google.android.material.snackbar.Snackbar.make(linear_body, "otp must be 6 digit!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			} else {
				button_submit.setEnabled(false);
				try {
					OkHttpClient client = new OkHttpClient();
					
					    JSONObject confirmEmailMap = new JSONObject();
					    confirmEmailMap.put("email", et2.getText().toString());
					    confirmEmailMap.put("token", edittext_code.getText().toString());
					    confirmEmailMap.put("type", "signup");
					
					    RequestBody body = RequestBody.create(MediaType.parse("application/json"), confirmEmailMap.toString());
					
					    Request request = new Request.Builder()
					            .url(getString(R.string.database_url) + "/auth/v1/verify")
					            .addHeader("apikey", getString(R.string.database_api_key))
					            .addHeader("Content-Type", "application/json")
					            .post(body)
					            .build();
					
					    client.newCall(request).enqueue(new Callback() {
						@Override
						public void onFailure(Call call, IOException e) {
							final String errorMessage = e.getMessage();
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									button_submit.setEnabled(true);
								}
							});
						}
						@Override
						public void onResponse(Call call, Response response) throws IOException {
							final boolean isSuccessful = response.isSuccessful();
							final String responseBody = response.body().string();
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (isSuccessful) {
										confirmEmailResMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
										_TransitionManager(linear_body, 300);
										textinput_code.setVisibility(View.GONE);
										linear_bt.setVisibility(View.GONE);
										linear_succ.setVisibility(View.VISIBLE);
										button_back.performClick();
										button_select_signin.performClick();
										button_submit.setEnabled(true);
									} else {
										confirmEmailErrorMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
										com.google.android.material.snackbar.Snackbar.make(linear_body, confirmEmailErrorMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
										button_submit.setEnabled(true);
									}
								}
							});
						}
					});
				} catch (Exception e) {
					 
				}
			}
					        });
		confirmEmail.setCancelable(false);
		confirmEmail.show();
	}
	
	
	public void _clearData() {
		et1.setText("");
		et2.setText("");
		et3.setText("");
		autocomplete_question1.setText("");
		et5.setText("");
		et6.setText("");
	}
	
}
