package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.card.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;

public class SecurityCheckerActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private MaterialCardView linear17;
	private Button button1;
	private LinearLayout linear18;
	private ImageView imageview1;
	private LinearLayout linear12;
	private TextView textview_massage;
	
	private Intent intent = new Intent();
	private SharedPreferences save;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.security_checker);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear17 = findViewById(R.id.linear17);
		button1 = findViewById(R.id.button1);
		linear18 = findViewById(R.id.linear18);
		imageview1 = findViewById(R.id.imageview1);
		linear12 = findViewById(R.id.linear12);
		textview_massage = findViewById(R.id.textview_massage);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (getIntent().getStringExtra("activity name").equals("banned")) {
					finishAffinity();
				} else {
					if (getIntent().getStringExtra("activity name").equals("re-login")) {
						save.edit().putString("email", "").commit();
						save.edit().putString("password", "").commit();
						save.edit().putString("user id", "").commit();
						save.edit().putString("authentication", "no").commit();
						intent.setClass(getApplicationContext(), MainActivity.class);
						ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(SecurityCheckerActivity.this, R.anim.fade_in, R.anim.fade_out);
						startActivity(intent, intentOp.toBundle());

						finish();
					} else {
						intent.setClass(getApplicationContext(), MainActivity.class);
						ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(SecurityCheckerActivity.this, R.anim.fade_in, R.anim.fade_out);
						startActivity(intent, intentOp.toBundle());

						finish();
					}
				}
			}
		});
	}
	
	private void initializeLogic() {
		// Start: "Remove unnecessary imports"
		//End: "Remove unnecessary imports"
		// Start: "Mode"
		if (getIntent().getStringExtra("activity name").equals("re-login")) {
			textview_massage.setText("Your data not found please log in again or come back to the app again!");
			button1.setText("Re-Login");
		} else {
			if (getIntent().getStringExtra("activity name").equals("others")) {
				textview_massage.setText("There are some server errors. Try again or contact Apple Contact Center!");
			} else {
				if (getIntent().getStringExtra("activity name").equals("no internet access")) {
					textview_massage.setText("You have internet active but there is no internet access!");
				} else {
					if (getIntent().getStringExtra("activity name").equals("no internet")) {
						textview_massage.setText("You cannot run the app without an internet connection so connect an internet connection!");
					} else {
						if (getIntent().getStringExtra("activity name").equals("banned")) {
							textview_massage.setText("Your account has been banned due to a violation of our rules or privacy policy. If you believe this is a mistake, you can send an unban request to: fastersoftwaredeveloper@gmail.com");
							button1.setText("Exit!");
						} else {
							if (getIntent().getStringExtra("activity name").equals("login")) {
								textview_massage.setText("You are not logged in, so please log in quickly.");
								button1.setText("Login!");
							} else {
								
							}
						}
					}
				}
			}
		}
		//End: "Mode"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				finishAffinity();
			}
		});

	}
	
}
