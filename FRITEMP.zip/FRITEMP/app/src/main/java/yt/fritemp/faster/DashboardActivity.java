package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import androidx.viewpager2.widget.ViewPager2;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.google.android.material.card.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import eightbitlab.com.blurview.BlurView;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import java.util.Arrays;
import java.util.List;


public class DashboardActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
RealTimeNetworkHelper networkHelper;

private FasterM3BottomSheetLoader loader;
 
	
	private Timer _timer = new Timer();
	
	private String savedToken = "";
	private HashMap<String, Object> map = new HashMap<>();
	private HashMap<String, Object> getRefreshTokenResponse = new HashMap<>();
	private HashMap<String, Object> getRefreshTokenErrorResponse = new HashMap<>();
	private HashMap<String, Object> getDataMap = new HashMap<>();
	private String database_app_version = "";
	private HashMap<String, Object> checkProReqMap = new HashMap<>();
	private HashMap<String, Object> getProDataMap = new HashMap<>();
	private String account_type = "";
	private HashMap<String, Object> updateProData = new HashMap<>();
	private HashMap<String, Object> DetailsRqMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> getProDataListMap = new ArrayList<>();
	
	private RelativeLayout relativelayout1;
	private ViewPager2 viewPager;
	private MaterialCardView linear_nav_body;
	private BlurView blur2inside;
	private BottomNavigationView linear_nav;
	
	private SharedPreferences save;
	private TimerTask timer;
	private RequestNetwork checkSecurity;
	private RequestNetwork.RequestListener _checkSecurity_request_listener;
	private Intent app_mode_intent = new Intent();
	private RequestNetwork checkPro;
	private RequestNetwork.RequestListener _checkPro_request_listener;
	private Calendar get_date = Calendar.getInstance();
	private AlertDialog.Builder wearingDialog;
	private Intent secureIntent = new Intent();
	private Intent riskIntent = new Intent();
	private Intent errorIntent = new Intent();
	private AlertDialog.Builder notificationDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.dashboard);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		relativelayout1 = findViewById(R.id.relativelayout1);
		viewPager = findViewById(R.id.viewPager);
		linear_nav_body = findViewById(R.id.linear_nav_body);
		blur2inside = findViewById(R.id.blur2inside);
		linear_nav = findViewById(R.id.linear_nav);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		checkSecurity = new RequestNetwork(this);
		checkPro = new RequestNetwork(this);
		wearingDialog = new AlertDialog.Builder(this);
		notificationDialog = new AlertDialog.Builder(this);
		
		_checkSecurity_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					try {
						// Start: "convert json response to map"
						getDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						getDataMap = getDataListMap.get((int)0);
						//End: "convert json response to map"
						// Start: "Go another activity system"
						if (getDataMap.containsKey("maintenance_mode")) {
							if (getDataMap.get("maintenance_mode").toString().equals("on")) {
								app_mode_intent.setClass(getApplicationContext(), AppModeActivity.class);
								app_mode_intent.putExtra("app_mode", "maintenance");
								ActivityOptions app_mode_intentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
								startActivity(app_mode_intent, app_mode_intentOp.toBundle());

								finish();
							} else {
								if (getDataMap.get("update_mode").toString().equals("on")) {
									database_app_version = getDataMap.get("app_version").toString();
									if ((Double.parseDouble(getString(R.string.app_version)) == Double.parseDouble(database_app_version)) || (Double.parseDouble(getString(R.string.app_version)) > Double.parseDouble(database_app_version))) {
										
									} else {
										if (Double.parseDouble(getString(R.string.app_version)) < Double.parseDouble(database_app_version)) {
											app_mode_intent.setClass(getApplicationContext(), AppModeActivity.class);
											app_mode_intent.putExtra("app_mode", "update");
											ActivityOptions app_mode_intentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
											startActivity(app_mode_intent, app_mode_intentOp.toBundle());

											finish();
										}
									}
								} else {
									
								}
							}
						}
						//End: "Go another activity system"
					} catch (Exception e) {
						secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
						secureIntent.putExtra("activity name", "re-login");
						ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
						startActivity(secureIntent, secureIntentOp.toBundle());

						finish();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_checkPro_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					try {
						// Start: "convert json response to map"
						getProDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						getProDataMap = getProDataListMap.get((int)0);
						loader.dismiss();
						//End: "convert json response to map"
						if (getProDataMap.get("risk type").toString().equals("ban")) {
							riskIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
							riskIntent.putExtra("activity name", "banned");
							ActivityOptions riskIntentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
							startActivity(riskIntent, riskIntentOp.toBundle());

							finish();
						}
						get_date = Calendar.getInstance();
						if (getProDataMap.get("expired date").toString().equals("none")) {
							account_type = "free";
						} else {
							if (get_date.getTimeInMillis() < Double.parseDouble(getProDataMap.get("expired date").toString())) {
								account_type = "premium";
							} else {
								MaterialAlertDialogBuilder wearingDialog = new MaterialAlertDialogBuilder(DashboardActivity.this);
								wearingDialog.setTitle("Warning!");
								wearingDialog.setMessage("The premium you purchased has expired, do you want to buy it again or continue using the app with a free account?");
								wearingDialog.setPositiveButton("Continue & hide warning.", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        updateProData = new Gson().fromJson("{" + "\"" + "account type" + "\":\"" + "free" + "\"," + "\"" + "expired date" + "\":\"" + "none" + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
										OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
										    .addHeader("apikey", getString(R.string.database_api_key))
										    .patch(RequestBody.create(
										        MediaType.parse("application/json; charset=utf-8"),
										        new Gson().toJson(updateProData)
										    ))
										    .build();
										client.newCall(request).enqueue(new Callback() {
											    @Override
											    public void onFailure(Call call, IOException e) {
												        final String errorMessage = e.getMessage();
												        new Handler(Looper.getMainLooper()).post(new Runnable() {
													            @Override
													            public void run() {
														                com.google.android.material.snackbar.Snackbar.make(viewPager, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
														            }
													        });
												    }
											    @Override
											    public void onResponse(Call call, Response response) throws IOException {
												        final String responseMessage = response.body().string(); 
												        if (response.isSuccessful()) {
													            new Handler(Looper.getMainLooper()).post(new Runnable() {
														                @Override
														                public void run() {
															                    account_type = "free";
															com.google.android.material.snackbar.Snackbar.make(viewPager, " Warning hidden.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
															                }
														            });
													        } else {
													            new Handler(Looper.getMainLooper()).post(new Runnable() {
														                @Override
														                public void run() {
															                    secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
															secureIntent.putExtra("activity name", "others");
															ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
															startActivity(secureIntent, secureIntentOp.toBundle());

															finish();
															                }
														            });
													        }
												    }
										});
										    }
								});
								wearingDialog.setCancelable(false);
								wearingDialog.create().show();
							}
						}
						if (getProDataMap.get("notification token").toString().equals("none")) {
							_detailsUpdate();
						} else {
							if (!getProDataMap.get("notification token").toString().equals(save.getString("notification token", ""))) {
								_detailsUpdate();
							}
						}
					} catch (Exception e) {
						secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
						secureIntent.putExtra("activity name", "re-login");
						ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
						startActivity(secureIntent, secureIntentOp.toBundle());

						finish();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "Important"
		//End: "Important"
		// Start: "View Pager2"
		        viewPager.setAdapter(new ViewPagerAdapter(this));
		        viewPager.setOffscreenPageLimit(3);
		        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
			            @Override
			            public void onPageSelected(int position) {
				                super.onPageSelected(position);
				                switch (position) {
					                    case 0:
					                        linear_nav.setSelectedItemId(R.id.nav_home);
					                        break;
					                    case 1:
					                        linear_nav.setSelectedItemId(R.id.nav_search);
					                        break;
					                    case 2:
					                        linear_nav.setSelectedItemId(R.id.nav_list);
					                        break;
					                }
				            }
			
			            @Override
			            public void onPageScrolled(int position, float positionOffset, @Px int positionOffsetPixels) {
				            }
			
			            @Override
			            public void onPageScrollStateChanged(int state) {
				            }
			        });
		// Start: "View Pager2 Animation."
		viewPager.setOffscreenPageLimit(2);
		viewPager.setPageTransformer(new ViewPager2.PageTransformer() {
			    private final float MIN_SCALE = 0.92f;
			    private final float MAX_ELEVATION = 12f;
			
			    @Override
			    public void transformPage(@NonNull View page, float position) {
				        float absPos = Math.abs(position);
				
				        float scaleFactor = Math.max(MIN_SCALE, 1 - absPos * 0.08f);
				        float elevationFactor = (1 - absPos) * MAX_ELEVATION;
				        float alphaFactor = 1 - absPos * 0.3f;
				
				        page.setScaleX(scaleFactor);
				        page.setScaleY(scaleFactor);
				        page.setTranslationZ(elevationFactor);
				        page.setAlpha(Math.max(0.3f, alphaFactor)); // Never fully transparent
				    }
		});
		//End: "View Pager2 Animation."
		//End: "View Pager2"
		// Start: "Material 3 floating rounded bottom navigation bar."
		linear_nav.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
			    @Override
			    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
				        int itemId = item.getItemId();
				        View view = linear_nav.findViewById(itemId);
				
				        if (view != null) {
					            view.animate()
					                .scaleX(1.2f)
					                .scaleY(1.2f)
					                .setDuration(150)
					                .withEndAction(() -> 
					                    view.animate()
					                        .scaleX(1f)
					                        .scaleY(1f)
					                        .setDuration(150)
					                ).start();
					        }
				
				        if (itemId == R.id.nav_home) {
					            viewPager.setCurrentItem((int)0);
					            return true;
					        } else if (itemId == R.id.nav_search) {
					            viewPager.setCurrentItem((int)1);
					            return true;
					        } else if (itemId == R.id.nav_list) {
					            viewPager.setCurrentItem((int)2);
					            return true;
					        } else {
					            return false;
					        }
				    }
		});
		
		// Start: "Manage navigation bar blur"
		if (save.getString("blur", "").equals("on")) {
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							float radius = 5f;
							View decorView = getWindow().getDecorView();
							ViewGroup rootView = decorView.findViewById(android.R.id.content);
							Drawable windowBackground = getWindow().getDecorView().getBackground();
							
							if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
								    
							} else {
								    linear_nav_body.setCardBackgroundColor(Color.TRANSPARENT);
								    linear_nav.setBackground(null);
								    linear_nav.setBackgroundColor(Color.TRANSPARENT);
								    blur2inside.setupWith(rootView)
								        .setFrameClearDrawable(windowBackground)
								        .setBlurRadius(radius)
								        .setBlurEnabled(true);
							}
						}
					});
				}
			};
			_timer.scheduleAtFixedRate(timer, (int)(0), (int)(100));
		}
		//End: "Manage navigation bar blur"
		//End: "Material 3 floating rounded bottom navigation bar."
		// Start: "Mode Check"
		loader = new FasterM3BottomSheetLoader(DashboardActivity.this);
		loader.setCancelableOnOutsideClick(false);
		loader.show("Checking data");
		if (save.getString("authentication", "").equals("yes")) {
			checkProReqMap = new HashMap<>(); 
			checkProReqMap.put("apikey", getString(R.string.database_api_key));
			checkPro.setHeaders(checkProReqMap);
			checkPro.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", ""), "", _checkPro_request_listener);
			checkSecurity.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + getString(R.string.AppModeTableName) + "?apikey=" + getString(R.string.database_api_key), "A", _checkSecurity_request_listener);
		} else {
			errorIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
			errorIntent.putExtra("activity name", "login");
			ActivityOptions errorIntentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
			startActivity(errorIntent, errorIntentOp.toBundle());

			finish();
		}
		//End: "Mode Check"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				finishAffinity();
			}
		});

		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(DashboardActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
	public void _detailsUpdate() {
		MaterialAlertDialogBuilder notificationDialog = new MaterialAlertDialogBuilder(DashboardActivity.this);
		notificationDialog.setTitle("Details update need!");
		notificationDialog.setMessage("You need to update some details. Click the update button below.");
		notificationDialog.setPositiveButton("Update", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				        FasterM3BottomSheetLoader updateDetailsLoader = new FasterM3BottomSheetLoader(DashboardActivity.this);
				updateDetailsLoader.setCancelableOnOutsideClick(false);
				updateDetailsLoader.show("Details updating....");
				DetailsRqMap = new Gson().fromJson("{" + "\"" + "notification token" + "\":\"" + save.getString("notification token", "") + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(DetailsRqMap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                updateDetailsLoader.dismiss();
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    updateDetailsLoader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(viewPager, "Update successful!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    updateDetailsLoader.dismiss();
									                }
								            });
							        }
						    }
				});
				    }
		});
		notificationDialog.setCancelable(false);
		notificationDialog.create().show();
	}
	
}
