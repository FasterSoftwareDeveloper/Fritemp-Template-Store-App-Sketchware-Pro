package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.card.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.slider.Slider;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import com.google.android.material.shape.ShapeAppearanceModel;
import androidx.core.content.ContextCompat;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;


public class RechargeActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
RealTimeNetworkHelper networkHelper;

private FasterM3BottomSheetLoader loader;
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> addHistoryHeadersMap = new HashMap<>();
	private HashMap<String, Object> addHistoryValueMap = new HashMap<>();
	private String keyGenerator = "";
	private boolean idCheck = false;
	private HashMap<String, Object> getDataMap = new HashMap<>();
	private HashMap<String, Object> getDataMap2 = new HashMap<>();
	private HashMap<String, Object> getDataMap3 = new HashMap<>();
	private HashMap<String, Object> checkReqMap = new HashMap<>();
	private HashMap<String, Object> checkMap = new HashMap<>();
	private HashMap<String, Object> notification_map = new HashMap<>();
	private String accessTokenError = "";
	private String accessToken = "";
	private String onError = "";
	private String onSuccess = "";
	private String ProjectID = "";
	
	private ArrayList<HashMap<String, Object>> rechargeSuccessListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> checkListMap = new ArrayList<>();
	
	private NestedScrollView vscroll1;
	private LinearLayout linear_main;
	private RelativeLayout relativelayout2;
	private MaterialCardView linear_top;
	private RelativeLayout relativelayout1;
	private LinearLayout linear_payment_body;
	private LinearLayout linear93;
	private MaterialCardView linear92;
	private TextView textview_balance;
	private MaterialCardView img;
	private ImageView img_main;
	private MaterialCardView important_note;
	private MaterialCardView linear_id;
	private TextInputLayout textinputlayout_yourName;
	private MaterialCardView linear_total;
	private MaterialButton button1;
	private MaterialButtonToggleGroup linear_selection;
	private RecyclerView recyclerview_pending;
	private RecyclerView recyclerview_success;
	private RecyclerView recyclerview_reject;
	private LinearLayout linear65;
	private LinearLayout linear64;
	private LinearLayout linear63;
	private ImageView imageview22;
	private TextView textview17;
	private TextView textview18;
	private LinearLayout linear91;
	private TextView textview20;
	private ImageView imageview23;
	private TextInputEditText edittext_yourName;
	private LinearLayout linear89;
	private Slider seekbar1;
	private LinearLayout linear9;
	private TextView textview16;
	private LinearLayout linear10;
	private TextView total_txt;
	private TextView textview19;
	private MaterialButton button_pending;
	private MaterialButton button5;
	private MaterialButton button6;
	
	private Intent backIntent = new Intent();
	private SharedPreferences save;
	private RequestNetwork rq_history;
	private RequestNetwork.RequestListener _rq_history_request_listener;
	private Calendar date = Calendar.getInstance();
	private TimerTask timer;
	private RequestNetwork getData;
	private RequestNetwork.RequestListener _getData_request_listener;
	private AlertDialog.Builder dialog;
	private RequestNetwork rq_data2;
	private RequestNetwork.RequestListener _rq_data2_request_listener;
	private RequestNetwork check_rq;
	private RequestNetwork.RequestListener _check_rq_request_listener;
	private Intent secureIntent = new Intent();
	private Intent errorIntent = new Intent();
	private AlertDialog.Builder errorDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.recharge);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear_main = findViewById(R.id.linear_main);
		relativelayout2 = findViewById(R.id.relativelayout2);
		linear_top = findViewById(R.id.linear_top);
		relativelayout1 = findViewById(R.id.relativelayout1);
		linear_payment_body = findViewById(R.id.linear_payment_body);
		linear93 = findViewById(R.id.linear93);
		linear92 = findViewById(R.id.linear92);
		textview_balance = findViewById(R.id.textview_balance);
		img = findViewById(R.id.img);
		img_main = findViewById(R.id.img_main);
		important_note = findViewById(R.id.important_note);
		linear_id = findViewById(R.id.linear_id);
		textinputlayout_yourName = findViewById(R.id.textinputlayout_yourName);
		linear_total = findViewById(R.id.linear_total);
		button1 = findViewById(R.id.button1);
		linear_selection = findViewById(R.id.linear_selection);
		recyclerview_pending = findViewById(R.id.recyclerview_pending);
		recyclerview_success = findViewById(R.id.recyclerview_success);
		recyclerview_reject = findViewById(R.id.recyclerview_reject);
		linear65 = findViewById(R.id.linear65);
		linear64 = findViewById(R.id.linear64);
		linear63 = findViewById(R.id.linear63);
		imageview22 = findViewById(R.id.imageview22);
		textview17 = findViewById(R.id.textview17);
		textview18 = findViewById(R.id.textview18);
		linear91 = findViewById(R.id.linear91);
		textview20 = findViewById(R.id.textview20);
		imageview23 = findViewById(R.id.imageview23);
		edittext_yourName = findViewById(R.id.edittext_yourName);
		linear89 = findViewById(R.id.linear89);
		seekbar1 = findViewById(R.id.seekbar1);
		linear9 = findViewById(R.id.linear9);
		textview16 = findViewById(R.id.textview16);
		linear10 = findViewById(R.id.linear10);
		total_txt = findViewById(R.id.total_txt);
		textview19 = findViewById(R.id.textview19);
		button_pending = findViewById(R.id.button_pending);
		button5 = findViewById(R.id.button5);
		button6 = findViewById(R.id.button6);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		rq_history = new RequestNetwork(this);
		getData = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		rq_data2 = new RequestNetwork(this);
		check_rq = new RequestNetwork(this);
		errorDialog = new AlertDialog.Builder(this);
		
		linear_id.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FasterUtils.copyToClipboard(RechargeActivity.this, "", "3633773655");
				com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "Copy successful!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (idCheck) {
					if (total_txt.getText().toString().equals("0.00")) {
						com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "minimum $0.20 recharge!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					} else {
						loader.show("sending your request....");
						date = Calendar.getInstance();
						keyGenerator = "hiSToRy".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(100000), (int)(9000000)))));
						addHistoryValueMap = new HashMap<>();
						addHistoryHeadersMap = new HashMap<>();
						addHistoryHeadersMap.put("apikey", getString(R.string.database_api_key));
						addHistoryHeadersMap.put("Content-Type", "application/json");
						addHistoryValueMap.put("key", keyGenerator);
						addHistoryValueMap.put("user uid", save.getString("user id", ""));
						addHistoryValueMap.put("id", edittext_yourName.getText().toString());
						addHistoryValueMap.put("money", total_txt.getText().toString());
						addHistoryValueMap.put("status", "pending");
						addHistoryValueMap.put("date", new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a").format(date.getTime()));
						rq_history.setHeaders(addHistoryHeadersMap); rq_history.setParams(addHistoryValueMap, RequestNetworkController.REQUEST_PARAM); rq_history.startRequestNetwork(RequestNetworkController.POST, getString(R.string.database_url) + "/rest/v1/" + "history", "A", _rq_history_request_listener);
						_FasterNotificationSender("New recharge request!", "Deposit id: ".concat(keyGenerator), "", "", "admin", "", "");
					}
				}
			}
		});
		
		edittext_yourName.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinputlayout_yourName.setErrorEnabled(true);
					textinputlayout_yourName.setError("Please enter your transaction id!");
					idCheck = false;
				} else {
					textinputlayout_yourName.setErrorEnabled(false);
					idCheck = false;
					if (_charSeq.contains(" ")) {
						textinputlayout_yourName.setErrorEnabled(true);
						textinputlayout_yourName.setError("Speed cannot be given!");
						idCheck = false;
					} else {
						textinputlayout_yourName.setErrorEnabled(false);
						idCheck = true;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button_pending.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				recyclerview_pending.setVisibility(View.VISIBLE);
				recyclerview_success.setVisibility(View.GONE);
				recyclerview_reject.setVisibility(View.GONE);
				_TransitionManager(linear_payment_body, 300);
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				recyclerview_pending.setVisibility(View.GONE);
				recyclerview_success.setVisibility(View.VISIBLE);
				recyclerview_reject.setVisibility(View.GONE);
				_TransitionManager(linear_payment_body, 300);
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				recyclerview_pending.setVisibility(View.GONE);
				recyclerview_success.setVisibility(View.GONE);
				recyclerview_reject.setVisibility(View.VISIBLE);
				_TransitionManager(linear_payment_body, 300);
			}
		});
		
		_rq_history_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					if (_tag.equals("A")) {
						if (_response.equals("[]")) {
								loader.dismiss();
							secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
							secureIntent.putExtra("activity name", "others");
							ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(RechargeActivity.this, R.anim.fade_in, R.anim.fade_out);
							startActivity(secureIntent, secureIntentOp.toBundle());

							finish();
						} else {
								loader.dismiss();
							timer = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											getDataMap2 = new HashMap<>(); 
											getDataMap2.put("apikey", getString(R.string.database_api_key));
											getData.setHeaders(getDataMap2);
											getData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + save.getString("user id", "") + "&", "B", _getData_request_listener);
											timer.cancel();
										}
									});
								}
							};
							_timer.schedule(timer, (int)(500));
						}
					}
					if (_tag.equals("B")) {
						rechargeSuccessListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						Collections.reverse(rechargeSuccessListMap);
						recyclerview_pending.setAdapter(new Recyclerview_pendingAdapter(rechargeSuccessListMap));
						recyclerview_success.setAdapter(new Recyclerview_successAdapter(rechargeSuccessListMap));
						recyclerview_reject.setAdapter(new Recyclerview_rejectAdapter(rechargeSuccessListMap));
						loader.dismiss();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_getData_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					rechargeSuccessListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					Collections.reverse(rechargeSuccessListMap);
					recyclerview_pending.setAdapter(new Recyclerview_pendingAdapter(rechargeSuccessListMap));
					recyclerview_success.setAdapter(new Recyclerview_successAdapter(rechargeSuccessListMap));
					recyclerview_reject.setAdapter(new Recyclerview_rejectAdapter(rechargeSuccessListMap));
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_rq_data2_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					rechargeSuccessListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					Collections.reverse(rechargeSuccessListMap);
					recyclerview_pending.setAdapter(new Recyclerview_pendingAdapter(rechargeSuccessListMap));
					recyclerview_success.setAdapter(new Recyclerview_successAdapter(rechargeSuccessListMap));
					recyclerview_reject.setAdapter(new Recyclerview_rejectAdapter(rechargeSuccessListMap));
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_check_rq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					checkListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					checkMap = checkListMap.get((int)0);
					textview_balance.setText(checkMap.get("deposit balance").toString().concat("$"));
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), SettingsActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(RechargeActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});

		// Start: "setup"
		ShapeAppearanceModel shapeAppearanceModel = new ShapeAppearanceModel.Builder()
		    .setTopLeftCornerSize(0f)
		    .setTopRightCornerSize(0f)
		    .setBottomLeftCornerSize(150f)
		    .setBottomRightCornerSize(150f)
		    .build();
		linear_top.setShapeAppearanceModel(shapeAppearanceModel);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			   getWindow().setStatusBarColor(getResources().getColor(R.color.oneitemViewBgColor, getTheme()));
		}
		seekbar1.addOnChangeListener(new Slider.OnChangeListener() {
			    @Override
			    public void onValueChange(@NonNull Slider slider, float value, boolean fromUser) {
				total_txt.setText(new DecimalFormat("0.00").format(value));
				    }
		});
		relativelayout1.setElevation((float)3);
		recyclerview_success.setVisibility(View.GONE);
		recyclerview_reject.setVisibility(View.GONE);
		recyclerview_pending.setLayoutManager(new LinearLayoutManager(this));
		recyclerview_success.setLayoutManager(new LinearLayoutManager(this));
		recyclerview_reject.setLayoutManager(new LinearLayoutManager(this));
		//End: "setup"
		// Start: "Loader"
		loader = new FasterM3BottomSheetLoader(RechargeActivity.this);
		loader.setCancelableOnOutsideClick(false);
		loader.show("Requesting data....");
		//End: "Loader"
		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_pending, OverScrollDecoratorHelper.ORIENTATION_VERTICAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_reject, OverScrollDecoratorHelper.ORIENTATION_VERTICAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_success, OverScrollDecoratorHelper.ORIENTATION_VERTICAL);
			}
		}
		//End: "over scroll checker"
		// Start: "Request network"
		if (save.getString("authentication", "").equals("yes")) {
			getDataMap = new HashMap<>(); 
			getDataMap.put("apikey", getString(R.string.database_api_key));
			rq_history.setHeaders(getDataMap);
			rq_history.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + save.getString("user id", "") + "&", "B", _rq_history_request_listener);
			checkReqMap = new HashMap<>(); 
			checkReqMap.put("apikey", getString(R.string.database_api_key));
			check_rq.setHeaders(checkReqMap);
			check_rq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&", "", _check_rq_request_listener);
		} else {
			errorIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
			errorIntent.putExtra("activity name", "login");
			ActivityOptions errorIntentOp = ActivityOptions.makeCustomAnimation(RechargeActivity.this, R.anim.fade_in, R.anim.fade_out);
			startActivity(errorIntent, errorIntentOp.toBundle());

			finish();
		}
		//End: "Request network"
		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(RechargeActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(RechargeActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
		// Start: "Access an token"
		try {
			    try (InputStream originalInputStream = getAssets().open("service-account.json")) {
				        byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
					            HashMap<String, Object> map = new Gson().fromJson(
					                jsonString,
					                new TypeToken<HashMap<String, Object>>(){}.getType()
					            );
					            ProjectID = map.get("project_id").toString();
					        }
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.OnTokenResponse() {
						                @Override
						                public void onSuccess(String token) {
							                    JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
							                    if (jsonResponse.has("access_token")) {
								                        accessToken = jsonResponse.get("access_token").getAsString();
								                    } else {
								                        accessToken = "error getting accessToken";
								                    }
							                }
						
						                @Override
						                public void onError(String error) {
							                    accessTokenError = error;
							                    runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
							                }
						            });
					        }
				    } catch (IOException e) {
				        accessTokenError = "Error reading service account file: " + e.getMessage();
				        runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
				    }
		} catch (Exception e) {
			    runOnUiThread(() -> _m3ErrorDialog("Unexpected error: " + e.getMessage()));
		}
		//End: "Access an token"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _FasterNotificationSender(final String _title, final String _body, final String _imageUrl, final String _contextactivity, final String _topic, final String _token, final String _extraText) {
		notification_map = new HashMap<>();
		notification_map.put("title", _title);
		notification_map.put("body", _body);
		if (!_imageUrl.equals("")) {
			notification_map.put("image", _imageUrl);
		}
		if (!_extraText.equals("")) {
			notification_map.put("extraData", _extraText);
		}
		if (!_contextactivity.equals("")) {
			notification_map.put("ContextActivity", _contextactivity);
		}
		if (_token.equals("")) {
			// Start: "Send notification with topic"
			    String topic = _topic;
			    String token = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with topic"
		} else {
			// Start: "Send notification with token"
			    String token = _token;
			    String topic = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with token"
		}
	}
	
	
	public void _m3ErrorDialog(final String _massage) {
		MaterialAlertDialogBuilder errorDialog = new MaterialAlertDialogBuilder(RechargeActivity.this);
		errorDialog.setTitle("Error!");
		errorDialog.setMessage(_massage);
		errorDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		errorDialog.setCancelable(true);
		errorDialog.create().show();
	}
	
	public class Recyclerview_pendingAdapter extends RecyclerView.Adapter<Recyclerview_pendingAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_pendingAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.recharge_history, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("pending")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("money")) {
						money.setText("-".concat(_data.get((int)_position).get("money").toString().concat("$")));
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("key")) {
						name.setText(_data.get((int)_position).get("key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_primary));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (_data.get((int)_position).containsKey("key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(RechargeActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=eq." + _data.get((int)_position).get("key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															getDataMap3 = new HashMap<>(); 
															getDataMap3.put("apikey", getString(R.string.database_api_key));
															rq_data2.setHeaders(getDataMap3);
															rq_data2.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + save.getString("user id", "") + "&", "B", _rq_data2_request_listener);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(RechargeActivity.this, "", _data.get((int)_position).get("key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_successAdapter extends RecyclerView.Adapter<Recyclerview_successAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_successAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.recharge_history, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("success")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("money")) {
						money.setText("+".concat(_data.get((int)_position).get("money").toString().concat("$")));
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("key")) {
						name.setText(_data.get((int)_position).get("key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(Color.parseColor("#4caf50"));
					money.setTextColor(Color.parseColor("#4caf50"));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (_data.get((int)_position).containsKey("key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(RechargeActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=eq." + _data.get((int)_position).get("key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															getDataMap3 = new HashMap<>(); 
															getDataMap3.put("apikey", getString(R.string.database_api_key));
															rq_data2.setHeaders(getDataMap3);
															rq_data2.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + save.getString("user id", "") + "&", "B", _rq_data2_request_listener);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(RechargeActivity.this, "", _data.get((int)_position).get("key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_rejectAdapter extends RecyclerView.Adapter<Recyclerview_rejectAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_rejectAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.recharge_history, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("rejected")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("money")) {
						money.setText("-".concat(_data.get((int)_position).get("money").toString().concat("$")));
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("key")) {
						name.setText(_data.get((int)_position).get("key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(Color.parseColor("#f44336"));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (_data.get((int)_position).containsKey("key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(RechargeActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=eq." + _data.get((int)_position).get("key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															getDataMap3 = new HashMap<>(); 
															getDataMap3.put("apikey", getString(R.string.database_api_key));
															rq_data2.setHeaders(getDataMap3);
															rq_data2.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + save.getString("user id", "") + "&", "B", _rq_data2_request_listener);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear_payment_body, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(RechargeActivity.this, "", _data.get((int)_position).get("key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}
