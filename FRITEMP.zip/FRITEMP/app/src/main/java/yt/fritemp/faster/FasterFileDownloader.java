package yt.fritemp.faster;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class FasterFileDownloader {

    private final Context context;
    private OnDownloadListener downloadListener;

    private static final String CHANNEL_ID = "download_channel";
    private static final int NOTIFICATION_ID = 101;

    public interface OnDownloadListener {
        void onProgress(int percent);
        void onSuccess(String savedFilePath);
        void onError(String reason);
    }

    public FasterFileDownloader(Context context) {
        this.context = context;
        createNotificationChannel();
    }

    public void setOnDownloadListener(OnDownloadListener listener) {
        this.downloadListener = listener;
    }

    public void startDownload(String fileUrl, String fileNameWithExtension) {
        File downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (downloadsDir == null) {
            postError("Storage not available");
            return;
        }

        File outputFile = new File(downloadsDir, fileNameWithExtension);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setContentTitle("Downloading")
                .setContentText("Download in progress")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true)
                .setProgress(100, 0, false);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        notificationManager.notify(NOTIFICATION_ID, builder.build());

        new Thread(() -> {
            try {
                URL url = new URL(fileUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                int fileLength = connection.getContentLength();
                InputStream input = new BufferedInputStream(connection.getInputStream());
                FileOutputStream output = new FileOutputStream(outputFile);

                byte[] buffer = new byte[4096];
                int total = 0;
                int count;
                while ((count = input.read(buffer)) != -1) {
                    total += count;
                    output.write(buffer, 0, count);
                    int percent = (int) ((total * 100L) / fileLength);
                    postProgress(percent);

                    builder.setProgress(100, percent, false)
                            .setContentText("Downloading... " + percent + "%");
                    notificationManager.notify(NOTIFICATION_ID, builder.build());
                }

                output.flush();
                output.close();
                input.close();
                connection.disconnect();

                notificationManager.cancel(NOTIFICATION_ID);

                NotificationCompat.Builder completeBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setContentTitle("Download Complete")
                        .setContentText("Saved to: " + outputFile.getName())
                        .setSmallIcon(android.R.drawable.stat_sys_download_done)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                notificationManager.notify(NOTIFICATION_ID + 1, completeBuilder.build());

                postSuccess(outputFile.getAbsolutePath());

            } catch (Exception e) {
                e.printStackTrace();
                notificationManager.cancel(NOTIFICATION_ID);

                NotificationCompat.Builder failedBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setContentTitle("Download Failed")
                        .setContentText(e.getMessage())
                        .setSmallIcon(android.R.drawable.stat_notify_error)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

                notificationManager.notify(NOTIFICATION_ID + 2, failedBuilder.build());

                postError("Download failed: " + e.getMessage());
            }
        }).start();
    }

    private void postSuccess(String path) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (downloadListener != null) downloadListener.onSuccess(path);
        });
    }

    private void postError(String error) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (downloadListener != null) downloadListener.onError(error);
        });
    }

    private void postProgress(int progress) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (downloadListener != null) downloadListener.onProgress(progress);
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Download Progress";
            String description = "Shows file download status";
            int importance = NotificationManager.IMPORTANCE_LOW;

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}
