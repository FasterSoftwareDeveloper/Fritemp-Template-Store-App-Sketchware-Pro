package yt.fritemp.faster;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.*;
import com.google.android.material.card.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.*;
import androidx.core.content.ContextCompat;


public class SettingsActivity extends AppCompatActivity {

private FasterM3BottomSheetLoader loader;
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
RealTimeNetworkHelper networkHelper;
	
	private boolean ss3 = false;
	private boolean ss1 = false;
	private boolean ss = false;
	private HashMap<String, Object> getDataMap = new HashMap<>();
	private HashMap<String, Object> ShowDataMap = new HashMap<>();
	private String modes = "";
	private HashMap<String, Object> password_checkMap = new HashMap<>();
	private HashMap<String, Object> passwordChangerMap = new HashMap<>();
	private HashMap<String, Object> updatePasswordErrorRessMap = new HashMap<>();
	private HashMap<String, Object> updatePasswordMap = new HashMap<>();
	private HashMap<String, Object> emailChangerMap = new HashMap<>();
	private HashMap<String, Object> emailCheckerMap = new HashMap<>();
	private HashMap<String, Object> questionCheckMap2 = new HashMap<>();
	private HashMap<String, Object> questionCheckMap1 = new HashMap<>();
	private HashMap<String, Object> updateEmailMap = new HashMap<>();
	private HashMap<String, Object> updateEmailErrorMap = new HashMap<>();
	private HashMap<String, Object> getRefreshTokenResponse = new HashMap<>();
	private HashMap<String, Object> getRefreshTokenErrorResponse = new HashMap<>();
	private String passwordStr = "";
	private String emailStr = "";
	private String signOut = "";
	private HashMap<String, Object> checkProReqMap = new HashMap<>();
	private HashMap<String, Object> getProDataMap = new HashMap<>();
	private String account_type = "";
	private HashMap<String, Object> updateProData = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> ShowDataListmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> getProDataListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private MaterialButton button1;
	private TextView textview1;
	private LinearLayout linear12;
	private LinearLayout linear2;
	private MaterialCardView linear_box10;
	private MaterialCardView linear_box13;
	private MaterialCardView linear_box14;
	private TextView textview7;
	private MaterialCardView linear_box3;
	private MaterialCardView linear_box4;
	private MaterialCardView linear_box12;
	private MaterialCardView linear_box5;
	private MaterialCardView linear_box6;
	private MaterialCardView linear_box7;
	private MaterialCardView linear_box8;
	private MaterialCardView linear_box2;
	private TextView textview2;
	private MaterialCardView linear_box1;
	private LinearLayout linear11;
	private LinearLayout linear_bordar1;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private MaterialCardView linear_round;
	private ImageView imageview_profile_icon;
	private TextView account_name;
	private TextView textview6;
	private MaterialButton button3;
	private LinearLayout linear74;
	private LinearLayout linear75;
	private LinearLayout linear76;
	private LinearLayout linear77;
	private ImageView imageview17;
	private TextView textview32;
	private TextView textview33;
	private MaterialButton button16;
	private LinearLayout linear84;
	private LinearLayout linear85;
	private LinearLayout linear86;
	private LinearLayout linear87;
	private ImageView imageview19;
	private TextView textview36;
	private TextView textview37;
	private MaterialButton button17;
	private LinearLayout linear89;
	private LinearLayout linear90;
	private LinearLayout linear91;
	private LinearLayout linear92;
	private ImageView imageview20;
	private TextView textview38;
	private TextView textview39;
	private MaterialButton button18;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private ImageView imageview7;
	private TextView textview12;
	private TextView textview13;
	private MaterialButton button6;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private ImageView imageview8;
	private TextView textview14;
	private TextView textview15;
	private LinearLayout linear_blur_bg;
	private LinearLayout linear_blur_thumb;
	private LinearLayout linear_sd1;
	private LinearLayout linear79;
	private LinearLayout linear80;
	private LinearLayout linear81;
	private LinearLayout linear82;
	private ImageView imageview18;
	private TextView textview34;
	private TextView textview35;
	private LinearLayout switch_switch_bg;
	private LinearLayout switch_thumb3;
	private LinearLayout SD4;
	private LinearLayout linear34;
	private LinearLayout linear35;
	private LinearLayout linear36;
	private LinearLayout linear37;
	private ImageView imageview9;
	private TextView textview16;
	private TextView textview17;
	private MaterialButton button8;
	private LinearLayout linear39;
	private LinearLayout linear40;
	private LinearLayout linear41;
	private LinearLayout linear42;
	private ImageView imageview10;
	private TextView textview18;
	private TextView textview19;
	private MaterialButton button9;
	private LinearLayout linear49;
	private LinearLayout linear50;
	private LinearLayout linear51;
	private LinearLayout linear52;
	private ImageView imageview12;
	private TextView textview22;
	private TextView textview23;
	private MaterialButton button11;
	private LinearLayout linear54;
	private LinearLayout linear55;
	private LinearLayout linear56;
	private LinearLayout linear57;
	private ImageView imageview13;
	private TextView textview24;
	private TextView textview25;
	private MaterialButton button12;
	private LinearLayout linear19;
	private LinearLayout linear_bordar2;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private ImageView imageview6;
	private TextView textview10;
	private TextView textview11;
	private MaterialButton button5;
	
	private ObjectAnimator animation3 = new ObjectAnimator();
	private SharedPreferences save;
	private AlertDialog.Builder restartDialog;
	private Intent restartIntent = new Intent();
	private ObjectAnimator animation1 = new ObjectAnimator();
	private Intent privacy = new Intent();
	private Intent channelIntent = new Intent();
	private Intent aboutIntent = new Intent();
	private AlertDialog.Builder securityDialog;
	private Intent backIntent = new Intent();
	private RequestNetwork getData;
	private RequestNetwork.RequestListener _getData_request_listener;
	private AlertDialog.Builder DeleteDialog;
	private Intent intentRest = new Intent();
	private Intent intentRecharge = new Intent();
	private RequestNetwork checkPro;
	private RequestNetwork.RequestListener _checkPro_request_listener;
	private Calendar get_date = Calendar.getInstance();
	private Intent secureIntent = new Intent();
	private Intent historyIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		vscroll1 = findViewById(R.id.vscroll1);
		button1 = findViewById(R.id.button1);
		textview1 = findViewById(R.id.textview1);
		linear12 = findViewById(R.id.linear12);
		linear2 = findViewById(R.id.linear2);
		linear_box10 = findViewById(R.id.linear_box10);
		linear_box13 = findViewById(R.id.linear_box13);
		linear_box14 = findViewById(R.id.linear_box14);
		textview7 = findViewById(R.id.textview7);
		linear_box3 = findViewById(R.id.linear_box3);
		linear_box4 = findViewById(R.id.linear_box4);
		linear_box12 = findViewById(R.id.linear_box12);
		linear_box5 = findViewById(R.id.linear_box5);
		linear_box6 = findViewById(R.id.linear_box6);
		linear_box7 = findViewById(R.id.linear_box7);
		linear_box8 = findViewById(R.id.linear_box8);
		linear_box2 = findViewById(R.id.linear_box2);
		textview2 = findViewById(R.id.textview2);
		linear_box1 = findViewById(R.id.linear_box1);
		linear11 = findViewById(R.id.linear11);
		linear_bordar1 = findViewById(R.id.linear_bordar1);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear_round = findViewById(R.id.linear_round);
		imageview_profile_icon = findViewById(R.id.imageview_profile_icon);
		account_name = findViewById(R.id.account_name);
		textview6 = findViewById(R.id.textview6);
		button3 = findViewById(R.id.button3);
		linear74 = findViewById(R.id.linear74);
		linear75 = findViewById(R.id.linear75);
		linear76 = findViewById(R.id.linear76);
		linear77 = findViewById(R.id.linear77);
		imageview17 = findViewById(R.id.imageview17);
		textview32 = findViewById(R.id.textview32);
		textview33 = findViewById(R.id.textview33);
		button16 = findViewById(R.id.button16);
		linear84 = findViewById(R.id.linear84);
		linear85 = findViewById(R.id.linear85);
		linear86 = findViewById(R.id.linear86);
		linear87 = findViewById(R.id.linear87);
		imageview19 = findViewById(R.id.imageview19);
		textview36 = findViewById(R.id.textview36);
		textview37 = findViewById(R.id.textview37);
		button17 = findViewById(R.id.button17);
		linear89 = findViewById(R.id.linear89);
		linear90 = findViewById(R.id.linear90);
		linear91 = findViewById(R.id.linear91);
		linear92 = findViewById(R.id.linear92);
		imageview20 = findViewById(R.id.imageview20);
		textview38 = findViewById(R.id.textview38);
		textview39 = findViewById(R.id.textview39);
		button18 = findViewById(R.id.button18);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		linear26 = findViewById(R.id.linear26);
		linear27 = findViewById(R.id.linear27);
		imageview7 = findViewById(R.id.imageview7);
		textview12 = findViewById(R.id.textview12);
		textview13 = findViewById(R.id.textview13);
		button6 = findViewById(R.id.button6);
		linear29 = findViewById(R.id.linear29);
		linear30 = findViewById(R.id.linear30);
		linear31 = findViewById(R.id.linear31);
		linear32 = findViewById(R.id.linear32);
		imageview8 = findViewById(R.id.imageview8);
		textview14 = findViewById(R.id.textview14);
		textview15 = findViewById(R.id.textview15);
		linear_blur_bg = findViewById(R.id.linear_blur_bg);
		linear_blur_thumb = findViewById(R.id.linear_blur_thumb);
		linear_sd1 = findViewById(R.id.linear_sd1);
		linear79 = findViewById(R.id.linear79);
		linear80 = findViewById(R.id.linear80);
		linear81 = findViewById(R.id.linear81);
		linear82 = findViewById(R.id.linear82);
		imageview18 = findViewById(R.id.imageview18);
		textview34 = findViewById(R.id.textview34);
		textview35 = findViewById(R.id.textview35);
		switch_switch_bg = findViewById(R.id.switch_switch_bg);
		switch_thumb3 = findViewById(R.id.switch_thumb3);
		SD4 = findViewById(R.id.SD4);
		linear34 = findViewById(R.id.linear34);
		linear35 = findViewById(R.id.linear35);
		linear36 = findViewById(R.id.linear36);
		linear37 = findViewById(R.id.linear37);
		imageview9 = findViewById(R.id.imageview9);
		textview16 = findViewById(R.id.textview16);
		textview17 = findViewById(R.id.textview17);
		button8 = findViewById(R.id.button8);
		linear39 = findViewById(R.id.linear39);
		linear40 = findViewById(R.id.linear40);
		linear41 = findViewById(R.id.linear41);
		linear42 = findViewById(R.id.linear42);
		imageview10 = findViewById(R.id.imageview10);
		textview18 = findViewById(R.id.textview18);
		textview19 = findViewById(R.id.textview19);
		button9 = findViewById(R.id.button9);
		linear49 = findViewById(R.id.linear49);
		linear50 = findViewById(R.id.linear50);
		linear51 = findViewById(R.id.linear51);
		linear52 = findViewById(R.id.linear52);
		imageview12 = findViewById(R.id.imageview12);
		textview22 = findViewById(R.id.textview22);
		textview23 = findViewById(R.id.textview23);
		button11 = findViewById(R.id.button11);
		linear54 = findViewById(R.id.linear54);
		linear55 = findViewById(R.id.linear55);
		linear56 = findViewById(R.id.linear56);
		linear57 = findViewById(R.id.linear57);
		imageview13 = findViewById(R.id.imageview13);
		textview24 = findViewById(R.id.textview24);
		textview25 = findViewById(R.id.textview25);
		button12 = findViewById(R.id.button12);
		linear19 = findViewById(R.id.linear19);
		linear_bordar2 = findViewById(R.id.linear_bordar2);
		linear21 = findViewById(R.id.linear21);
		linear22 = findViewById(R.id.linear22);
		imageview6 = findViewById(R.id.imageview6);
		textview10 = findViewById(R.id.textview10);
		textview11 = findViewById(R.id.textview11);
		button5 = findViewById(R.id.button5);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		restartDialog = new AlertDialog.Builder(this);
		securityDialog = new AlertDialog.Builder(this);
		getData = new RequestNetwork(this);
		DeleteDialog = new AlertDialog.Builder(this);
		checkPro = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				backIntent.setClass(getApplicationContext(), DashboardActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});
		
		linear_box10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				backIntent.setClass(getApplicationContext(), PlanActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});
		
		linear_box13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intentRecharge.setClass(getApplicationContext(), RechargeActivity.class);
				ActivityOptions intentRechargeOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(intentRecharge, intentRechargeOp.toBundle());

				finish();
			}
		});
		
		linear_box14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				historyIntent.setClass(getApplicationContext(), TemplateHistoryActivity.class);
				ActivityOptions historyIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(historyIntent, historyIntentOp.toBundle());

				finish();
			}
		});
		
		linear_box3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MaterialAlertDialogBuilder securityDialog = new MaterialAlertDialogBuilder(SettingsActivity.this);
				securityDialog.setTitle("Action");
				View securityDialogDesign = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.security_dialog, null);
				securityDialog.setView(securityDialogDesign);

				final MaterialCardView linear_password_box = securityDialogDesign.findViewById(R.id.linear_password_box);
				final MaterialCardView linear_email_box = securityDialogDesign.findViewById(R.id.linear_email_box);
				final MaterialCardView linear_delete_box = securityDialogDesign.findViewById(R.id.linear_delete_box);
				androidx.appcompat.app.AlertDialog dialog = securityDialog.create();
				linear_password_box.setOnClickListener(v -> {
					_security_dialog2(true);
					dialog.dismiss();
				});
				linear_email_box.setOnClickListener(v -> {
					_security_dialog2(false);
					dialog.dismiss();
				});
				linear_delete_box.setOnClickListener(v -> {
					_deleteAccount();
					dialog.dismiss();
				});
				dialog.setCancelable(true);
				dialog.show();
			}
		});
		
		linear_box4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_blur_bg.performClick();
			}
		});
		
		linear_box12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				switch_switch_bg.performClick();
			}
		});
		
		linear_box5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final
				com.google.android.material.bottomsheet.BottomSheetDialog themeChanger = new com.google.android.material.bottomsheet.BottomSheetDialog(SettingsActivity.this);
				View themeChangerDesign = getLayoutInflater().inflate(R.layout.theme_changer, null);
				themeChanger.setContentView(themeChangerDesign);
				themeChanger.getWindow().getDecorView().setBackgroundColor(0);
				final MaterialCardView light_theme = themeChangerDesign.findViewById(R.id.light_theme);
				final MaterialCardView dark_theme = themeChangerDesign.findViewById(R.id.dark_theme);
				final LinearLayout SD2 = themeChangerDesign.findViewById(R.id.SD2);
				final LinearLayout switch_thumb = themeChangerDesign.findViewById(R.id.switch_thumb);
				final LinearLayout switch_bg = themeChangerDesign.findViewById(R.id.switch_bg);
				if (save.getString("theme", "").equals("system default")) {
					_switch_on(switch_bg, switch_thumb, SD2);
					switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
					dark_theme.setChecked(false);
					light_theme.setChecked(false);
					light_theme.setEnabled(false);
					dark_theme.setEnabled(false);
					AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
				} else {
					_switch_off(switch_bg, switch_thumb, SD2);
					switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					light_theme.setEnabled(true);
					dark_theme.setEnabled(true);
					int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
					        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
						            light_theme.setChecked(false);
						            dark_theme.setChecked(true);
						        } else if (nightModeFlags == Configuration.UI_MODE_NIGHT_NO) {
						            light_theme.setChecked(true);
						            dark_theme.setChecked(false);
						        } else {
						            light_theme.setChecked(false);
						            dark_theme.setChecked(false);
						        }
				}
				light_theme.setOnClickListener(v -> {
					light_theme.setChecked(true);
					dark_theme.setChecked(false);
					AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
					save.edit().putString("theme", "light").commit();
							        });
				dark_theme.setOnClickListener(v -> {
					light_theme.setChecked(false);
					dark_theme.setChecked(true);
					AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
					save.edit().putString("theme", "dark").commit();
							        });
				switch_bg.setOnClickListener(v -> {
					if (ss) {
						_switch_off(switch_bg, switch_thumb, SD2);
						switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
						light_theme.setEnabled(true);
						dark_theme.setEnabled(true);
						save.edit().putString("theme", "system default").commit();
						int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
						        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
							            light_theme.setChecked(false);
							            dark_theme.setChecked(true);
							        } else if (nightModeFlags == Configuration.UI_MODE_NIGHT_NO) {
							            light_theme.setChecked(true);
							            dark_theme.setChecked(false);
							        } else {
							            light_theme.setChecked(false);
							            dark_theme.setChecked(false);
							        }
					} else {
						_switch_on(switch_bg, switch_thumb, SD2);
						switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
						dark_theme.setChecked(false);
						light_theme.setChecked(false);
						light_theme.setEnabled(false);
						dark_theme.setEnabled(false);
						save.edit().putString("theme", "system default").commit();
						AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
					}
							        });
				themeChanger.setCancelable(true);
				themeChanger.show();
			}
		});
		
		linear_box6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				aboutIntent.setAction(Intent.ACTION_VIEW);
				aboutIntent.setData(Uri.parse(getString(R.string.AbouUrl)));
				startActivity(aboutIntent);
			}
		});
		
		linear_box7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				channelIntent.setAction(Intent.ACTION_VIEW);
				channelIntent.setData(Uri.parse(getString(R.string.channelUrl)));
				startActivity(channelIntent);
			}
		});
		
		linear_box8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				privacy.setAction(Intent.ACTION_VIEW);
				privacy.setData(Uri.parse(getString(R.string.privacyUrl)));
				startActivity(privacy);
			}
		});
		
		linear_box2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FasterM3BottomSheetLoader SignOutLoader = new FasterM3BottomSheetLoader(SettingsActivity.this);
				SignOutLoader.setCancelableOnOutsideClick(false);
				SignOutLoader.show("Connection...");
				try {
					    OkHttpClient client = new OkHttpClient();
					
					    RequestBody body = RequestBody.create(
					        MediaType.parse("application/json"),
					        "{ \"refresh_token\": \"" + save.getString("refresh_token", "") + "\" }"
					    );
					
					    Request request = new Request.Builder()
					        .url(getString(R.string.database_url) + "/auth/v1/token?grant_type=refresh_token")
					        .addHeader("apikey", getString(R.string.database_api_key))
					        .addHeader("Content-Type", "application/json")
					        .post(body)
					        .build();
					
					    client.newCall(request).enqueue(new Callback() {
						@Override
						public void onFailure(Call call, IOException e) {
							final String errorMessage = e.getMessage();
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									SignOutLoader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear12, "Please check your internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								}
							});
						}
						@Override
						public void onResponse(Call call, Response response) throws IOException {
							final boolean isSuccessful = response.isSuccessful();
							final String responseBody = response.body().string();
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (isSuccessful) {
										getRefreshTokenResponse = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
										save.edit().putString("refresh_token", getRefreshTokenResponse.get("refresh_token").toString()).commit();
										save.edit().putString("access_token", getRefreshTokenResponse.get("access_token").toString()).commit();
										try {
											OkHttpClient client = new OkHttpClient();
											
											Request request = new Request.Builder()
											    .url(getString(R.string.database_url) + "/auth/v1/logout")
											    .addHeader("apikey", getString(R.string.database_api_key)) 
											    .addHeader("Authorization", "Bearer " + save.getString("access_token", ""))
											    .post(RequestBody.create(null, "")) 
											    .build();
											
											client.newCall(request).enqueue(new Callback() {
												@Override
												public void onFailure(Call call, IOException e) {
													final String errorMessage = e.getMessage();
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															SignOutLoader.dismiss();
															com.google.android.material.snackbar.Snackbar.make(linear12, "Check your connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
												@Override
												public void onResponse(Call call, Response response) throws IOException {
													final boolean isSuccessful = response.isSuccessful();
													final String responseBody = response.body().string();
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															if (isSuccessful) {
																SignOutLoader.dismiss();
																save.edit().putString("email", "").commit();
																save.edit().putString("password", "").commit();
																save.edit().putString("user id", "").commit();
																save.edit().putString("authentication", "no").commit();
																finishAffinity();
															} else {
																SignOutLoader.dismiss();
																com.google.android.material.snackbar.Snackbar.make(linear12, "Logout request failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																	@Override
																	public void onClick(View _view) {
																		 
																	}
																}).show();
															}
														}
													});
												}
											});
										} catch (Exception e) {
											 
										}
									} else {
										SignOutLoader.dismiss();
										getRefreshTokenErrorResponse = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
										com.google.android.material.snackbar.Snackbar.make(linear12, getRefreshTokenErrorResponse.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
									}
								}
							});
						}
					});
				} catch (Exception e) {
					 
				}
			}
		});
		
		linear_box1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				restartIntent.setClass(getApplicationContext(), ProfileActivity.class);
				ActivityOptions restartIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(restartIntent, restartIntentOp.toBundle());

				finish();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box1.performClick();
			}
		});
		
		button16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box10.performClick();
			}
		});
		
		button17.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box13.performClick();
			}
		});
		
		button18.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box14.performClick();
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box3.performClick();
			}
		});
		
		linear_blur_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
					if (ss1) {
						_switch_off1(linear_blur_bg, linear_blur_thumb, linear_sd1);
						linear_blur_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
						save.edit().putString("blur", "off").commit();
					} else {
						_switch_on1(linear_blur_bg, linear_blur_thumb, linear_sd1);
						linear_blur_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
						save.edit().putString("blur", "on").commit();
					}
				}
			}
		});
		
		switch_switch_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (ss3) {
					_switch_off3(switch_switch_bg, switch_thumb3, SD4);
					switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					save.edit().putString("over scroll", "off").commit();
				} else {
					_switch_on3(switch_switch_bg, switch_thumb3, SD4);
					switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
					save.edit().putString("over scroll", "on").commit();
				}
				MaterialAlertDialogBuilder restartDialog = new MaterialAlertDialogBuilder(SettingsActivity.this);
				restartDialog.setTitle("Restart Required!");
				restartDialog.setMessage("You need to restart the app for the over scroll setting to be applied.");
				restartDialog.setIcon(R.drawable.icon_restart);
				restartDialog.setPositiveButton("Restart", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_dialog.dismiss();
						restartIntent.setClass(getApplicationContext(), MainActivity.class);
						ActivityOptions restartIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
						startActivity(restartIntent, restartIntentOp.toBundle());

						finish();
					}
				});
				restartDialog.setCancelable(false);
				restartDialog.create().show();
			}
		});
		
		button8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box5.performClick();
			}
		});
		
		button9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box6.performClick();
			}
		});
		
		button11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box7.performClick();
			}
		});
		
		button12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box8.performClick();
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_box2.performClick();
			}
		});
		
		_getData_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						loader.dismiss();
					secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
					secureIntent.putExtra("activity name", "re-login");
					ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
					startActivity(secureIntent, secureIntentOp.toBundle());

					finish();
				} else {
						// Start: "List map to map"
					ShowDataListmap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					ShowDataMap = ShowDataListmap.get((int)0);
					//End: "List map to map"
					// Start: "Set data"
					if (ShowDataMap.containsKey("name")) {
						account_name.setText(ShowDataMap.get("name").toString());
					}
					if (ShowDataMap.containsKey("logo url")) {
						if (ShowDataMap.get("logo url").toString().equals("none")) {
							imageview_profile_icon.setImageResource(R.drawable.user_default_icon);
						} else {
							Glide.with(getApplicationContext()).load(Uri.parse(ShowDataMap.get("logo url").toString())).into(imageview_profile_icon);
						}
					}
					//End: "Set data"
					loader.dismiss();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_checkPro_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// Start: "convert json response to map"
				getProDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				getProDataMap = getProDataListMap.get((int)0);
				get_date = Calendar.getInstance();
				if (getProDataMap.get("expired date").toString().equals("none")) {
					account_type = "free";
				} else {
					if (get_date.getTimeInMillis() < Double.parseDouble(getProDataMap.get("expired date").toString())) {
						account_type = "premium";
						linear_box10.setVisibility(View.GONE);
					} else {
						MaterialAlertDialogBuilder wearingDialog = new MaterialAlertDialogBuilder(SettingsActivity.this);
						wearingDialog.setTitle("Warning!");
						wearingDialog.setMessage("The premium you purchased has expired, do you want to buy it again or continue using the app with a free account?");
						wearingDialog.setPositiveButton("Continue & hide warning.", new DialogInterface.OnClickListener() {
							    @Override
							    public void onClick(DialogInterface _dialog, int _which) {
								        updateProData = new Gson().fromJson("{" + "\"" + "account type" + "\":\"" + "free" + "\"," + "\"" + "expired date" + "\":\"" + "none" + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
								OkHttpClient client = new OkHttpClient();
								Request request = new Request.Builder()
								    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
								    .addHeader("apikey", getString(R.string.database_api_key))
								    .patch(RequestBody.create(
								        MediaType.parse("application/json; charset=utf-8"),
								        new Gson().toJson(updateProData)
								    ))
								    .build();
								client.newCall(request).enqueue(new Callback() {
									    @Override
									    public void onFailure(Call call, IOException e) {
										        final String errorMessage = e.getMessage();
										        new Handler(Looper.getMainLooper()).post(new Runnable() {
											            @Override
											            public void run() {
												                com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
												            }
											        });
										    }
									    @Override
									    public void onResponse(Call call, Response response) throws IOException {
										        final String responseMessage = response.body().string(); 
										        if (response.isSuccessful()) {
											            new Handler(Looper.getMainLooper()).post(new Runnable() {
												                @Override
												                public void run() {
													                    account_type = "free";
													linear_box10.setVisibility(View.VISIBLE);
													com.google.android.material.snackbar.Snackbar.make(linear1, " Warning hidden.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
														@Override
														public void onClick(View _view) {
															 
														}
													}).show();
													                }
												            });
											        } else {
											            new Handler(Looper.getMainLooper()).post(new Runnable() {
												                @Override
												                public void run() {
													                    secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
													secureIntent.putExtra("activity name", "re-login");
													ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
													startActivity(secureIntent, secureIntentOp.toBundle());

													finish();
													                }
												            });
											        }
										    }
								});
								    }
						});
						wearingDialog.setCancelable(false);
						wearingDialog.create().show();
					}
				}
				//End: "convert json response to map"
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "Checker"
		if (save.getString("over scroll", "").equals("on")) {
			if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
				    OverScrollDecoratorHelper.setUpOverScroll(vscroll1);
			}
			_switch_on3(switch_switch_bg, switch_thumb3, SD4);
			switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
		} else {
			_switch_off3(switch_switch_bg, switch_thumb3, SD4);
			switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		}
		if (save.getString("blur", "").equals("on")) {
			_switch_on1(linear_blur_bg, linear_blur_thumb, linear_sd1);
			linear_blur_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
		} else {
			_switch_off1(linear_blur_bg, linear_blur_thumb, linear_sd1);
			linear_blur_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		}
		linear_blur_bg.setEnabled(false);
		linear_blur_thumb.setEnabled(false);
		linear_sd1.setEnabled(false);
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			linear_blur_bg.setEnabled(true);
			linear_blur_thumb.setEnabled(true);
			linear_sd1.setEnabled(true);
		}
		//End: "Checker"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), DashboardActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});

		// Start: "Get data"
		if (save.getString("authentication", "").equals("yes")) {
			getDataMap = new HashMap<>(); 
			getDataMap.put("apikey", getString(R.string.database_api_key));
			getData.setHeaders(getDataMap);
			getData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", ""), "A", _getData_request_listener);
			checkProReqMap = new HashMap<>(); 
			checkProReqMap.put("apikey", getString(R.string.database_api_key));
			checkPro.setHeaders(checkProReqMap);
			checkPro.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", ""), "", _checkPro_request_listener);
		} else {
			com.google.android.material.snackbar.Snackbar.make(linear12, "Authentication required to get data.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
				@Override
				public void onClick(View _view) {
					 
				}
			}).show();
		}
		//End: "Get data"
		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
		loader = new FasterM3BottomSheetLoader(SettingsActivity.this);
		loader.setCancelableOnOutsideClick(false);
		loader.show("Getting data.....");
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
	public void _switch_on3(final View _bg, final View _thumb1, final View _thumb2) {
		ss3 = true;
		_bg.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(int a, int b) {
				        this.setCornerRadius(a);
				        this.setColor(b);
				        return this;
				    }
		}.getIns(360, ContextCompat.getColor(this, R.color.switchBgColor)));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation3.setTarget(_thumb1);
		animation3.setPropertyName("translationX");
		animation3.setFloatValues((float)(_thumb1.getTranslationX() - 35), (float)(_thumb1.getTranslationX()));
		animation3.setDuration((int)(200));
		animation3.start();
	}
	
	
	public void _switch_off3(final View _bg, final View _thumb1, final View _thumb2) {
		ss3 = false;
		_bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)6, 0xFF808C98, 0x33B4B6B9));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF808C98));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation3.setTarget(_thumb1);
		animation3.setPropertyName("translationX");
		animation3.setFloatValues((float)(_thumb1.getTranslationX() + 35), (float)(_thumb1.getTranslationX()));
		animation3.setDuration((int)(200));
		animation3.start();
	}
	
	
	public void _switch_on1(final View _bg, final View _thumb1, final View _thumb2) {
		ss1 = true;
		_bg.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(int a, int b) {
				        this.setCornerRadius(a);
				        this.setColor(b);
				        return this;
				    }
		}.getIns(360, ContextCompat.getColor(this, R.color.switchBgColor)));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() - 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _switch_off1(final View _bg, final View _thumb1, final View _thumb2) {
		ss1 = false;
		_bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)6, 0xFF808C98, 0x33B4B6B9));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF808C98));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() + 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _switch_on(final View _bg, final View _thumb1, final View _thumb2) {
		ss = true;
		_bg.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(int a, int b) {
				        this.setCornerRadius(a);
				        this.setColor(b);
				        return this;
				    }
		}.getIns(360, ContextCompat.getColor(this, R.color.switchBgColor)));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() - 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _switch_off(final View _bg, final View _thumb1, final View _thumb2) {
		ss = false;
		_bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)6, 0xFF808C98, 0x33B4B6B9));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF808C98));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() + 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _security_dialog2(final boolean _mode) {
		final
		com.google.android.material.bottomsheet.BottomSheetDialog securityDialogBuilder = new com.google.android.material.bottomsheet.BottomSheetDialog(SettingsActivity.this);
		View securityDialogDesign = getLayoutInflater().inflate(R.layout.forgotpassword_bottomsheet, null);
		securityDialogBuilder.setContentView(securityDialogDesign);
		securityDialogBuilder.getWindow().getDecorView().setBackgroundColor(0);
		final TextInputLayout textinput_email = securityDialogDesign.findViewById(R.id.textinput_email);
		final TextInputLayout textinput_code = securityDialogDesign.findViewById(R.id.textinput_code);
		final TextInputLayout textinputlayout_question2 = securityDialogDesign.findViewById(R.id.textinputlayout_question2);
		final TextInputLayout textinputlayout_old_pass = securityDialogDesign.findViewById(R.id.textinputlayout_old_pass);
		final TextInputLayout textinput_newpass = securityDialogDesign.findViewById(R.id.textinput_newpass);
		final EditText edittext_email = securityDialogDesign.findViewById(R.id.edittext_email);
		final EditText edittext_newpass = securityDialogDesign.findViewById(R.id.edittext_newpass);
		final EditText edittext_old_pass = securityDialogDesign.findViewById(R.id.edittext_old_pass);
		final EditText edittext_question2 = securityDialogDesign.findViewById(R.id.edittext_question2);
		final TextView textview_top = securityDialogDesign.findViewById(R.id.textview_top);
		final TextView textview_massage = securityDialogDesign.findViewById(R.id.textview_massage);
		final Button button_submit = securityDialogDesign.findViewById(R.id.button_submit);
		final MaterialButton linear_close = securityDialogDesign.findViewById(R.id.linear_close);
		final LinearLayout linear_bt = securityDialogDesign.findViewById(R.id.linear_bt);
		final LinearLayout linear_succ = securityDialogDesign.findViewById(R.id.linear_succ);
		final LinearLayout linear_body = securityDialogDesign.findViewById(R.id.linear_body);
		linear_close.setOnClickListener(v -> {
			securityDialogBuilder.dismiss();
			if (signOut.equals("yes")) {
				save.edit().putString("email", "").commit();
				save.edit().putString("password", "").commit();
				save.edit().putString("user id", "").commit();
				save.edit().putString("authentication", "no").commit();
				intentRest.setClass(getApplicationContext(), MainActivity.class);
				ActivityOptions intentRestOp = ActivityOptions.makeCustomAnimation(SettingsActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(intentRest, intentRestOp.toBundle());

				finish();
			}
					        });
		if (_mode) {
			textinput_email.setVisibility(View.GONE);
			textinput_code.setVisibility(View.GONE);
			textinput_newpass.setVisibility(View.GONE);
			textinput_email.setVisibility(View.GONE);
			linear_succ.setVisibility(View.GONE);
			textinputlayout_question2.setVisibility(View.GONE);
			modes = "first";
			button_submit.setOnClickListener(v -> {
				if (modes.equals("first")) {
					if (edittext_old_pass.getText().toString().isEmpty()) {
						com.google.android.material.snackbar.Snackbar.make(linear_body, "Enter your old password!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					} else {
						if (edittext_old_pass.getText().toString().contains(" ")) {
							com.google.android.material.snackbar.Snackbar.make(linear_body, "Spaces cannot be given!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
						} else {
							button_submit.setEnabled(false);
							RequestNetwork password_check = new RequestNetwork(SettingsActivity.this);
							HashMap<String, Object> password_checkMap = new HashMap<>();
							password_checkMap.put("apikey", getString(R.string.database_api_key));
							password_check.setHeaders(password_checkMap);
							password_check.startRequestNetwork(RequestNetworkController.GET, 
							    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&" + "password" + "=eq." + edittext_old_pass.getText().toString(), "A", 
							    new RequestNetwork.RequestListener() {
									        @Override
									        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
									if (response.equals("[]")) {
											button_submit.setEnabled(true);
										com.google.android.material.snackbar.Snackbar.make(linear_body, "Password don't match!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
									} else {
											_TransitionManager(linear_body, 200);
										button_submit.setEnabled(true);
										textinputlayout_old_pass.setVisibility(View.GONE);
										textinputlayout_question2.setVisibility(View.VISIBLE);
										modes = "second";
									}
											        }
								
									        @Override
									        public void onErrorResponse(String tag, String message) {
									button_submit.setEnabled(true);
									com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
											        }
									    }
							);
						}
					}
				} else {
					if (modes.equals("second")) {
						if (edittext_question2.getText().toString().isEmpty()) {
							com.google.android.material.snackbar.Snackbar.make(linear_body, "Enter correct question!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
						} else {
							if (edittext_question2.getText().toString().contains(" ")) {
								com.google.android.material.snackbar.Snackbar.make(linear_body, "Spaces cannot be given!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							} else {
								button_submit.setEnabled(false);
								// Start: "Question Checker"
								RequestNetwork question_check = new RequestNetwork(SettingsActivity.this);
								HashMap<String, Object> questionCheckMap1 = new HashMap<>();
								questionCheckMap1.put("apikey", getString(R.string.database_api_key));
								question_check.setHeaders(questionCheckMap1);
								question_check.startRequestNetwork(RequestNetworkController.GET, 
								    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&" + "question2" + "=eq." + edittext_question2.getText().toString(), "A", 
								    new RequestNetwork.RequestListener() {
										        @Override
										        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
										if (response.equals("[]")) {
												button_submit.setEnabled(true);
											com.google.android.material.snackbar.Snackbar.make(linear_body, "Question don't match!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										} else {
												_TransitionManager(linear_body, 200);
											button_submit.setEnabled(true);
											textinputlayout_old_pass.setVisibility(View.GONE);
											textinputlayout_question2.setVisibility(View.GONE);
											textinput_newpass.setVisibility(View.VISIBLE);
											modes = "third";
										}
												        }
									
										        @Override
										        public void onErrorResponse(String tag, String message) {
										button_submit.setEnabled(true);
										com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
												        }
										    }
								);
								//End: "Question Checker"
							}
						}
					} else {
						if (modes.equals("third")) {
							if (edittext_newpass.getText().toString().isEmpty()) {
								com.google.android.material.snackbar.Snackbar.make(linear_body, "Enter your new password!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							} else {
								if (edittext_newpass.getText().toString().contains(" ")) {
									com.google.android.material.snackbar.Snackbar.make(linear_body, "Spaces cannot be given!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								} else {
									if (edittext_newpass.getText().toString().matches(".*[@#$&%].*")) {
										if (edittext_newpass.getText().toString().matches(".*[0-9].*")) {
											if (edittext_newpass.getText().toString().length() < 8) {
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Minimum 8 characters!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											} else {
												button_submit.setEnabled(false);
												passwordStr = edittext_newpass.getText().toString();
												try {
													OkHttpClient client = new OkHttpClient();
													
													    JSONObject passwordChangerMap = new JSONObject();
													    passwordChangerMap.put("password", edittext_newpass.getText().toString());
													
													    RequestBody body = RequestBody.create(MediaType.parse("application/json"), passwordChangerMap.toString());
													
													    Request request = new Request.Builder()
													            .url(getString(R.string.database_url) + "/auth/v1/admin/users/" + save.getString("user id", ""))
													            .addHeader("apikey", getString(R.string.SecretKey))
													            .addHeader("Content-Type", "application/json")
													            .addHeader("Authorization", "Bearer " + getString(R.string.SecretKey))
													            .put(body)
													            .build();
													
													    client.newCall(request).enqueue(new Callback() {
														@Override
														public void onFailure(Call call, IOException e) {
															final String errorMessage = e.getMessage();
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	button_submit.setEnabled(true);
																	com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																		@Override
																		public void onClick(View _view) {
																			 
																		}
																	}).show();
																}
															});
														}
														@Override
														public void onResponse(Call call, Response response) throws IOException {
															final boolean isSuccessful = response.isSuccessful();
															final String responseBody = response.body().string();
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	if (isSuccessful) {
																		updatePasswordMap = new Gson().fromJson("{" + "\"" + "password" + "\":\"" + edittext_newpass.getText().toString() + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
																		OkHttpClient client = new OkHttpClient();
																		Request request = new Request.Builder()
																		    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
																		    .addHeader("apikey", getString(R.string.database_api_key))
																		    .patch(RequestBody.create(
																		        MediaType.parse("application/json; charset=utf-8"),
																		        new Gson().toJson(updatePasswordMap)
																		    ))
																		    .build();
																		client.newCall(request).enqueue(new Callback() {
																			    @Override
																			    public void onFailure(Call call, IOException e) {
																				        final String errorMessage = e.getMessage();
																				        new Handler(Looper.getMainLooper()).post(new Runnable() {
																					            @Override
																					            public void run() {
																						                button_submit.setEnabled(true);
																						com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																							@Override
																							public void onClick(View _view) {
																								 
																							}
																						}).show();
																						            }
																					        });
																				    }
																			    @Override
																			    public void onResponse(Call call, Response response) throws IOException {
																				        final String responseMessage = response.body().string(); 
																				        if (response.isSuccessful()) {
																					            new Handler(Looper.getMainLooper()).post(new Runnable() {
																						                @Override
																						                public void run() {
																							                    signOut = "yes";
																							save.edit().putString("password", passwordStr).commit();
																							_TransitionManager(linear_body, 200);
																							button_submit.setEnabled(true);
																							textinputlayout_old_pass.setVisibility(View.GONE);
																							textinputlayout_question2.setVisibility(View.GONE);
																							textinput_newpass.setVisibility(View.GONE);
																							linear_bt.setVisibility(View.GONE);
																							linear_succ.setVisibility(View.VISIBLE);
																							modes = "four";
																							                }
																						            });
																					        } else {
																					            new Handler(Looper.getMainLooper()).post(new Runnable() {
																						                @Override
																						                public void run() {
																							                    button_submit.setEnabled(true);
																							updatePasswordErrorRessMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
																							com.google.android.material.snackbar.Snackbar.make(linear_body, updatePasswordErrorRessMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																								@Override
																								public void onClick(View _view) {
																									 
																								}
																							}).show();
																							                }
																						            });
																					        }
																				    }
																		});
																	} else {
																		button_submit.setEnabled(true);
																		com.google.android.material.snackbar.Snackbar.make(linear_body, "New password change failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																			@Override
																			public void onClick(View _view) {
																				 
																			}
																		}).show();
																	}
																}
															});
														}
													});
												} catch (Exception e) {
													button_submit.setEnabled(true);
													com.google.android.material.snackbar.Snackbar.make(linear_body, "Something went wrong!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
														@Override
														public void onClick(View _view) {
															 
														}
													}).show();
												}
											}
										} else {
											com.google.android.material.snackbar.Snackbar.make(linear_body, "Password must contain at least one number (0-9)!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									} else {
										com.google.android.material.snackbar.Snackbar.make(linear_body, "Password must contain at least one special character (@, #, $, &, %)!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
									}
								}
							}
						}
					}
				}
						        });
		} else {
			textinputlayout_old_pass.setVisibility(View.GONE);
			textinput_code.setVisibility(View.GONE);
			textinput_newpass.setVisibility(View.GONE);
			linear_succ.setVisibility(View.GONE);
			textinput_email.setVisibility(View.GONE);
			textinput_email.setHint("Your New email?");
			textview_top.setText("Change your email!");
			textview_massage.setText("Removing the old email and setting the new password was successful.");
			modes = "first";
			button_submit.setOnClickListener(v -> {
				if (modes.equals("first")) {
					if (edittext_question2.getText().toString().isEmpty()) {
						com.google.android.material.snackbar.Snackbar.make(linear_body, "Enter correct question!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					} else {
						if (edittext_question2.getText().toString().contains(" ")) {
							com.google.android.material.snackbar.Snackbar.make(linear_body, "Spaces cannot be given!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
						} else {
							button_submit.setEnabled(false);
							RequestNetwork question_checker = new RequestNetwork(SettingsActivity.this);
							HashMap<String, Object> questionCheckMap2 = new HashMap<>();
							questionCheckMap2.put("apikey", getString(R.string.database_api_key));
							question_checker.setHeaders(questionCheckMap2);
							question_checker.startRequestNetwork(RequestNetworkController.GET, 
							    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&" + "question2" + "=eq." + edittext_question2.getText().toString(), "A", 
							    new RequestNetwork.RequestListener() {
									        @Override
									        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
									if (response.equals("[]")) {
											button_submit.setEnabled(true);
										com.google.android.material.snackbar.Snackbar.make(linear_body, "Question don't match!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
									} else {
											_TransitionManager(linear_body, 200);
										button_submit.setEnabled(true);
										textinput_email.setVisibility(View.VISIBLE);
										textinputlayout_question2.setVisibility(View.GONE);
										modes = "second";
									}
											        }
								
									        @Override
									        public void onErrorResponse(String tag, String message) {
									button_submit.setEnabled(true);
									com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
											        }
									    }
							);
						}
					}
				} else {
					if (modes.equals("second")) {
						if (edittext_email.getText().toString().isEmpty()) {
							com.google.android.material.snackbar.Snackbar.make(linear_body, "Please enter a valid email!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
						} else {
							if (edittext_email.getText().toString().contains(" ")) {
								com.google.android.material.snackbar.Snackbar.make(linear_body, "Space can't be given!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							} else {
								if (edittext_email.getText().toString().contains("@gmail.com")) {
									button_submit.setEnabled(false);
									emailStr = edittext_email.getText().toString();
									RequestNetwork emailCheckerRequestNet = new RequestNetwork(SettingsActivity.this);
									HashMap<String, Object> emailCheckerMap = new HashMap<>();
									emailCheckerMap.put("apikey", getString(R.string.database_api_key));
									emailCheckerRequestNet.setHeaders(emailCheckerMap);
									emailCheckerRequestNet.startRequestNetwork(RequestNetworkController.GET, 
									    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "email" + "=eq." + edittext_email.getText().toString(), "B", 
									    new RequestNetwork.RequestListener() {
											        @Override
											        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
											if (response.equals("[]")) {
													try {
													    OkHttpClient client = new OkHttpClient();
													    
													    JSONObject emailChangerMap = new JSONObject();
													    emailChangerMap.put("email", edittext_email.getText().toString());
													    
													    RequestBody body = RequestBody.create(MediaType.parse("application/json"), emailChangerMap.toString());
													    
													    Request request = new Request.Builder()
													            .url(getString(R.string.database_url) + "/auth/v1/admin/users/" + save.getString("user id", ""))
													            .addHeader("apikey", getString(R.string.SecretKey))
													            .addHeader("Content-Type", "application/json")
													            .addHeader("Authorization", "Bearer " + getString(R.string.SecretKey))
													            .put(body)
													            .build();
													client.newCall(request).enqueue(new Callback() {
														@Override
														public void onFailure(Call call, IOException e) {
															final String errorMessage = e.getMessage();
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	button_submit.setEnabled(true);
																	com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																		@Override
																		public void onClick(View _view) {
																			 
																		}
																	}).show();
																}
															});
														}
														@Override
														public void onResponse(Call call, Response response) throws IOException {
															final boolean isSuccessful = response.isSuccessful();
															final String responseBody = response.body().string();
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	if (isSuccessful) {
																		updateEmailMap = new Gson().fromJson("{" + "\"" + "email" + "\":\"" + edittext_email.getText().toString() + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
																		OkHttpClient client = new OkHttpClient();
																		Request request = new Request.Builder()
																		    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
																		    .addHeader("apikey", getString(R.string.database_api_key))
																		    .patch(RequestBody.create(
																		        MediaType.parse("application/json; charset=utf-8"),
																		        new Gson().toJson(updateEmailMap)
																		    ))
																		    .build();
																		client.newCall(request).enqueue(new Callback() {
																			    @Override
																			    public void onFailure(Call call, IOException e) {
																				        final String errorMessage = e.getMessage();
																				        new Handler(Looper.getMainLooper()).post(new Runnable() {
																					            @Override
																					            public void run() {
																						                button_submit.setEnabled(true);
																						com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																							@Override
																							public void onClick(View _view) {
																								 
																							}
																						}).show();
																						            }
																					        });
																				    }
																			    @Override
																			    public void onResponse(Call call, Response response) throws IOException {
																				        final String responseMessage = response.body().string(); 
																				        if (response.isSuccessful()) {
																					            new Handler(Looper.getMainLooper()).post(new Runnable() {
																						                @Override
																						                public void run() {
																							                    signOut = "yes";
																							save.edit().putString("email", emailStr).commit();
																							_TransitionManager(linear_body, 200);
																							button_submit.setEnabled(true);
																							textinput_email.setVisibility(View.GONE);
																							textinputlayout_question2.setVisibility(View.GONE);
																							linear_bt.setVisibility(View.GONE);
																							linear_succ.setVisibility(View.VISIBLE);
																							modes = "third";
																							                }
																						            });
																					        } else {
																					            new Handler(Looper.getMainLooper()).post(new Runnable() {
																						                @Override
																						                public void run() {
																							                    button_submit.setEnabled(true);
																							updateEmailErrorMap = new Gson().fromJson(responseBody, new TypeToken<HashMap<String, Object>>(){}.getType());
																							com.google.android.material.snackbar.Snackbar.make(linear_body, updateEmailErrorMap.get("msg").toString(), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																								@Override
																								public void onClick(View _view) {
																									 
																								}
																							}).show();
																							                }
																						            });
																					        }
																				    }
																		});
																	} else {
																		button_submit.setEnabled(true);
																		com.google.android.material.snackbar.Snackbar.make(linear_body, "Email change error. Please check your email again!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																			@Override
																			public void onClick(View _view) {
																				 
																			}
																		}).show();
																	}
																}
															});
														}
													});
												} catch (Exception e) {
													 
												}
												
											} else {
													button_submit.setEnabled(true);
												com.google.android.material.snackbar.Snackbar.make(linear_body, "This email has already been used.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
													        }
										
											        @Override
											        public void onErrorResponse(String tag, String message) {
											button_submit.setEnabled(true);
											com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
													        }
											    }
									);
								} else {
									com.google.android.material.snackbar.Snackbar.make(linear_body, " @gmail.com is required!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								}
							}
						}
					}
				}
						        });
		}
		securityDialogBuilder.setCancelable(false);
		securityDialogBuilder.show();
	}
	
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _deleteAccount() {
		MaterialAlertDialogBuilder DeleteDialog = new MaterialAlertDialogBuilder(SettingsActivity.this);
		View deleteDialogDesign = LayoutInflater.from(SettingsActivity.this).inflate(R.layout.delete_account_dialog, null);
		DeleteDialog.setView(deleteDialogDesign);

		final EditText edittext1 = deleteDialogDesign.findViewById(R.id.edittext1);
		final CheckBox checkbox1 = deleteDialogDesign.findViewById(R.id.checkbox1);
		DeleteDialog.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		DeleteDialog.setNegativeButton("Delete now!", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				        if (edittext1.getText().toString().equals("DELETE")) {
					if (checkbox1.isChecked()) {
						FasterM3BottomSheetLoader AccountDeleteLoader = new FasterM3BottomSheetLoader(SettingsActivity.this);
						AccountDeleteLoader.setCancelableOnOutsideClick(false);
						AccountDeleteLoader.show("Deleting authentication.....");
						try {
							    OkHttpClient client = new OkHttpClient();
							
							    String userId = save.getString("user id", "");
							
							    Request request = new Request.Builder()
							            .url(getString(R.string.database_url) + "/auth/v1/admin/users/" + userId)
							            .addHeader("apikey", getString(R.string.SecretKey))
							            .addHeader("Authorization", "Bearer " + getString(R.string.SecretKey))
							            .delete()
							            .build();
							
							client.newCall(request).enqueue(new Callback() {
								@Override
								public void onFailure(Call call, IOException e) {
									final String errorMessage = e.getMessage();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											AccountDeleteLoader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear12, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									});
								}
								@Override
								public void onResponse(Call call, Response response) throws IOException {
									final boolean isSuccessful = response.isSuccessful();
									final String responseBody = response.body().string();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (isSuccessful) {
												AccountDeleteLoader.updateMessage("Deleting user data & log out....");
												OkHttpClient client = new OkHttpClient();
												Request request = new Request.Builder()
												    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", ""))
												    .delete()
												    .addHeader("apikey", getString(R.string.database_api_key)) 
												    .addHeader("Content-Type", "application/json")
												    .build();
												
												client.newCall(request).enqueue(new Callback() {
													@Override
													public void onFailure(Call call, IOException e) {
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																AccountDeleteLoader.dismiss();
																com.google.android.material.snackbar.Snackbar.make(linear12, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																	@Override
																	public void onClick(View _view) {
																		 
																	}
																}).show();
															}
														});
													}
													@Override
													public void onResponse(Call call, Response response) throws IOException {
														if (response.isSuccessful()) {
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	save.edit().putString("authentication", "no").commit();
																	finishAffinity();
																	 }
															});
														}
														else {
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	AccountDeleteLoader.dismiss();
																	com.google.android.material.snackbar.Snackbar.make(linear12, "Ah! something went wrong. Tell the owner of this app to fix this problem.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																		@Override
																		public void onClick(View _view) {
																			 
																		}
																	}).show();
																}
															});
														}
													}
												});
											} else {
												AccountDeleteLoader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear12, "Ah! something went wrong. Tell the owner of this app to fix this problem.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										}
									});
								}
							});
						} catch (Exception e) {
							 
						}
					}
				}
				    }
		});
		DeleteDialog.setCancelable(true);
		DeleteDialog.create().show();
	}
	
}
