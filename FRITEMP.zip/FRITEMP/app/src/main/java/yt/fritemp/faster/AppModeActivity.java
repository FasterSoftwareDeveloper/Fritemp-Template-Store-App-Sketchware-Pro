package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.airbnb.lottie.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.card.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import android.widget.Toast;


public class AppModeActivity extends AppCompatActivity {
RealTimeNetworkHelper networkHelper;
	
	private HashMap<String, Object> getDataUpdateMap = new HashMap<>();
	private String app_link = "";
	
	private ArrayList<HashMap<String, Object>> getDataListUpdateMap = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout linear_maintenance_body;
	private LinearLayout linear_update_body;
	private RelativeLayout relativelayout1;
	private MaterialCardView linear_maintenance;
	private LinearLayout linear17;
	private LottieAnimationView lottie1;
	private LinearLayout linear12;
	private TextView textview2;
	private TextView textview3;
	private RelativeLayout relativelayout2;
	private MaterialCardView linear_update;
	private TextView textview_version;
	private LinearLayout linear8;
	private LinearLayout linear10;
	private LinearLayout linear6;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview_about;
	private Button button1;
	private LinearLayout linear9;
	private Button button2;
	
	private RequestNetwork app_mode;
	private RequestNetwork.RequestListener _app_mode_request_listener;
	private Intent intentView = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.app_mode);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear2 = findViewById(R.id.linear2);
		linear_maintenance_body = findViewById(R.id.linear_maintenance_body);
		linear_update_body = findViewById(R.id.linear_update_body);
		relativelayout1 = findViewById(R.id.relativelayout1);
		linear_maintenance = findViewById(R.id.linear_maintenance);
		linear17 = findViewById(R.id.linear17);
		lottie1 = findViewById(R.id.lottie1);
		linear12 = findViewById(R.id.linear12);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		relativelayout2 = findViewById(R.id.relativelayout2);
		linear_update = findViewById(R.id.linear_update);
		textview_version = findViewById(R.id.textview_version);
		linear8 = findViewById(R.id.linear8);
		linear10 = findViewById(R.id.linear10);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		textview_about = findViewById(R.id.textview_about);
		button1 = findViewById(R.id.button1);
		linear9 = findViewById(R.id.linear9);
		button2 = findViewById(R.id.button2);
		app_mode = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (app_link.isEmpty()) {
					com.google.android.material.snackbar.Snackbar.make(linear_update_body, "Link not found.Try again in a while.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("Ok", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
					intentView.setAction(Intent.ACTION_VIEW);
					intentView.setData(Uri.parse(app_link));
					startActivity(intentView);
				}
			}
		});
		
		_app_mode_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (getIntent().getStringExtra("app_mode").equals("update")) {
					// Start: "convert json response to map"
					getDataListUpdateMap.clear();
					getDataUpdateMap.clear();
					getDataListUpdateMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					getDataUpdateMap = getDataListUpdateMap.get((int)0);
					//End: "convert json response to map"
					// Start: "update"
					textview_version.setText("New version: ".concat(getDataUpdateMap.get("app_version").toString()));
					textview_about.setText(getDataUpdateMap.get("about").toString());
					app_link = getDataUpdateMap.get("app_link").toString();
					//End: "update"
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				if (_tag.equals("A")) {
					com.google.android.material.snackbar.Snackbar.make(linear_update_body, "No Internet Connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				}
				if (_tag.equals("B")) {
					com.google.android.material.snackbar.Snackbar.make(linear_maintenance_body, "No Internet Connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				}
			}
		};
	}
	
	private void initializeLogic() {
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				finishAffinity();
			}
		});

		// Start: "Mode"
		if (getIntent().getStringExtra("app_mode").equals("update")) {
			app_mode.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "app_mode" + "?apikey=" + getString(R.string.database_api_key), "A", _app_mode_request_listener);
			linear_maintenance_body.setVisibility(View.GONE);
			linear_update_body.setVisibility(View.VISIBLE);
		} else {
			linear_maintenance_body.setVisibility(View.VISIBLE);
			linear_update_body.setVisibility(View.GONE);
		}
		//End: "Mode"
		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(AppModeActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(AppModeActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
}
