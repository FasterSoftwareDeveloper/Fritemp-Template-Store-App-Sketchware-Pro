package yt.fritemp.faster;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.airbnb.lottie.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.net.Uri;
import android.util.Log;
import android.content.res.Configuration;
import android.Manifest;
import android.content.pm.PackageManager;


public class NewUserActivity extends AppCompatActivity {
RealTimeNetworkHelper networkHelper;

private ActivityResultLauncher<Intent> folderPickerLauncher;
private ActivityResultLauncher<String> requestPermissionLauncher;
	
	private Timer _timer = new Timer();
	
	private boolean ss = false;
	private boolean ss2 = false;
	private boolean ss3 = false;
	private boolean notification = false;
	private boolean storage = false;
	private boolean privacy = false;
	private boolean terms = false;
	private String folder_location = "";
	private boolean isChecked = false;
	
	private LinearLayout linear1;
	private RelativeLayout content1;
	private RelativeLayout content2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private TextView textview2;
	private TextView textview3;
	private LottieAnimationView lottie1;
	private MaterialButton button1;
	private LinearLayout linear6;
	private MaterialButton button2;
	private LinearLayout linear15;
	private LinearLayout linear_setup;
	private LinearLayout linear41;
	private LinearLayout linear14;
	private MaterialButton button3;
	private LinearLayout linear16;
	private MaterialButton button4;
	private LinearLayout notification_linear;
	private LinearLayout linear26;
	private LinearLayout linear39;
	private LinearLayout linear31;
	private LinearLayout linear37;
	private TextView textview12;
	private LinearLayout linear20;
	private LinearLayout notification_switch_bg;
	private TextView textview_error;
	private LinearLayout switch_thumb;
	private LinearLayout SD2;
	private TextView textview14;
	private LinearLayout linear27;
	private LinearLayout storage_switch_bg;
	private LinearLayout switch_thumb2;
	private LinearLayout SD3;
	private TextView textview19;
	private LinearLayout linear40;
	private LinearLayout switch_switch_bg;
	private LinearLayout switch_thumb3;
	private LinearLayout SD4;
	private TextView textview15;
	private LinearLayout linear36;
	private MaterialButton button5;
	private TextView textview18;
	private LinearLayout linear38;
	private MaterialButton button6;
	private LottieAnimationView lottie2;
	private TextView textview10;
	private TextView textview11;
	
	private ObjectAnimator animation1 = new ObjectAnimator();
	private ObjectAnimator animation2 = new ObjectAnimator();
	private ObjectAnimator animation3 = new ObjectAnimator();
	private TimerTask timer;
	private SharedPreferences save;
	private Intent restartIntent = new Intent();
	private AlertDialog.Builder restartDialog;
	private AlertDialog.Builder error;
	private AlertDialog.Builder info;
	private Intent privacyLink = new Intent();
	private Intent termsLink = new Intent();
	private Intent intent = new Intent();
	private Intent getStart = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.new_user);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		content1 = findViewById(R.id.content1);
		content2 = findViewById(R.id.content2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		lottie1 = findViewById(R.id.lottie1);
		button1 = findViewById(R.id.button1);
		linear6 = findViewById(R.id.linear6);
		button2 = findViewById(R.id.button2);
		linear15 = findViewById(R.id.linear15);
		linear_setup = findViewById(R.id.linear_setup);
		linear41 = findViewById(R.id.linear41);
		linear14 = findViewById(R.id.linear14);
		button3 = findViewById(R.id.button3);
		linear16 = findViewById(R.id.linear16);
		button4 = findViewById(R.id.button4);
		notification_linear = findViewById(R.id.notification_linear);
		linear26 = findViewById(R.id.linear26);
		linear39 = findViewById(R.id.linear39);
		linear31 = findViewById(R.id.linear31);
		linear37 = findViewById(R.id.linear37);
		textview12 = findViewById(R.id.textview12);
		linear20 = findViewById(R.id.linear20);
		notification_switch_bg = findViewById(R.id.notification_switch_bg);
		textview_error = findViewById(R.id.textview_error);
		switch_thumb = findViewById(R.id.switch_thumb);
		SD2 = findViewById(R.id.SD2);
		textview14 = findViewById(R.id.textview14);
		linear27 = findViewById(R.id.linear27);
		storage_switch_bg = findViewById(R.id.storage_switch_bg);
		switch_thumb2 = findViewById(R.id.switch_thumb2);
		SD3 = findViewById(R.id.SD3);
		textview19 = findViewById(R.id.textview19);
		linear40 = findViewById(R.id.linear40);
		switch_switch_bg = findViewById(R.id.switch_switch_bg);
		switch_thumb3 = findViewById(R.id.switch_thumb3);
		SD4 = findViewById(R.id.SD4);
		textview15 = findViewById(R.id.textview15);
		linear36 = findViewById(R.id.linear36);
		button5 = findViewById(R.id.button5);
		textview18 = findViewById(R.id.textview18);
		linear38 = findViewById(R.id.linear38);
		button6 = findViewById(R.id.button6);
		lottie2 = findViewById(R.id.lottie2);
		textview10 = findViewById(R.id.textview10);
		textview11 = findViewById(R.id.textview11);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		restartDialog = new AlertDialog.Builder(this);
		error = new AlertDialog.Builder(this);
		info = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				    ObjectAnimator fadeOut = ObjectAnimator.ofFloat(content1, "alpha", 1f, 0f);
				    fadeOut.setDuration(500);
				    fadeOut.addListener(new AnimatorListenerAdapter() {
					        @Override
					        public void onAnimationEnd(Animator animation) {
						            content1.setVisibility(View.GONE);
						            content2.setVisibility(View.VISIBLE);
						            ObjectAnimator moveY = ObjectAnimator.ofFloat(content2, "translationY", 500f, 0f);
						            ObjectAnimator scaleX = ObjectAnimator.ofFloat(content2, "scaleX", 0.8f, 1f);
						            ObjectAnimator scaleY = ObjectAnimator.ofFloat(content2, "scaleY", 0.8f, 1f);
						            ObjectAnimator alpha = ObjectAnimator.ofFloat(content2, "alpha", 0f, 1f);
						            moveY.setDuration(1000);
						            scaleX.setDuration(1000);
						            scaleY.setDuration(1000);
						            alpha.setDuration(1000);
						            AnimatorSet appearSet = new AnimatorSet();
						            appearSet.playTogether(moveY, scaleX, scaleY, alpha);
						            appearSet.start();
						        }
					    });
				    fadeOut.start();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				    ObjectAnimator fadeOut = ObjectAnimator.ofFloat(content2, "alpha", 1f, 0f);
				    fadeOut.setDuration(500);
				    fadeOut.addListener(new AnimatorListenerAdapter() {
					        @Override
					        public void onAnimationEnd(Animator animation) {
						            content2.setVisibility(View.GONE);
						            content1.setVisibility(View.VISIBLE);
						            ObjectAnimator moveY = ObjectAnimator.ofFloat(content1, "translationY", 500f, 0f);
						            ObjectAnimator scaleX = ObjectAnimator.ofFloat(content1, "scaleX", 0.8f, 1f);
						            ObjectAnimator scaleY = ObjectAnimator.ofFloat(content1, "scaleY", 0.8f, 1f);
						            ObjectAnimator alpha = ObjectAnimator.ofFloat(content1, "alpha", 0f, 1f);
						            moveY.setDuration(1000);
						            scaleX.setDuration(1000);
						            scaleY.setDuration(1000);
						            alpha.setDuration(1000);
						            AnimatorSet appearSet = new AnimatorSet();
						            appearSet.playTogether(moveY, scaleX, scaleY, alpha);
						            appearSet.start();
						        }
					    });
				    fadeOut.start();
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				save.edit().putString("new_user", "no").commit();
				getStart.setClass(getApplicationContext(), AuthenticationActivity.class);
				ActivityOptions getStartOp = ActivityOptions.makeCustomAnimation(NewUserActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(getStart, getStartOp.toBundle());

				finish();
			}
		});
		
		notification_switch_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (isChecked) {
					_switch_off(notification_switch_bg, switch_thumb, SD2);
					notification_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					_checker();
					isChecked = false;
				} else {
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
						            if (ContextCompat.checkSelfPermission(NewUserActivity.this, Manifest.permission.POST_NOTIFICATIONS)
						                    == PackageManager.PERMISSION_DENIED) {
							                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
							            } else {
							_switch_on(notification_switch_bg, switch_thumb, SD2);
							notification_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
							notification = true;
							isChecked = true;
							_checker();
							}
					}else {
						_switch_on(notification_switch_bg, switch_thumb, SD2);
						notification_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
						notification = true;
						isChecked = true;
						_checker();
					}
				}
			}
		});
		
		storage_switch_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (storage) {
					    if (folder_location != null) {
						        Uri treeUri = Uri.parse(folder_location);
						        getContentResolver().releasePersistableUriPermission(treeUri,
						                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
						        Log.d("Storage", "Folder permission revoked");
						
						        // Reset stored location
						        folder_location = null;
						        storage = false;
						        
						        _switch_off2(storage_switch_bg, switch_thumb2, SD3);
						        storage_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
						        storage = false;
						        _checker();
						    }
				} else {
					Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
					folderPickerLauncher.launch(intent);
				}
			}
		});
		
		switch_switch_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (ss3) {
					_switch_off3(switch_switch_bg, switch_thumb3, SD4);
					switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					save.edit().putString("theme", "dark").commit();
				} else {
					_switch_on3(switch_switch_bg, switch_thumb3, SD4);
					switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
					save.edit().putString("theme", "light").commit();
				}
				MaterialAlertDialogBuilder restartDialog = new MaterialAlertDialogBuilder(NewUserActivity.this);
				restartDialog.setTitle("Restart Required!");
				restartDialog.setMessage("You need to restart the app for the theme to be applied.");
				restartDialog.setIcon(R.drawable.icon_restart);
				restartDialog.setPositiveButton("Restart", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_dialog.dismiss();
						restartIntent.setClass(getApplicationContext(), MainActivity.class);
						ActivityOptions restartIntentOp = ActivityOptions.makeCustomAnimation(NewUserActivity.this, R.anim.fade_in, R.anim.fade_out);
						startActivity(restartIntent, restartIntentOp.toBundle());
					}
				});
				restartDialog.setCancelable(false);
				restartDialog.create().show();
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MaterialAlertDialogBuilder info = new MaterialAlertDialogBuilder(NewUserActivity.this);
				info.setTitle(" Agree?");
				info.setMessage("To continue using the app, you must agree to our Privacy Policy! Click on the button below to open the link browser.");
				info.setIcon(R.drawable.icon_info);
				info.setPositiveButton("Open in browser!", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_dialog.dismiss();
						privacyLink.setAction(Intent.ACTION_VIEW);
						privacyLink.setData(Uri.parse(getString(R.string.privacyUrl)));
						startActivity(privacyLink);
					}
				});
				info.setNegativeButton("Agree!", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_dialog.dismiss();
						button5.setText("Agreed");
						button5.setEnabled(false);
						privacy = true;
						_checker();
					}
				});
				info.create().show();
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MaterialAlertDialogBuilder info = new MaterialAlertDialogBuilder(NewUserActivity.this);
				info.setTitle(" Agree?");
				info.setMessage("To continue using the app, you must agree to our Terms & Condition! Click on the button below to open the link browser.");
				info.setIcon(R.drawable.icon_info);
				info.setPositiveButton("Open in browser!", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_dialog.dismiss();
						termsLink.setAction(Intent.ACTION_VIEW);
						termsLink.setData(Uri.parse(getString(R.string.termsUrl)));
						startActivity(termsLink);
					}
				});
				info.setNegativeButton("Agree!", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_dialog.dismiss();
						button6.setText("Agreed");
						button6.setEnabled(false);
						terms = true;
						_checker();
					}
				});
				info.create().show();
			}
		});
	}
	
	private void initializeLogic() {
		// Start: "animation"
		    ObjectAnimator fadeOut = ObjectAnimator.ofFloat(content2, "alpha", 1f, 0f);
		    fadeOut.setDuration(100);
		    fadeOut.addListener(new AnimatorListenerAdapter() {
			        @Override
			        public void onAnimationEnd(Animator animation) {
				            content2.setVisibility(View.GONE);
				            content1.setVisibility(View.VISIBLE);
				            ObjectAnimator moveY = ObjectAnimator.ofFloat(content1, "translationY", 500f, 0f);
				            ObjectAnimator scaleX = ObjectAnimator.ofFloat(content1, "scaleX", 0.8f, 1f);
				            ObjectAnimator scaleY = ObjectAnimator.ofFloat(content1, "scaleY", 0.8f, 1f);
				            ObjectAnimator alpha = ObjectAnimator.ofFloat(content1, "alpha", 0f, 1f);
				            moveY.setDuration(1000);
				            scaleX.setDuration(1000);
				            scaleY.setDuration(1000);
				            alpha.setDuration(1000);
				            AnimatorSet appearSet = new AnimatorSet();
				            appearSet.playTogether(moveY, scaleX, scaleY, alpha);
				            appearSet.start();
				        }
			    });
		    fadeOut.start();
		//End: "animation"
		// Start: "others"
		_switch_off2(storage_switch_bg, switch_thumb2, SD3);
		storage_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
		        if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
			            _switch_off3(switch_switch_bg, switch_thumb3, SD4);
			            switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
			        } else if (nightModeFlags == Configuration.UI_MODE_NIGHT_NO) {
			            _switch_on3(switch_switch_bg, switch_thumb3, SD4);
			            switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
			        } else {
			            _switch_off3(switch_switch_bg, switch_thumb3, SD4);
			            switch_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
			        }
		storage = false;
		privacy = false;
		terms = false;
		//End: "others"
		// Start: "Folder permission"
		folderPickerLauncher = registerForActivityResult(
		        new ActivityResultContracts.StartActivityForResult(),
		        result -> {
			            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
				                Uri treeUri = result.getData().getData();
				                folder_location = treeUri.toString();
				                _switch_on2(storage_switch_bg, switch_thumb2, SD3);
				                storage_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
				                storage = true;
				                _checker();
				                
				                getContentResolver().takePersistableUriPermission(treeUri,
				                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
				            }
			        }
		    );
		//End: "Folder permission"
		// Start: "Notification permission"
		_switch_off(notification_switch_bg, switch_thumb, SD2);
		notification_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
		notification = false;
		isChecked = false;
		textview_error.setVisibility(View.GONE);
		notification_switch_bg.setVisibility(View.VISIBLE);
		_checker();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			requestPermissionLauncher = registerForActivityResult(
			            new ActivityResultContracts.RequestPermission(),
			            isGranted -> {
				                if (isGranted) {
					_switch_on(notification_switch_bg, switch_thumb, SD2);
					notification_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
					notification = true;
					isChecked = true;
					_checker();
					textview_error.setVisibility(View.GONE);
					notification_switch_bg.setVisibility(View.VISIBLE);
					                } else {
					_switch_off(notification_switch_bg, switch_thumb, SD2);
					notification_switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					notification = false;
					isChecked = false;
					textview_error.setVisibility(View.GONE);
					notification_switch_bg.setVisibility(View.VISIBLE);
					_checker();
					                }
				            }
			        );
		} else {
			notification = true;
			textview_error.setVisibility(View.VISIBLE);
			notification_switch_bg.setVisibility(View.GONE);
		}
		//End: "Notification permission"
		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(NewUserActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(NewUserActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
	public void _switch_on(final View _bg, final View _thumb1, final View _thumb2) {
		ss = true;
		_bg.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(int a, int b) {
				        this.setCornerRadius(a);
				        this.setColor(b);
				        return this;
				    }
		}.getIns(360, ContextCompat.getColor(this, R.color.switchBgColor)));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() - 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _switch_off(final View _bg, final View _thumb1, final View _thumb2) {
		ss = false;
		_bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)6, 0xFF808C98, 0x33B4B6B9));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF808C98));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() + 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _switch_on2(final View _bg, final View _thumb1, final View _thumb2) {
		ss2 = true;
		_bg.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(int a, int b) {
				        this.setCornerRadius(a);
				        this.setColor(b);
				        return this;
				    }
		}.getIns(360, ContextCompat.getColor(this, R.color.switchBgColor)));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation2.setTarget(_thumb1);
		animation2.setPropertyName("translationX");
		animation2.setFloatValues((float)(_thumb1.getTranslationX() - 35), (float)(_thumb1.getTranslationX()));
		animation2.setDuration((int)(200));
		animation2.start();
	}
	
	
	public void _switch_off2(final View _bg, final View _thumb1, final View _thumb2) {
		ss2 = false;
		_bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)6, 0xFF808C98, 0x33B4B6B9));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF808C98));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation2.setTarget(_thumb1);
		animation2.setPropertyName("translationX");
		animation2.setFloatValues((float)(_thumb1.getTranslationX() + 35), (float)(_thumb1.getTranslationX()));
		animation2.setDuration((int)(200));
		animation2.start();
	}
	
	
	public void _switch_on3(final View _bg, final View _thumb1, final View _thumb2) {
		ss3 = true;
		_bg.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(int a, int b) {
				        this.setCornerRadius(a);
				        this.setColor(b);
				        return this;
				    }
		}.getIns(360, ContextCompat.getColor(this, R.color.switchBgColor)));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation3.setTarget(_thumb1);
		animation3.setPropertyName("translationX");
		animation3.setFloatValues((float)(_thumb1.getTranslationX() - 35), (float)(_thumb1.getTranslationX()));
		animation3.setDuration((int)(200));
		animation3.start();
	}
	
	
	public void _switch_off3(final View _bg, final View _thumb1, final View _thumb2) {
		ss3 = false;
		_bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)6, 0xFF808C98, 0x33B4B6B9));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF808C98));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation3.setTarget(_thumb1);
		animation3.setPropertyName("translationX");
		animation3.setFloatValues((float)(_thumb1.getTranslationX() + 35), (float)(_thumb1.getTranslationX()));
		animation3.setDuration((int)(200));
		animation3.start();
	}
	
	
	public void _checker() {
		if (notification && (storage && (privacy && terms))) {
			button4.setEnabled(true);
		} else {
			button4.setEnabled(false);
		}
	}
	
}
