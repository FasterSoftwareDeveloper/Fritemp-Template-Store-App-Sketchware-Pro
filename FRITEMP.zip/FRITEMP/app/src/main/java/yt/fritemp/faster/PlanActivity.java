package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.android.material.card.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import androidx.core.content.ContextCompat;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;


public class PlanActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
RealTimeNetworkHelper networkHelper;
	
	private HashMap<String, Object> checkerMap = new HashMap<>();
	private HashMap<String, Object> checkerRqMap = new HashMap<>();
	private double dollarStore = 0;
	private HashMap<String, Object> checkerReqMap = new HashMap<>();
	private HashMap<String, Object> updateData = new HashMap<>();
	private String ProjectID = "";
	private String accessToken = "";
	private String accessTokenError = "";
	private HashMap<String, Object> notification_map = new HashMap<>();
	private String onError = "";
	private String onSuccess = "";
	private String email = "";
	
	private ArrayList<HashMap<String, Object>> collectListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private ScrollView vscroll1;
	private MaterialButton button1;
	private TextView textview1;
	private LinearLayout linear2;
	private MaterialCardView linear_plan;
	private RelativeLayout relativelayout1;
	private MaterialCardView linear_details;
	private MaterialCardView linear_question;
	private LinearLayout linear15;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview1;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private ImageView imageview2;
	private TextView textview6;
	private LinearLayout linear10;
	private LinearLayout linear9;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private ImageView imageview3;
	private TextView textview7;
	private ImageView imageview4;
	private TextView textview8;
	private ImageView imageview5;
	private TextView textview9;
	private ImageView imageview6;
	private TextView textview10;
	private ImageView imageview7;
	private TextView textview11;
	private LinearLayout linear17;
	private TextView textview12;
	private TextView textview13;
	private Button button3;
	private Button button2;
	
	private Intent backIntent = new Intent();
	private AlertDialog.Builder buyDialog;
	private SharedPreferences save;
	private RequestNetwork checker;
	private RequestNetwork.RequestListener _checker_request_listener;
	private AlertDialog.Builder CheckerDialog;
	private Calendar dateGet = Calendar.getInstance();
	private Intent secureIntent = new Intent();
	private Intent errorIntent = new Intent();
	private AlertDialog.Builder errorDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.plan);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		vscroll1 = findViewById(R.id.vscroll1);
		button1 = findViewById(R.id.button1);
		textview1 = findViewById(R.id.textview1);
		linear2 = findViewById(R.id.linear2);
		linear_plan = findViewById(R.id.linear_plan);
		relativelayout1 = findViewById(R.id.relativelayout1);
		linear_details = findViewById(R.id.linear_details);
		linear_question = findViewById(R.id.linear_question);
		linear15 = findViewById(R.id.linear15);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		imageview2 = findViewById(R.id.imageview2);
		textview6 = findViewById(R.id.textview6);
		linear10 = findViewById(R.id.linear10);
		linear9 = findViewById(R.id.linear9);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		imageview3 = findViewById(R.id.imageview3);
		textview7 = findViewById(R.id.textview7);
		imageview4 = findViewById(R.id.imageview4);
		textview8 = findViewById(R.id.textview8);
		imageview5 = findViewById(R.id.imageview5);
		textview9 = findViewById(R.id.textview9);
		imageview6 = findViewById(R.id.imageview6);
		textview10 = findViewById(R.id.textview10);
		imageview7 = findViewById(R.id.imageview7);
		textview11 = findViewById(R.id.textview11);
		linear17 = findViewById(R.id.linear17);
		textview12 = findViewById(R.id.textview12);
		textview13 = findViewById(R.id.textview13);
		button3 = findViewById(R.id.button3);
		button2 = findViewById(R.id.button2);
		buyDialog = new AlertDialog.Builder(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		checker = new RequestNetwork(this);
		CheckerDialog = new AlertDialog.Builder(this);
		errorDialog = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				backIntent.setClass(getApplicationContext(), SettingsActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				backIntent.setClass(getApplicationContext(), SettingsActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				// Start: "Access an token"
				try {
					    try (InputStream originalInputStream = getAssets().open("service-account.json")) {
						        byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
						
						        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
							            String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
							            HashMap<String, Object> map = new Gson().fromJson(
							                jsonString,
							                new TypeToken<HashMap<String, Object>>(){}.getType()
							            );
							            ProjectID = map.get("project_id").toString();
							        }
						
						        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
							            AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.OnTokenResponse() {
								                @Override
								                public void onSuccess(String token) {
									                    JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
									                    if (jsonResponse.has("access_token")) {
										                        accessToken = jsonResponse.get("access_token").getAsString();
										                    } else {
										                        accessToken = "error getting accessToken";
										                    }
									                }
								
								                @Override
								                public void onError(String error) {
									                    accessTokenError = error;
									                    runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
									                }
								            });
							        }
						    } catch (IOException e) {
						        accessTokenError = "Error reading service account file: " + e.getMessage();
						        runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
						    }
				} catch (Exception e) {
					    runOnUiThread(() -> _m3ErrorDialog("Unexpected error: " + e.getMessage()));
				}
				//End: "Access an token"
				MaterialAlertDialogBuilder buyDialog = new MaterialAlertDialogBuilder(PlanActivity.this);
				buyDialog.setTitle("Are you really sure?");
				buyDialog.setMessage("Do you want to buy this one-month premium plan? If you want to buy, five dollars will be deducted from your account.");
				buyDialog.setPositiveButton("I'm sorry", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						         
						    }
				});
				buyDialog.setNegativeButton("I'm confirm", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						        FasterM3BottomSheetLoader confirmbuydialog = new FasterM3BottomSheetLoader(PlanActivity.this);
						confirmbuydialog.setCancelableOnOutsideClick(false);
						confirmbuydialog.show("Buying...");
						RequestNetwork checkernetrq = new RequestNetwork(PlanActivity.this);
						HashMap<String, Object> checkerRqMap = new HashMap<>();
						checkerRqMap.put("apikey", getString(R.string.database_api_key));
						checkernetrq.setHeaders(checkerRqMap);
						checkernetrq.startRequestNetwork(RequestNetworkController.GET, 
						    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", ""), "", 
						    new RequestNetwork.RequestListener() {
								        @Override
								        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
								if (response.equals("[]")) {
										confirmbuydialog.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear1, "Your data extraction was unsuccessful. Please log in again or try again.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								} else {
										collectListMap = new Gson().fromJson(response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
									checkerMap = collectListMap.get((int)0);
									dollarStore = Double.parseDouble(new DecimalFormat("0.00").format(Double.parseDouble(checkerMap.get("deposit balance").toString())));
									email = checkerMap.get("email").toString();
									if ((dollarStore == 5.00d) || (dollarStore > 5.00d)) {
										dateGet = Calendar.getInstance();
										dateGet.add(Calendar.MONTH, (int)(1));
										updateData = new Gson().fromJson("{\"" + "account type" + "\":\"" + "premium" + "\"," + "\"" + "deposit balance" + "\":\"" + new DecimalFormat("0.00").format(dollarStore - 5.00d).replace("-", "") + "\"," + "\"" + "expired date" + "\":\"" + String.valueOf((long)(dateGet.getTimeInMillis())) + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
										OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
										    .addHeader("apikey", getString(R.string.database_api_key))
										    .patch(RequestBody.create(
										        MediaType.parse("application/json; charset=utf-8"),
										        new Gson().toJson(updateData)
										    ))
										    .build();
										client.newCall(request).enqueue(new Callback() {
											    @Override
											    public void onFailure(Call call, IOException e) {
												        final String errorMessage = e.getMessage();
												        new Handler(Looper.getMainLooper()).post(new Runnable() {
													            @Override
													            public void run() {
														                confirmbuydialog.dismiss();
														com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
														            }
													        });
												    }
											    @Override
											    public void onResponse(Call call, Response response) throws IOException {
												        final String responseMessage = response.body().string(); 
												        if (response.isSuccessful()) {
													            new Handler(Looper.getMainLooper()).post(new Runnable() {
														                @Override
														                public void run() {
															                    confirmbuydialog.dismiss();
															backIntent.setClass(getApplicationContext(), MainActivity.class);
															ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
															startActivity(backIntent, backIntentOp.toBundle());

															_FasterNotificationSender("A user has purchased premium!", "User email: ".concat(email), "", "", "admin", "", "");
															finish();
															                }
														            });
													        } else {
													            new Handler(Looper.getMainLooper()).post(new Runnable() {
														                @Override
														                public void run() {
															                    confirmbuydialog.dismiss();
															secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
															secureIntent.putExtra("activity name", "others");
															ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
															startActivity(secureIntent, secureIntentOp.toBundle());

															finish();
															                }
														            });
													        }
												    }
										});
									} else {
										confirmbuydialog.dismiss();
										com.google.android.material.snackbar.Snackbar.make(linear1, "You don't have enough money in your account, so recharge.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
									}
								}
										        }
							
								        @Override
								        public void onErrorResponse(String tag, String message) {
								confirmbuydialog.dismiss();
								com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
										        }
								    }
						);
						    }
				});
				buyDialog.setCancelable(false);
				buyDialog.create().show();
			}
		});
		
		_checker_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					if (_response.equals("[]")) {
							MaterialAlertDialogBuilder CheckerDialog = new MaterialAlertDialogBuilder(PlanActivity.this);
						CheckerDialog.setTitle("You have premium running!");
						CheckerDialog.setMessage("You already purchased Premium, it is running now, so you can buy it again later when it ends.");
						CheckerDialog.setNegativeButton("Go back!", new DialogInterface.OnClickListener() {
							    @Override
							    public void onClick(DialogInterface _dialog, int _which) {
								        finish();
								    }
						});
						CheckerDialog.setCancelable(false);
						CheckerDialog.create().show();
					} else {
							 
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), SettingsActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});

		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(vscroll1);
			}
		}
		//End: "over scroll checker"
		// Start: "Request network"
		if (save.getString("authentication", "").equals("yes")) {
			checkerReqMap = new HashMap<>(); 
			checkerReqMap.put("apikey", getString(R.string.database_api_key));
			checker.setHeaders(checkerReqMap);
			checker.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&" + "account type" + "=eq." + "free", "", _checker_request_listener);
		} else {
			errorIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
			errorIntent.putExtra("activity name", "login");
			ActivityOptions errorIntentOp = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
			startActivity(errorIntent, errorIntentOp.toBundle());

			finish();
		}
		//End: "Request network"
		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(PlanActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
	public void _FasterNotificationSender(final String _title, final String _body, final String _imageUrl, final String _contextactivity, final String _topic, final String _token, final String _extraText) {
		notification_map = new HashMap<>();
		notification_map.put("title", _title);
		notification_map.put("body", _body);
		if (!_imageUrl.equals("")) {
			notification_map.put("image", _imageUrl);
		}
		if (!_extraText.equals("")) {
			notification_map.put("extraData", _extraText);
		}
		if (!_contextactivity.equals("")) {
			notification_map.put("ContextActivity", _contextactivity);
		}
		if (_token.equals("")) {
			// Start: "Send notification with topic"
			    String topic = _topic;
			    String token = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with topic"
		} else {
			// Start: "Send notification with token"
			    String token = _token;
			    String topic = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with token"
		}
	}
	
	
	public void _m3ErrorDialog(final String _massage) {
		MaterialAlertDialogBuilder errorDialog = new MaterialAlertDialogBuilder(PlanActivity.this);
		errorDialog.setTitle("Error!");
		errorDialog.setMessage(_massage);
		errorDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		errorDialog.setCancelable(true);
		errorDialog.create().show();
	}
	
}
