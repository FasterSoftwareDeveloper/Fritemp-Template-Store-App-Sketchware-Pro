package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import androidx.core.content.ContextCompat;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;


public class TemplateHistoryActivity extends AppCompatActivity {
private FasterFileDownloader fasterDown;

private FasterM3BottomSheetLoader DownLoader;
	
	private HashMap<String, Object> historyRqMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> historyListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	private MaterialButtonToggleGroup linear_selection;
	private ListView listview_pending;
	private ListView listview_success;
	private MaterialButton button_pending;
	private MaterialButton button5;
	
	private Intent backIntent = new Intent();
	private SharedPreferences save;
	private RequestNetwork historyRq;
	private RequestNetwork.RequestListener _historyRq_request_listener;
	private AlertDialog.Builder DownloadDialog;
	private AlertDialog.Builder downloaderDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.template_history);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		linear_selection = findViewById(R.id.linear_selection);
		listview_pending = findViewById(R.id.listview_pending);
		listview_success = findViewById(R.id.listview_success);
		button_pending = findViewById(R.id.button_pending);
		button5 = findViewById(R.id.button5);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		historyRq = new RequestNetwork(this);
		DownloadDialog = new AlertDialog.Builder(this);
		downloaderDialog = new AlertDialog.Builder(this);
		
		button_pending.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview_pending.setVisibility(View.VISIBLE);
				listview_success.setVisibility(View.GONE);
				_TransitionManager(linear1, 300);
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview_pending.setVisibility(View.GONE);
				listview_success.setVisibility(View.VISIBLE);
				_TransitionManager(linear1, 300);
			}
		});
		
		_historyRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				historyListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				Collections.reverse(historyListMap);
				listview_pending.setAdapter(new Listview_pendingAdapter(historyListMap));
				((BaseAdapter)listview_pending.getAdapter()).notifyDataSetChanged();
				listview_success.setAdapter(new Listview_successAdapter(historyListMap));
				((BaseAdapter)listview_success.getAdapter()).notifyDataSetChanged();
				DownLoader.dismiss();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), SettingsActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(TemplateHistoryActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});

		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(listview_pending);
				OverScrollDecoratorHelper.setUpOverScroll(listview_success);
			}
		}
		//End: "over scroll checker"
		historyRqMap = new HashMap<>(); 
		historyRqMap.put("apikey", getString(R.string.database_api_key));
		historyRq.setHeaders(historyRqMap);
		historyRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "template history" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&", "", _historyRq_request_listener);
		DownLoader = new FasterM3BottomSheetLoader(TemplateHistoryActivity.this);
		DownLoader.setCancelableOnOutsideClick(false);
		DownLoader.show("Getting data...");
		fasterDown = new FasterFileDownloader(TemplateHistoryActivity.this);
		listview_success.setVisibility(View.GONE);
	}
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	public class Listview_pendingAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview_pendingAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.recharge_history, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("pending")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("file type")) {
						money.setText(_data.get((int)_position).get("file type").toString());
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("purchase key")) {
						name.setText(_data.get((int)_position).get("purchase key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_primary));
					money.setTextColor(Color.parseColor("#4caf50"));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (_data.get((int)_position).containsKey("purchase key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "template history" + "?" + "purchase key" + "=eq." + _data.get((int)_position).get("purchase key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_main, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															linear_main.setVisibility(View.GONE);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear_main, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(TemplateHistoryActivity.this, "", _data.get((int)_position).get("purchase key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
			
			return _view;
		}
	}
	
	public class Listview_successAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview_successAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.recharge_history, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("success")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("file type")) {
						money.setText(_data.get((int)_position).get("file type").toString());
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("purchase key")) {
						name.setText(_data.get((int)_position).get("purchase key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_primary));
					money.setTextColor(Color.parseColor("#4caf50"));
					linear_main.setOnLongClickListener(new View.OnLongClickListener() {
						@Override
						public boolean onLongClick(View _view) {
							if (_data.get((int)_position).containsKey("purchase key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "template history" + "?" + "purchase key" + "=eq." + _data.get((int)_position).get("purchase key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_main, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															linear_main.setVisibility(View.GONE);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear_main, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(TemplateHistoryActivity.this, "", _data.get((int)_position).get("purchase key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
							return true;
						}
					});
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (_data.get((int)_position).get("file type").toString().equals("upload") || _data.get((int)_position).get("file type").toString().equals("direct link")) {
								MaterialAlertDialogBuilder DownloadDialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
								DownloadDialog.setTitle("Do you want to download the template?");
								DownloadDialog.setMessage("If you want to download the template file now, click on the Yes button. If you want to download it later, click on the Later button.");
								DownloadDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        if (_data.get((int)_position).get("massage").toString().isEmpty()) {
											com.google.android.material.snackbar.Snackbar.make(linear_main, "File not found!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										} else {
											DownLoader.show("Download starting....");
											fasterDown.startDownload(_data.get((int)_position).get("massage").toString(), _data.get((int)_position).get("purchase key").toString() + ".zip");
											fasterDown.setOnDownloadListener(new FasterFileDownloader.OnDownloadListener() {
												@Override
												public void onProgress(int percent) {
													DownLoader.updateMessage("Downloading ".concat(String.valueOf((long)(percent)).concat("/100%")));
												}
												@Override
												public void onSuccess(String savedFilePath) {
													DownLoader.dismiss();
													MaterialAlertDialogBuilder downloaderDialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
													downloaderDialog.setTitle("Download success!");
													downloaderDialog.setMessage("Your file has been downloaded to: ".concat(savedFilePath));
													downloaderDialog.setPositiveButton("Okay!", new DialogInterface.OnClickListener() {
														    @Override
														    public void onClick(DialogInterface _dialog, int _which) {
															         
															    }
													});
													downloaderDialog.setCancelable(true);
													downloaderDialog.create().show();
												}
												@Override
												public void onError(String reason) {
													DownLoader.dismiss();
													MaterialAlertDialogBuilder downloaderDialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
													downloaderDialog.setTitle("Download success!");
													downloaderDialog.setMessage("Your template could not be downloaded! Reason: ".concat(reason));
													downloaderDialog.setPositiveButton("Okay!", new DialogInterface.OnClickListener() {
														    @Override
														    public void onClick(DialogInterface _dialog, int _which) {
															         
															    }
													});
													downloaderDialog.setCancelable(true);
													downloaderDialog.create().show();
												}
											});
										}
										    }
								});
								DownloadDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								DownloadDialog.setCancelable(false);
								DownloadDialog.create().show();
							} else {
								MaterialAlertDialogBuilder downloaderDialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
								downloaderDialog.setTitle("Massage:");
								downloaderDialog.setMessage(_data.get((int)_position).get("massage").toString());
								downloaderDialog.setPositiveButton("Okay!", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								downloaderDialog.setNegativeButton("Copy", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(TemplateHistoryActivity.this, "", _data.get((int)_position).get("massage").toString());
										    }
								});
								downloaderDialog.setCancelable(true);
								downloaderDialog.create().show();
							}
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
			
			return _view;
		}
	}
}
