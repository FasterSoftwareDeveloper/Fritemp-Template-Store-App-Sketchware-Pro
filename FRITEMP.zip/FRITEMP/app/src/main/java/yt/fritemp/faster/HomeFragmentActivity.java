package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import me.everything.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import okhttp3.*;
import org.json.*;
import androidx.recyclerview.widget.PagerSnapHelper;
import com.google.android.material.shape.ShapeAppearanceModel;
import androidx.core.content.ContextCompat;


public class HomeFragmentActivity extends Fragment {
	
	private Timer _timer = new Timer();
	
	private double position = 0;
	private double number = 0;
	private HashMap<String, Object> userMap = new HashMap<>();
	private HashMap<String, Object> userDataMap = new HashMap<>();
	private HashMap<String, Object> mostPopularMap = new HashMap<>();
	private double most_popular_num = 0;
	private PeekAndPop peekAndPop;
	private double peekPosition = 0;
	private double peekPosition2 = 0;
	private double peekPosition3 = 0;
	private double peekPosition4 = 0;
	
	private ArrayList<HashMap<String, Object>> suggestionMp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> userDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> templatesListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> mostPopularListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> filteredList = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> editorChoiceListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> landscapeTemplateListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> gamingTemplateListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> sliderListMap = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview_top;
	private TextView textview2;
	private RecyclerView recyclerview1;
	private LinearLayout linear_most_popular;
	private LinearLayout linear_editor_choice;
	private LinearLayout linear_landscape_templates;
	private LinearLayout linear_gaming_template;
	private MaterialButton button1;
	private LinearLayout linear13;
	private LinearLayout linear3;
	private RecyclerView recyclerview_most_popular;
	private RecyclerView recyclerview_category;
	private TextView textview3;
	private MaterialButton button2;
	private LinearLayout linear6;
	private RecyclerView recyclerview_editor_choice;
	private TextView textview4;
	private MaterialButton button3;
	private LinearLayout linear8;
	private RecyclerView recyclerview_landscape_templates;
	private TextView textview_landscape_templates;
	private MaterialButton button4;
	private LinearLayout linear12;
	private RecyclerView recyclerview_gaming_template;
	private TextView textview7;
	private MaterialButton button6;
	
	private TimerTask scrollTimer;
	private Intent settingsIntent = new Intent();
	private SharedPreferences save;
	private Intent viewIntent = new Intent();
	private RequestNetwork userRq;
	private RequestNetwork.RequestListener _userRq_request_listener;
	private RequestNetwork templatesRq;
	private RequestNetwork.RequestListener _templatesRq_request_listener;
	private Intent allViewIntent = new Intent();
	private Intent linkView = new Intent();
	private RequestNetwork sliderRq;
	private RequestNetwork.RequestListener _sliderRq_request_listener;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.home_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		vscroll1 = _view.findViewById(R.id.vscroll1);
		linear1 = _view.findViewById(R.id.linear1);
		linear2 = _view.findViewById(R.id.linear2);
		textview_top = _view.findViewById(R.id.textview_top);
		textview2 = _view.findViewById(R.id.textview2);
		recyclerview1 = _view.findViewById(R.id.recyclerview1);
		linear_most_popular = _view.findViewById(R.id.linear_most_popular);
		linear_editor_choice = _view.findViewById(R.id.linear_editor_choice);
		linear_landscape_templates = _view.findViewById(R.id.linear_landscape_templates);
		linear_gaming_template = _view.findViewById(R.id.linear_gaming_template);
		button1 = _view.findViewById(R.id.button1);
		linear13 = _view.findViewById(R.id.linear13);
		linear3 = _view.findViewById(R.id.linear3);
		recyclerview_most_popular = _view.findViewById(R.id.recyclerview_most_popular);
		recyclerview_category = _view.findViewById(R.id.recyclerview_category);
		textview3 = _view.findViewById(R.id.textview3);
		button2 = _view.findViewById(R.id.button2);
		linear6 = _view.findViewById(R.id.linear6);
		recyclerview_editor_choice = _view.findViewById(R.id.recyclerview_editor_choice);
		textview4 = _view.findViewById(R.id.textview4);
		button3 = _view.findViewById(R.id.button3);
		linear8 = _view.findViewById(R.id.linear8);
		recyclerview_landscape_templates = _view.findViewById(R.id.recyclerview_landscape_templates);
		textview_landscape_templates = _view.findViewById(R.id.textview_landscape_templates);
		button4 = _view.findViewById(R.id.button4);
		linear12 = _view.findViewById(R.id.linear12);
		recyclerview_gaming_template = _view.findViewById(R.id.recyclerview_gaming_template);
		textview7 = _view.findViewById(R.id.textview7);
		button6 = _view.findViewById(R.id.button6);
		save = getContext().getSharedPreferences("save", Activity.MODE_PRIVATE);
		userRq = new RequestNetwork((Activity) getContext());
		templatesRq = new RequestNetwork((Activity) getContext());
		sliderRq = new RequestNetwork((Activity) getContext());
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				settingsIntent.setClass(getContext().getApplicationContext(), SettingsActivity.class);
				settingsIntent.putExtra("uid", "");
				ActivityOptions settingsIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(settingsIntent, settingsIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "portrait");
				allViewIntent.putExtra("item category", "Most Popular");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "portrait");
				allViewIntent.putExtra("item category", "Editor Choice");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "landscape");
				allViewIntent.putExtra("item category", "Landscape Template");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "landscape");
				allViewIntent.putExtra("item category", "Gaming Landscape Template");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		_userRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					try {
						userDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						userDataMap = userDataListMap.get((int)0);
						if (userDataMap.containsKey("name")) {
							textview_top.setText("Assalamu Alaikum ".concat(userDataMap.get("name").toString().concat(", What's on mind today?")));
						}
						sliderRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "slider" + "?apikey=" + getString(R.string.database_api_key), "", _sliderRq_request_listener);
					} catch (Exception e) {
						 
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_templatesRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				templatesListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				mostPopularListMap.clear();
				for (HashMap<String, Object> item : templatesListMap) {
					    if ("Most Popular".equals(String.valueOf(item.get("item category"))) &&
					        "portrait".equals(String.valueOf(item.get("template type")))) {
						        mostPopularListMap.add(item);
						    }
				}
				recyclerview_most_popular.setAdapter(new Recyclerview_most_popularAdapter(mostPopularListMap));
				editorChoiceListMap.clear();
				for (HashMap<String, Object> item : templatesListMap) {
					    if ("Editor Choice".equals(String.valueOf(item.get("item category"))) &&
					        "portrait".equals(String.valueOf(item.get("template type")))) {
						        editorChoiceListMap.add(item);
						    }
				}
				recyclerview_editor_choice.setAdapter(new Recyclerview_editor_choiceAdapter(editorChoiceListMap));
				landscapeTemplateListMap.clear();
				for (HashMap<String, Object> item : templatesListMap) {
					    if ("Landscape Template".equals(String.valueOf(item.get("item category"))) &&
					        "landscape".equals(String.valueOf(item.get("template type")))) {
						        landscapeTemplateListMap.add(item);
						    }
				}
				recyclerview_landscape_templates.setAdapter(new Recyclerview_landscape_templatesAdapter(landscapeTemplateListMap));
				gamingTemplateListMap.clear();
				for (HashMap<String, Object> item : templatesListMap) {
					    if ("Gaming Landscape Template".equals(String.valueOf(item.get("item category"))) &&
					        "landscape".equals(String.valueOf(item.get("template type")))) {
						        gamingTemplateListMap.add(item);
						    }
				}
				recyclerview_gaming_template.setAdapter(new Recyclerview_gaming_templateAdapter(gamingTemplateListMap));
				if (mostPopularListMap.size() > 2) {
					recyclerview_most_popular.smoothScrollToPosition((int)2);
				}
				if (editorChoiceListMap.size() > 2) {
					recyclerview_editor_choice.smoothScrollToPosition((int)2);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_sliderRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				sliderListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				recyclerview1.setAdapter(new Recyclerview1Adapter(sliderListMap));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "category"
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Gaming");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Vlogs");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Tech Reviews");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Lifestyle");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Travel");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Education");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Music Videos");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Cinematic Edits");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Business & Corporate");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Sports Highlights");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Fashion & Beauty");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Food & Cooking");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Motivational");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "News & Politics");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Comedy & Memes");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Wedding & Events");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Fitness & Gym");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Real Estate");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "Product Reviews");
			    suggestionMp.add(_item);
		}
		{
			    HashMap<String, Object> _item = new HashMap<>();
			    _item.put("hi", "TikTok & Shorts");
			    suggestionMp.add(_item);
		}
		recyclerview_category.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_category.setAdapter(new Recyclerview_categoryAdapter(suggestionMp));
		recyclerview_most_popular.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_landscape_templates.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_gaming_template.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_editor_choice.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview1.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		//End: "category"
		// Start: "Slider animation (Recyclerview)"
		final float anim1 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview1);
		recyclerview1.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim1);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview1.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview1.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim2 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_most_popular);
		recyclerview_most_popular.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim2);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_most_popular.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_most_popular.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim3 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_editor_choice);
		recyclerview_editor_choice.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim3);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_editor_choice.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_editor_choice.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim4 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_landscape_templates);
		recyclerview_landscape_templates.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim4);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_landscape_templates.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_landscape_templates.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim5 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_gaming_template);
		recyclerview_gaming_template.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim5);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_gaming_template.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_gaming_template.fling(adjustedVelocityX, velocityY);
				    }
		});
		position = 0;
		number = 0;
		scrollTimer = new TimerTask() {
			@Override
			public void run() {
				getActivity().runOnUiThread(new Runnable() {
					@Override
					public void run() {
						recyclerview1.smoothScrollToPosition((int)number);
						number++;
						if (number == sliderListMap.size()) {
							number = 0;
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(scrollTimer, (int)(0), (int)(3000));
		//End: "Slider animation (Recyclerview)"
		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(vscroll1);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview1, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_most_popular, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_editor_choice, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_landscape_templates, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_gaming_template, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
			}
		}
		//End: "over scroll checker"
		// Start: "Database"
		userMap = new HashMap<>(); 
		userMap.put("apikey", getString(R.string.database_api_key));
		userRq.setHeaders(userMap);
		userRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&", "", _userRq_request_listener);
		templatesRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?apikey=" + getString(R.string.database_api_key), "", _templatesRq_request_listener);
		//End: "Database"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		try {
			scrollTimer.cancel();
		} catch (Exception e) {
			 
		}
	}
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.carousel, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView carousel = _view.findViewById(R.id.carousel);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			if (_data.get((int)_position).containsKey("image url")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image url").toString())).into(imageview3);
			}
			if (_data.get((int)_position).containsKey("title")) {
				textview1.setText(_data.get((int)_position).get("title").toString());
			}
			if (_data.get((int)_position).containsKey("description")) {
				textview2.setText(_data.get((int)_position).get("description").toString());
			}
			carousel.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (_data.get((int)_position).containsKey("link")) {
						try {
							linkView.setAction(Intent.ACTION_VIEW);
							linkView.setData(Uri.parse(_data.get((int)_position).get("link").toString()));
							startActivity(linkView);
						} catch (Exception e) {
							 
						}
					}
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_most_popularAdapter extends RecyclerView.Adapter<Recyclerview_most_popularAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_most_popularAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.portrait, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(mostPopularListMap.get((int)peekPosition).get("category").toString());
							peekText2.setText(mostPopularListMap.get((int)peekPosition).get("media type").toString());
							peekText3.setText(mostPopularListMap.get((int)peekPosition).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_categoryAdapter extends RecyclerView.Adapter<Recyclerview_categoryAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_categoryAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.category_cus, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.chip.Chip linear_chip = _view.findViewById(R.id.linear_chip);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			linear_chip.setText(_data.get((int)_position).get("hi").toString());
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_editor_choiceAdapter extends RecyclerView.Adapter<Recyclerview_editor_choiceAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_editor_choiceAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.portrait, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition2 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(editorChoiceListMap.get((int)peekPosition2).get("category").toString());
							peekText2.setText(editorChoiceListMap.get((int)peekPosition2).get("media type").toString());
							peekText3.setText(editorChoiceListMap.get((int)peekPosition2).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_landscape_templatesAdapter extends RecyclerView.Adapter<Recyclerview_landscape_templatesAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_landscape_templatesAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.landscape, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition3 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(landscapeTemplateListMap.get((int)peekPosition3).get("category").toString());
							peekText2.setText(landscapeTemplateListMap.get((int)peekPosition3).get("media type").toString());
							peekText3.setText(landscapeTemplateListMap.get((int)peekPosition3).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_gaming_templateAdapter extends RecyclerView.Adapter<Recyclerview_gaming_templateAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_gaming_templateAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.landscape, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition4 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(gamingTemplateListMap.get((int)peekPosition4).get("category").toString());
							peekText2.setText(gamingTemplateListMap.get((int)peekPosition4).get("media type").toString());
							peekText3.setText(gamingTemplateListMap.get((int)peekPosition4).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}
