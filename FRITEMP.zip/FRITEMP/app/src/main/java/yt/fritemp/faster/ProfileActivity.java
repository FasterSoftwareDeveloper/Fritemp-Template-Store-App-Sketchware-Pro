package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.android.material.card.*;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.activity.result.ActivityResultCallback;
import java.io.InputStream;
import android.database.Cursor;
import com.bumptech.glide.Glide;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import androidx.core.content.ContextCompat;


public class ProfileActivity extends AppCompatActivity {
RealTimeNetworkHelper networkHelper;
ActivityResultLauncher<String> launcher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri) {
                    if (uri == null) {
                    } else {
                        imageUri = _saveUriToFile(uri.toString());
                        Glide.with(getApplicationContext()).load(uri).into(imageview1);
                    }
                }
            });

private FasterM3BottomSheetLoader loader;
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
	
	private HashMap<String, Object> getData = new HashMap<>();
	private boolean nameTextCheck = false;
	private boolean countryTextCheck = false;
	private boolean numberTextCheck = false;
	private String imageUri = "";
	private HashMap<String, Object> InsertDataValueMap = new HashMap<>();
	private String fileName = "";
	private String Url = "";
	private String Api = "";
	private String imgUrl = "";
	private String path = "";
	private String oldLogoUrl = "";
	private HashMap<String, Object> checkProReqMap = new HashMap<>();
	private HashMap<String, Object> getProDataMap = new HashMap<>();
	private String account_type = "";
	private boolean socialTextCheck = false;
	private String imageDeleteToken = "";
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> getProDataListMap = new ArrayList<>();
	
	private RelativeLayout relativelayout1;
	private ScrollView vscroll1;
	private MaterialButton button1;
	private TextView textview1;
	private LinearLayout linear1;
	private RelativeLayout relativelayout2;
	private TextInputLayout textinput_name;
	private TextInputLayout textinput_country;
	private TextInputLayout textinput_number;
	private TextInputLayout textinputlayout_link;
	private TextInputLayout textinputlayout_email;
	private Button button2;
	private MaterialCardView linear_image_border;
	private MaterialButton linear2;
	private ImageView imageview1;
	private EditText edittext_name;
	private EditText edittext_country;
	private EditText edittext_number;
	private EditText edittext_link;
	private EditText edittext_email;
	
	private Intent backIntent = new Intent();
	private SharedPreferences save;
	private RequestNetwork Request;
	private RequestNetwork.RequestListener _Request_request_listener;
	private RequestNetwork checkPro;
	private RequestNetwork.RequestListener _checkPro_request_listener;
	private Calendar get_date = Calendar.getInstance();
	private Intent secureIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		relativelayout1 = findViewById(R.id.relativelayout1);
		vscroll1 = findViewById(R.id.vscroll1);
		button1 = findViewById(R.id.button1);
		textview1 = findViewById(R.id.textview1);
		linear1 = findViewById(R.id.linear1);
		relativelayout2 = findViewById(R.id.relativelayout2);
		textinput_name = findViewById(R.id.textinput_name);
		textinput_country = findViewById(R.id.textinput_country);
		textinput_number = findViewById(R.id.textinput_number);
		textinputlayout_link = findViewById(R.id.textinputlayout_link);
		textinputlayout_email = findViewById(R.id.textinputlayout_email);
		button2 = findViewById(R.id.button2);
		linear_image_border = findViewById(R.id.linear_image_border);
		linear2 = findViewById(R.id.linear2);
		imageview1 = findViewById(R.id.imageview1);
		edittext_name = findViewById(R.id.edittext_name);
		edittext_country = findViewById(R.id.edittext_country);
		edittext_number = findViewById(R.id.edittext_number);
		edittext_link = findViewById(R.id.edittext_link);
		edittext_email = findViewById(R.id.edittext_email);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		Request = new RequestNetwork(this);
		checkPro = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				backIntent.setClass(getApplicationContext(), SettingsActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(ProfileActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (nameTextCheck) {
					if (countryTextCheck) {
						if (numberTextCheck) {
							if (socialTextCheck) {
								if (imageUri.isEmpty()) {
									loader.show("Saving data....");
									InsertDataValueMap = new Gson().fromJson("{" + "\"" + "name" + "\":\"" + edittext_name.getText().toString() + "\"," + "\"" + "country" + "\":\"" + edittext_country.getText().toString() + "\"," + "\"" + "mobile number" + "\":\"" + edittext_number.getText().toString() + "\"," + "\"" + "social media" + "\":\"" + edittext_link.getText().toString() + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
									OkHttpClient client = new OkHttpClient();
									Request request = new Request.Builder()
									    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
									    .addHeader("apikey", getString(R.string.database_api_key))
									    .patch(RequestBody.create(
									        MediaType.parse("application/json; charset=utf-8"),
									        new Gson().toJson(InsertDataValueMap)
									    ))
									    .build();
									client.newCall(request).enqueue(new Callback() {
										    @Override
										    public void onFailure(Call call, IOException e) {
											        final String errorMessage = e.getMessage();
											        new Handler(Looper.getMainLooper()).post(new Runnable() {
												            @Override
												            public void run() {
													                 
													            }
												        });
											    }
										    @Override
										    public void onResponse(Call call, Response response) throws IOException {
											        final String responseMessage = response.body().string(); 
											        if (response.isSuccessful()) {
												            new Handler(Looper.getMainLooper()).post(new Runnable() {
													                @Override
													                public void run() {
														                    loader.dismiss();
														                }
													            });
												        } else {
												            new Handler(Looper.getMainLooper()).post(new Runnable() {
													                @Override
													                public void run() {
														                     
														                }
													            });
												        }
											    }
									});
								} else {
									fileName = "pRofiLe".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(10000), (int)(90000)))));
									if (oldLogoUrl.equals("none") || imageDeleteToken.equals("none")) {
										loader.show("Uploading new photo.....");
										_uploadfiles();
									} else {
										loader.show("Deleting old photo....");
										FasterCloudinaryUploader.deleteByPublicId(ProfileActivity.this, imageDeleteToken, new FasterCloudinaryUploader.UploadCallback() {
											@Override
											public void onSuccess(String msg, String nothing) {
												loader.updateMessage("Uploading new photo.....");
												_uploadfiles();
											}
											@Override
											public void onFailure(String error) {
												loader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear1, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										});
									}
								}
							}
						}
					}
				}
			}
		});
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				launcher.launch("image/*");
			}
		});
		
		edittext_name.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_name.setErrorEnabled(true);
					textinput_name.setError("Please enter your full name");
					nameTextCheck = false;
				} else {
					textinput_name.setErrorEnabled(false);
					nameTextCheck = false;
					if (_charSeq.length() > textinput_name.getCounterMaxLength()) {
						textinput_name.setErrorEnabled(true);
						textinput_name.setError("Text exceeds maximum length!");
						nameTextCheck = false;
					} else {
						textinput_name.setErrorEnabled(false);
						nameTextCheck = true;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		edittext_country.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_country.setErrorEnabled(true);
					textinput_country.setError("Please enter your full name");
					countryTextCheck = false;
				} else {
					textinput_country.setErrorEnabled(false);
					countryTextCheck = true;
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		edittext_number.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinput_number.setErrorEnabled(true);
					textinput_number.setError("Please enter your full name");
					numberTextCheck = false;
				} else {
					textinput_number.setErrorEnabled(false);
					numberTextCheck = false;
					if (_charSeq.contains("+")) {
						textinput_number.setErrorEnabled(false);
						numberTextCheck = true;
					} else {
						textinput_number.setErrorEnabled(true);
						textinput_number.setError("Please add your country code!");
						numberTextCheck = false;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		edittext_link.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.isEmpty()) {
					textinputlayout_link.setErrorEnabled(true);
					textinputlayout_link.setError("Please enter a social media url!");
					socialTextCheck = false;
				} else {
					textinputlayout_link.setErrorEnabled(false);
					socialTextCheck = false;
					if (_charSeq.contains(" ")) {
						textinputlayout_link.setErrorEnabled(true);
						textinputlayout_link.setError("Spaces cannot be given!");
						socialTextCheck = false;
					} else {
						textinputlayout_link.setErrorEnabled(false);
						socialTextCheck = false;
						if (_charSeq.contains("https://") || _charSeq.contains("http://")) {
							textinputlayout_link.setErrorEnabled(true);
							textinputlayout_link.setError("Domain invalid! Don't use http or https.");
							socialTextCheck = false;
						} else {
							textinputlayout_link.setErrorEnabled(false);
							socialTextCheck = false;
							if (_charSeq.contains(".")) {
								textinputlayout_link.setErrorEnabled(false);
								socialTextCheck = true;
							} else {
								textinputlayout_link.setErrorEnabled(true);
								textinputlayout_link.setError("Domain invalid!");
								socialTextCheck = false;
							}
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_Request_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						loader.dismiss();
					secureIntent.setClass(getApplicationContext(), SecurityCheckerActivity.class);
					secureIntent.putExtra("activity name", "re-login");
					ActivityOptions secureIntentOp = ActivityOptions.makeCustomAnimation(ProfileActivity.this, R.anim.fade_in, R.anim.fade_out);
					startActivity(secureIntent, secureIntentOp.toBundle());

					finish();
				} else {
						// Start: "List map to map"
					getDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					getData = getDataListMap.get((int)0);
					//End: "List map to map"
					// Start: "Set data"
					if (getData.containsKey("logo url")) {
						if (getData.get("logo url").toString().equals("none")) {
							imageview1.setImageResource(R.drawable.user_default_icon);
							oldLogoUrl = "none";
						} else {
							Glide.with(getApplicationContext()).load(Uri.parse(getData.get("logo url").toString())).into(imageview1);
							oldLogoUrl = getData.get("logo url").toString();
						}
					}
					if (getData.containsKey("name")) {
						edittext_name.setText(getData.get("name").toString());
					}
					if (getData.containsKey("country")) {
						edittext_country.setText(getData.get("country").toString());
					}
					if (getData.containsKey("mobile number")) {
						edittext_number.setText(getData.get("mobile number").toString());
					}
					if (getData.containsKey("email")) {
						edittext_email.setText(getData.get("email").toString());
					}
					if (getData.containsKey("social media")) {
						edittext_link.setText(getData.get("social media").toString());
					}
					if (getData.containsKey("imageDeleteToken")) {
						imageDeleteToken = getData.get("imageDeleteToken").toString();
					}
					//End: "Set data"
					loader.dismiss();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				loader.dismiss();
				com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			}
		};
		
		_checkPro_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// Start: "convert json response to map"
				getProDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				getProDataMap = getProDataListMap.get((int)0);
				get_date = Calendar.getInstance();
				if (getProDataMap.get("expired date").toString().equals("none")) {
					account_type = "free";
					textinput_country.setEndIconMode(TextInputLayout.END_ICON_CUSTOM);
					textinput_country.setEndIconDrawable(ContextCompat.getDrawable(ProfileActivity.this, R.drawable.icon_king));
					textinput_country.setEndIconTintList(ColorStateList.valueOf(Color.parseColor("#FFC107")));
					textinput_country.setHelperText(getString(R.string.countryhelper));
					textinput_country.setHelperTextEnabled(true);
					textinput_country.setEnabled(false);
				} else {
					if (get_date.getTimeInMillis() < Double.parseDouble(getProDataMap.get("expired date").toString())) {
						account_type = "premium";
						textinput_country.setEnabled(true);
					} else {
						account_type = "premium";
						textinput_country.setEnabled(true);
					}
				}
				//End: "convert json response to map"
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), SettingsActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(ProfileActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});

		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(vscroll1);
			}
		}
		//End: "over scroll checker"
		// Start: "Request for data"
		getData = new HashMap<>(); 
		getData.put("apikey", getString(R.string.database_api_key));
		Request.setHeaders(getData);
		Request.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", ""), "A", _Request_request_listener);
		checkProReqMap = new HashMap<>(); 
		checkProReqMap.put("apikey", getString(R.string.database_api_key));
		checkPro.setHeaders(checkProReqMap);
		checkPro.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", ""), "", _checkPro_request_listener);
		//End: "Request for data"
		// Start: "setup"
		nameTextCheck = false;
		countryTextCheck = false;
		numberTextCheck = false;
		socialTextCheck = false;
		//End: "setup"
		// Start: "Loading dialog"
		loader = new FasterM3BottomSheetLoader(ProfileActivity.this);
		loader.setCancelableOnOutsideClick(false);
		loader.show("Getting data....");
		textinputlayout_email.setEnabled(false);
		edittext_country.setEnabled(false);
		//End: "Loading dialog"
		// Start: "Image picker"
		//End: "Image picker"
		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(ProfileActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(ProfileActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
	public void _uploadfiles() {
		FasterCloudinaryUploader.uploadMedia(ProfileActivity.this, imageUri, new FasterCloudinaryUploader.UploadCallback() {
			@Override
			public void onSuccess(String fileUrl, String
			publicId) {
				loader.updateMessage("Saving data.....");
				InsertDataValueMap = new Gson().fromJson("{" + "\"" + "name" + "\":\"" + edittext_name.getText().toString() + "\",\"" + "country" + "\":\"" + edittext_country.getText().toString() + "\",\"" + "mobile number" + "\":\"" + edittext_number.getText().toString() + "\",\"" + "logo url" + "\":\"" + fileUrl + "\",\"" + "social media" + "\":\"" + edittext_link.getText().toString() + "\",\"" + "imageDeleteToken" + "\":\"" + publicId + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + save.getString("user id", ""))
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(InsertDataValueMap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                loader.dismiss();
								com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    loader.dismiss();
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    loader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear1, "Data save failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									                }
								            });
							        }
						    }
				});
			}
			@Override
			public void onFailure(String error) {
				loader.dismiss();
				com.google.android.material.snackbar.Snackbar.make(linear1, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			}
		});
	}
	
	
	public String _saveUriToFile(final String _uri) {
		    try {  
			        ContentResolver contentResolver = getContentResolver();  
			        Uri uri = Uri.parse(_uri);
			        InputStream inputStream = contentResolver.openInputStream(uri);  
			        File file = new File(getExternalFilesDir(null), "picked_image.jpg");  
			        FileOutputStream outputStream = new FileOutputStream(file);  
			
			        byte[] buffer = new byte[1024];  
			        int length;  
			        while ((length = inputStream.read(buffer)) > 0) {  
				            outputStream.write(buffer, 0, length);  
				        }  
			
			        outputStream.close();  
			        inputStream.close();  
			
			        return file.getAbsolutePath();
			    } catch (Exception e) {  
			        e.printStackTrace();  
			        return null;  
			    }
	}
	
}
