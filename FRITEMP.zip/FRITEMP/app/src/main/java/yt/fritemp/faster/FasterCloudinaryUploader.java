package yt.fritemp.faster;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FasterCloudinaryUploader {

    private static final String API_KEY = "add here";
    private static final String API_SECRET = "add here";
    private static final String CLOUD_NAME = "add here";
    private static final String UPLOAD_URL = "https://api.cloudinary.com/v1_1/" + CLOUD_NAME + "/auto/upload";
    private static final String DESTROY_URL = "https://api.cloudinary.com/v1_1/" + CLOUD_NAME + "/image/destroy";

    public interface UploadCallback {
        void onSuccess(String fileUrl, String publicId);
        void onFailure(String error);
    }

    public static void uploadMedia(Context context, String filePath, UploadCallback callback) {
        File file = new File(filePath);
        if (!file.exists()) {
            callback.onFailure("File not found");
            return;
        }

        String mimeType = getMimeType(filePath);
        if (!mimeType.startsWith("image/") && !mimeType.startsWith("video/")) {
            callback.onFailure("Invalid file type");
            return;
        }

        long timestamp = System.currentTimeMillis() / 1000L;

        String signatureRaw = "timestamp=" + timestamp + API_SECRET;
        String signature = sha1Hex(signatureRaw);

        OkHttpClient client = new OkHttpClient();

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.getName(),
                        RequestBody.create(MediaType.parse("application/octet-stream"), file))
                .addFormDataPart("api_key", API_KEY)
                .addFormDataPart("timestamp", String.valueOf(timestamp))
                .addFormDataPart("signature", signature)
                .build();

        Request request = new Request.Builder()
                .url(UPLOAD_URL)
                .post(requestBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            Handler mainHandler = new Handler(Looper.getMainLooper());

            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onFailure(e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseStr = response.body() != null ? response.body().string() : "";

                mainHandler.post(() -> {
                    if (response.isSuccessful()) {
                        try {
                            JSONObject json = new JSONObject(responseStr);
                            String fileUrl = json.getString("secure_url");
                            String publicId = json.getString("public_id");
                            callback.onSuccess(fileUrl, publicId);
                        } catch (Exception e) {
                            callback.onFailure("JSON parse error");
                        }
                    } else {
                        callback.onFailure("Server error: " + responseStr);
                    }
                });
            }
        });
    }

    public static void deleteByPublicId(Context context, String publicId, UploadCallback callback) {
        long timestamp = System.currentTimeMillis() / 1000L;
        String signatureRaw = "public_id=" + publicId + "&timestamp=" + timestamp + API_SECRET;
        String signature = sha1Hex(signatureRaw);

        OkHttpClient client = new OkHttpClient();

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("public_id", publicId)
                .addFormDataPart("api_key", API_KEY)
                .addFormDataPart("timestamp", String.valueOf(timestamp))
                .addFormDataPart("signature", signature)
                .build();

        Request request = new Request.Builder()
                .url(DESTROY_URL)
                .post(requestBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            Handler mainHandler = new Handler(Looper.getMainLooper());

            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onFailure(e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String res = response.body() != null ? response.body().string() : "";
                mainHandler.post(() -> {
                    if (response.isSuccessful()) {
                        callback.onSuccess("File deleted successfully", null);
                    } else {
                        callback.onFailure("Delete failed: " + res);
                    }
                });
            }
        });
    }

    private static String sha1Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] result = md.digest(input.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : result) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static String getMimeType(String filePath) {
        String lower = filePath.toLowerCase();
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".mp4")) return "video/mp4";
        if (lower.endsWith(".avi")) return "video/x-msvideo";
        if (lower.endsWith(".mov")) return "video/quicktime";
        return "application/octet-stream";
    }
}