package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;

public class DebugActivity extends AppCompatActivity {
	
	private AlertDialog.Builder errorDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.debug);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		errorDialog = new AlertDialog.Builder(this);
	}
	
	private void initializeLogic() {
		MaterialAlertDialogBuilder errorDialog = new MaterialAlertDialogBuilder(DebugActivity.this);
		errorDialog.setTitle("The app has been crashed!");
		errorDialog.setMessage("We are sorry, the app crashed due to some problem in the app. You can click on copy button and copy the error and send it to our email. We will find out where it happened. Try again!");
		errorDialog.setNegativeButton("Copy", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				        FasterUtils.copyToClipboard(DebugActivity.this, getIntent().getStringExtra("error"), getIntent().getStringExtra("error"));
				finishAffinity();
				    }
		});
		errorDialog.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				        finishAffinity();
				    }
		});
		errorDialog.setCancelable(false);
		errorDialog.create().show();
	}
	
}
