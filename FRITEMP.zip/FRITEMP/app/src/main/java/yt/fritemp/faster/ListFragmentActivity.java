package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import okhttp3.*;
import org.json.*;

public class ListFragmentActivity extends Fragment {
	
	private HashMap<String, Object> userDataMap = new HashMap<>();
	private HashMap<String, Object> userMap = new HashMap<>();
	private PeekAndPop peekAndPop;
	private double peekPosition = 0;
	private double peekPosition2 = 0;
	private double peekPosition3 = 0;
	private double peekPosition4 = 0;
	private double peekPosition5 = 0;
	
	private ArrayList<String> str = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> templateListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> businessListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> socialmediaListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> educationalListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> videoListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> marketingListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> userDataListMap = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear;
	private LinearLayout linear2;
	private LinearLayout linear7;
	private LinearLayout linear9;
	private LinearLayout linear11;
	private LinearLayout linear13;
	private LinearLayout linear3;
	private RecyclerView recyclerview_businesses;
	private TextView textview3;
	private MaterialButton button2;
	private LinearLayout linear6;
	private RecyclerView recyclerview_social_media;
	private TextView textview4;
	private MaterialButton button3;
	private LinearLayout linear8;
	private RecyclerView recyclerview_education;
	private TextView textview5;
	private MaterialButton button4;
	private LinearLayout linear10;
	private RecyclerView recyclerview_video;
	private TextView textview6;
	private MaterialButton button5;
	private LinearLayout linear12;
	private RecyclerView recyclerview_marketing;
	private TextView textview7;
	private MaterialButton button6;
	
	private SharedPreferences save;
	private RequestNetwork uesrRq;
	private RequestNetwork.RequestListener _uesrRq_request_listener;
	private RequestNetwork templateRq;
	private RequestNetwork.RequestListener _templateRq_request_listener;
	private Intent viewIntent = new Intent();
	private Intent allViewIntent = new Intent();
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.list_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		vscroll1 = _view.findViewById(R.id.vscroll1);
		linear1 = _view.findViewById(R.id.linear1);
		linear = _view.findViewById(R.id.linear);
		linear2 = _view.findViewById(R.id.linear2);
		linear7 = _view.findViewById(R.id.linear7);
		linear9 = _view.findViewById(R.id.linear9);
		linear11 = _view.findViewById(R.id.linear11);
		linear13 = _view.findViewById(R.id.linear13);
		linear3 = _view.findViewById(R.id.linear3);
		recyclerview_businesses = _view.findViewById(R.id.recyclerview_businesses);
		textview3 = _view.findViewById(R.id.textview3);
		button2 = _view.findViewById(R.id.button2);
		linear6 = _view.findViewById(R.id.linear6);
		recyclerview_social_media = _view.findViewById(R.id.recyclerview_social_media);
		textview4 = _view.findViewById(R.id.textview4);
		button3 = _view.findViewById(R.id.button3);
		linear8 = _view.findViewById(R.id.linear8);
		recyclerview_education = _view.findViewById(R.id.recyclerview_education);
		textview5 = _view.findViewById(R.id.textview5);
		button4 = _view.findViewById(R.id.button4);
		linear10 = _view.findViewById(R.id.linear10);
		recyclerview_video = _view.findViewById(R.id.recyclerview_video);
		textview6 = _view.findViewById(R.id.textview6);
		button5 = _view.findViewById(R.id.button5);
		linear12 = _view.findViewById(R.id.linear12);
		recyclerview_marketing = _view.findViewById(R.id.recyclerview_marketing);
		textview7 = _view.findViewById(R.id.textview7);
		button6 = _view.findViewById(R.id.button6);
		save = getContext().getSharedPreferences("save", Activity.MODE_PRIVATE);
		uesrRq = new RequestNetwork((Activity) getContext());
		templateRq = new RequestNetwork((Activity) getContext());
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "landscape");
				allViewIntent.putExtra("item category", "Business Template");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "portrait");
				allViewIntent.putExtra("item category", "Social Media Template");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "landscape");
				allViewIntent.putExtra("item category", "Educational Template");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "portrait");
				allViewIntent.putExtra("item category", "Video Template");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				allViewIntent.setClass(getContext().getApplicationContext(), ViewAllActivity.class);
				allViewIntent.putExtra("template type", "portrait");
				allViewIntent.putExtra("item category", "Marketing Template");
				ActivityOptions allViewIntentOp = ActivityOptions.makeCustomAnimation(getContext(), R.anim.fade_in, R.anim.fade_out);
				startActivity(allViewIntent, allViewIntentOp.toBundle());
				requireActivity().finish();
			}
		});
		
		_uesrRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					try {
						userDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						userDataMap = userDataListMap.get((int)0);
						templateRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?apikey=" + getString(R.string.database_api_key), "", _templateRq_request_listener);
					} catch (Exception e) {
						 
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_templateRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				templateListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				businessListMap.clear();
				for (HashMap<String, Object> item : templateListMap) {
					    if ("Business Template".equals(String.valueOf(item.get("item category"))) &&
					        "landscape".equals(String.valueOf(item.get("template type")))) {
						        businessListMap.add(item);
						    }
				}
				recyclerview_businesses.setAdapter(new Recyclerview_businessesAdapter(businessListMap));
				socialmediaListMap.clear();
				for (HashMap<String, Object> item : templateListMap) {
					    if ("Social Media Template".equals(String.valueOf(item.get("item category"))) &&
					        "portrait".equals(String.valueOf(item.get("template type")))) {
						        socialmediaListMap.add(item);
						    }
				}
				recyclerview_social_media.setAdapter(new Recyclerview_social_mediaAdapter(socialmediaListMap));
				educationalListMap.clear();
				for (HashMap<String, Object> item : templateListMap) {
					    if ("Educational Template".equals(String.valueOf(item.get("item category"))) &&
					        "landscape".equals(String.valueOf(item.get("template type")))) {
						        educationalListMap.add(item);
						    }
				}
				recyclerview_education.setAdapter(new Recyclerview_educationAdapter(educationalListMap));
				videoListMap.clear();
				for (HashMap<String, Object> item : templateListMap) {
					    if ("Video Template".equals(String.valueOf(item.get("item category"))) &&
					        "portrait".equals(String.valueOf(item.get("template type")))) {
						        videoListMap.add(item);
						    }
				}
				recyclerview_video.setAdapter(new Recyclerview_videoAdapter(videoListMap));
				marketingListMap.clear();
				for (HashMap<String, Object> item : templateListMap) {
					    if ("Marketing Template".equals(String.valueOf(item.get("item category"))) &&
					        "portrait".equals(String.valueOf(item.get("template type")))) {
						        marketingListMap.add(item);
						    }
				}
				recyclerview_marketing.setAdapter(new Recyclerview_marketingAdapter(marketingListMap));
				if (socialmediaListMap.size() > 2) {
					recyclerview_social_media.smoothScrollToPosition((int)2);
				}
				if (videoListMap.size() > 2) {
					recyclerview_video.smoothScrollToPosition((int)2);
				}
				if (marketingListMap.size() > 2) {
					recyclerview_marketing.smoothScrollToPosition((int)2);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "recycle view"
		recyclerview_businesses.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_social_media.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_education.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_video.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		recyclerview_marketing.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false));
		//End: "recycle view"
		// Start: "Slider animation"
		final float anim1 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_businesses);
		recyclerview_businesses.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim1);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_businesses.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_businesses.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim2 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_social_media);
		recyclerview_social_media.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim2);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_social_media.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_social_media.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim3 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_education);
		recyclerview_education.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim3);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_education.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_education.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim4 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_video);
		recyclerview_video.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim4);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_video.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_video.fling(adjustedVelocityX, velocityY);
				    }
		});
		final float anim5 = 0.90f;
		new LinearSnapHelper().attachToRecyclerView(recyclerview_marketing);
		recyclerview_marketing.addOnScrollListener(new RecyclerView.OnScrollListener() {
			    @Override
			    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
				        super.onScrolled(recyclerView, dx, dy);
				        int recyclerCenterX = recyclerView.getWidth() / 2;
				        for (int i = 0; i < recyclerView.getChildCount(); i++) {
					            View child = recyclerView.getChildAt(i);
					            int childCenterX = (child.getLeft() + child.getRight()) / 2;
					            int distanceFromCenter = Math.abs(recyclerCenterX - childCenterX);
					            float scale = 1 - ((float) distanceFromCenter / recyclerCenterX) * (1 - anim5);
					            child.setScaleX(scale);
					            child.setScaleY(scale);
					        }
				    }
		});
		recyclerview_marketing.setOnFlingListener(new RecyclerView.OnFlingListener() {
			    @Override
			    public boolean onFling(int velocityX, int velocityY) {
				        int adjustedVelocityX = (int) (velocityX * 0.5f);
				        return recyclerview_marketing.fling(adjustedVelocityX, velocityY);
				    }
		});
		//End: "Slider animation"
		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(vscroll1);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_businesses, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_social_media, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_education, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_video, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
				OverScrollDecoratorHelper.setUpOverScroll(recyclerview_marketing, OverScrollDecoratorHelper.ORIENTATION_HORIZONTAL);
			}
		}
		//End: "over scroll checker"
		// Start: "database"
		userMap = new HashMap<>(); 
		userMap.put("apikey", getString(R.string.database_api_key));
		uesrRq.setHeaders(userMap);
		uesrRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&", "", _uesrRq_request_listener);
		//End: "database"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	public class Recyclerview_businessesAdapter extends RecyclerView.Adapter<Recyclerview_businessesAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_businessesAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.landscape, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(businessListMap.get((int)peekPosition).get("category").toString());
							peekText2.setText(businessListMap.get((int)peekPosition).get("media type").toString());
							peekText3.setText(businessListMap.get((int)peekPosition).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_social_mediaAdapter extends RecyclerView.Adapter<Recyclerview_social_mediaAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_social_mediaAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.portrait, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition2 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(socialmediaListMap.get((int)peekPosition2).get("category").toString());
							peekText2.setText(socialmediaListMap.get((int)peekPosition2).get("media type").toString());
							peekText3.setText(socialmediaListMap.get((int)peekPosition2).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_educationAdapter extends RecyclerView.Adapter<Recyclerview_educationAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_educationAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.landscape, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition3 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(educationalListMap.get((int)peekPosition3).get("category").toString());
							peekText2.setText(educationalListMap.get((int)peekPosition3).get("media type").toString());
							peekText3.setText(educationalListMap.get((int)peekPosition3).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_videoAdapter extends RecyclerView.Adapter<Recyclerview_videoAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_videoAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.portrait, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition4 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(videoListMap.get((int)peekPosition4).get("category").toString());
							peekText2.setText(videoListMap.get((int)peekPosition4).get("media type").toString());
							peekText3.setText(videoListMap.get((int)peekPosition4).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview_marketingAdapter extends RecyclerView.Adapter<Recyclerview_marketingAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview_marketingAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _v = _inflater.inflate(R.layout.portrait, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
			_view.setLayoutParams(_lp);
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getContext().getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getContext().getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        getActivity(), linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition5 = _position;
							peekAndPop = new PeekAndPop.Builder(requireActivity())
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							peekText.setText(marketingListMap.get((int)peekPosition5).get("category").toString());
							peekText2.setText(marketingListMap.get((int)peekPosition5).get("media type").toString());
							peekText3.setText(marketingListMap.get((int)peekPosition5).get("item category").toString());
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}
