package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.android.material.card.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.UnityAds;


public class ViewTemplatesActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }

private FasterM3BottomSheetLoader purchaseLoader;

private FasterM3BottomSheetLoader DownLoader;

private FasterM3BottomSheetLoader adLoader;
private FasterFileDownloader fasterDown;
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> userRqMap = new HashMap<>();
	private HashMap<String, Object> templatesRq = new HashMap<>();
	private HashMap<String, Object> userDataMap = new HashMap<>();
	private HashMap<String, Object> extractMap = new HashMap<>();
	private String fileUrl = "";
	private String title = "";
	private HashMap<String, Object> DatabaseValueMap = new HashMap<>();
	private HashMap<String, Object> DatabaseHeaderMap = new HashMap<>();
	private String purchase_key = "";
	private String email = "";
	private String accessToken = "";
	private String accessTokenError = "";
	private String ProjectID = "";
	private HashMap<String, Object> notification_map = new HashMap<>();
	private String onError = "";
	private String onSuccess = "";
	private HashMap<String, Object> getsRqMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> userDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> extractListMap = new ArrayList<>();
	
	private RelativeLayout relativelayout1;
	private ScrollView vscroll3;
	private MaterialCardView linear_bottom_card;
	private LinearLayout linear45;
	private LinearLayout linear35;
	private LinearLayout linear_top;
	private LinearLayout linear_top_content;
	private MaterialCardView linear_bottom_content;
	private MaterialButton button2;
	private LinearLayout linear4;
	private MaterialButton button1;
	private MaterialCardView linear_card1;
	private MaterialCardView linear_card2;
	private LinearLayout linear9;
	private ImageView imageview2;
	private ImageView imageview3;
	private TextView textview_title;
	private LinearLayout linear46;
	private LinearLayout linear41;
	private MaterialCardView linear_category;
	private TextView textview6;
	private TextView textview_description;
	private LinearLayout linear43;
	private LinearLayout linear44;
	private MaterialButton button3;
	private TextView textview_restrictions;
	private TextView textview_duration;
	private MaterialButton button4;
	private TextView textview4;
	private TextView textview_price;
	private TextView textview_category;
	private LinearLayout linear29;
	private MaterialCardView linear_img_card;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private ImageView imageview_bottom;
	private TextView textview_bottom_title;
	private TextView textview_bottom_subtitle;
	private MaterialButton button_play;
	private Button button_get;
	
	private TimerTask timer;
	private Intent backIntent = new Intent();
	private RequestNetwork userRq;
	private RequestNetwork.RequestListener _userRq_request_listener;
	private RequestNetwork templateRq;
	private RequestNetwork.RequestListener _templateRq_request_listener;
	private SharedPreferences save;
	private Intent videoViewIntent = new Intent();
	private AlertDialog.Builder adDialog;
	private AlertDialog.Builder downloaderDialog;
	private RequestNetwork directionRq;
	private RequestNetwork.RequestListener _directionRq_request_listener;
	private Calendar date = Calendar.getInstance();
	private Intent successintent = new Intent();
	private AlertDialog.Builder collectEmailDialog;
	private AlertDialog.Builder confirmDialog;
	private AlertDialog.Builder DownloadDialog;
	private AlertDialog.Builder purchaseSuccessfulDialog;
	private AlertDialog.Builder premiumDialog;
	private Intent premiumIntent = new Intent();
	private AlertDialog.Builder errorDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view_templates);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		relativelayout1 = findViewById(R.id.relativelayout1);
		vscroll3 = findViewById(R.id.vscroll3);
		linear_bottom_card = findViewById(R.id.linear_bottom_card);
		linear45 = findViewById(R.id.linear45);
		linear35 = findViewById(R.id.linear35);
		linear_top = findViewById(R.id.linear_top);
		linear_top_content = findViewById(R.id.linear_top_content);
		linear_bottom_content = findViewById(R.id.linear_bottom_content);
		button2 = findViewById(R.id.button2);
		linear4 = findViewById(R.id.linear4);
		button1 = findViewById(R.id.button1);
		linear_card1 = findViewById(R.id.linear_card1);
		linear_card2 = findViewById(R.id.linear_card2);
		linear9 = findViewById(R.id.linear9);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		textview_title = findViewById(R.id.textview_title);
		linear46 = findViewById(R.id.linear46);
		linear41 = findViewById(R.id.linear41);
		linear_category = findViewById(R.id.linear_category);
		textview6 = findViewById(R.id.textview6);
		textview_description = findViewById(R.id.textview_description);
		linear43 = findViewById(R.id.linear43);
		linear44 = findViewById(R.id.linear44);
		button3 = findViewById(R.id.button3);
		textview_restrictions = findViewById(R.id.textview_restrictions);
		textview_duration = findViewById(R.id.textview_duration);
		button4 = findViewById(R.id.button4);
		textview4 = findViewById(R.id.textview4);
		textview_price = findViewById(R.id.textview_price);
		textview_category = findViewById(R.id.textview_category);
		linear29 = findViewById(R.id.linear29);
		linear_img_card = findViewById(R.id.linear_img_card);
		linear30 = findViewById(R.id.linear30);
		linear31 = findViewById(R.id.linear31);
		imageview_bottom = findViewById(R.id.imageview_bottom);
		textview_bottom_title = findViewById(R.id.textview_bottom_title);
		textview_bottom_subtitle = findViewById(R.id.textview_bottom_subtitle);
		button_play = findViewById(R.id.button_play);
		button_get = findViewById(R.id.button_get);
		userRq = new RequestNetwork(this);
		templateRq = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		adDialog = new AlertDialog.Builder(this);
		downloaderDialog = new AlertDialog.Builder(this);
		directionRq = new RequestNetwork(this);
		collectEmailDialog = new AlertDialog.Builder(this);
		confirmDialog = new AlertDialog.Builder(this);
		DownloadDialog = new AlertDialog.Builder(this);
		purchaseSuccessfulDialog = new AlertDialog.Builder(this);
		premiumDialog = new AlertDialog.Builder(this);
		errorDialog = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_get_it();
			}
		});
		
		button_play.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				videoViewIntent.setClass(getApplicationContext(), VideoPlayerActivity.class);
				videoViewIntent.putExtra("video url", extractMap.get("video").toString());
				videoViewIntent.putExtra("media type", getIntent().getStringExtra("media type"));
				videoViewIntent.putExtra("template type", getIntent().getStringExtra("template type"));
				videoViewIntent.putExtra("key", getIntent().getStringExtra("key"));
				ActivityOptions videoViewIntentOp = ActivityOptions.makeCustomAnimation(ViewTemplatesActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(videoViewIntent, videoViewIntentOp.toBundle());

			}
		});
		
		button_get.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_get_it();
			}
		});
		
		_userRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					try {
						userDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						userDataMap = userDataListMap.get((int)0);
						templatesRq = new HashMap<>(); 
						templatesRq.put("apikey", getString(R.string.database_api_key));
						templateRq.setHeaders(templatesRq);
						templateRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "main key" + "=eq." + getIntent().getStringExtra("key") + "&", "", _templateRq_request_listener);
					} catch (Exception e) {
						 
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_templateRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				extractListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				extractMap = extractListMap.get((int)0);
				if (extractMap.containsKey("title")) {
					textview_title.setText(extractMap.get("title").toString());
					textview_bottom_title.setText(extractMap.get("title").toString());
					title = extractMap.get("title").toString().toLowerCase().trim().replace(" ", "_").concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(00001), (int)(10000)))));
				}
				if (extractMap.containsKey("price")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_price.setText("Unlocked");
					} else {
						textview_price.setText(extractMap.get("price").toString());
					}
				}
				if (extractMap.containsKey("image")) {
					Glide.with(getApplicationContext()).load(Uri.parse(extractMap.get("image").toString())).into(imageview2);
					Glide.with(getApplicationContext()).load(Uri.parse(extractMap.get("image").toString())).into(imageview3);
					Glide.with(getApplicationContext()).load(Uri.parse(extractMap.get("image").toString())).into(imageview_bottom);
				}
				if (extractMap.containsKey("description")) {
					textview_description.setText(extractMap.get("description").toString());
				}
				if (extractMap.containsKey("duration")) {
					if (extractMap.get("duration").toString().equals("")) {
						textview_restrictions.setText("Restriction");
						textview_duration.setText("Copyright Free!");
					} else {
						textview_duration.setText(extractMap.get("duration").toString());
					}
				}
				if (extractMap.containsKey("category")) {
					textview_bottom_subtitle.setText(extractMap.get("category").toString().concat(" ".concat(extractMap.get("media type").toString().concat(" Template".concat("")))));
					textview_category.setText(extractMap.get("category").toString().concat(" ".concat(extractMap.get("media type").toString().concat(" Template".concat("")))));
				}
				if (extractMap.containsKey("template file type")) {
					if (extractMap.get("template file type").toString().equals("upload")) {
						if (extractMap.containsKey("template file")) {
							fileUrl = extractMap.get("template file").toString();
						}
					} else {
						if (extractMap.containsKey("direct download link")) {
							fileUrl = extractMap.get("direct download link").toString();
						}
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_directionRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, "Purchase failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
						if (_tag.equals("upload")) {
						purchaseLoader.dismiss();
						_purchase_mode("upload");
					} else {
						purchaseLoader.dismiss();
						MaterialAlertDialogBuilder purchaseSuccessfulDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
						purchaseSuccessfulDialog.setTitle("Purchase successful!");
						purchaseSuccessfulDialog.setMessage("You can now check the history if you want to see if the template was successful.");
						purchaseSuccessfulDialog.setPositiveButton("Check history!", new DialogInterface.OnClickListener() {
							    @Override
							    public void onClick(DialogInterface _dialog, int _which) {
								        successintent.setClass(getApplicationContext(), TemplateHistoryActivity.class);
								ActivityOptions successintentOp = ActivityOptions.makeCustomAnimation(ViewTemplatesActivity.this, R.anim.fade_in, R.anim.fade_out);
								startActivity(successintent, successintentOp.toBundle());

								finish();
								    }
						});
						purchaseSuccessfulDialog.setCancelable(false);
						purchaseSuccessfulDialog.create().show();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), DashboardActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(ViewTemplatesActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());
			}
		});

		// Start: "ui & database related"
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			   getWindow().setStatusBarColor(getResources().getColor(R.color.md_theme_tertiaryContainer, getTheme()));
		}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			   getWindow().setNavigationBarColor(getResources().getColor(R.color.reverse_theme_background, getTheme()));
			   }
		ShapeAppearanceModel shapeAppearanceModel = new ShapeAppearanceModel.Builder()
		    .setTopLeftCornerSize(100f)
		    .setTopRightCornerSize(100f)
		    .setBottomLeftCornerSize(0f)
		    .setBottomRightCornerSize(0f)
		    .build();
		linear_bottom_content.setShapeAppearanceModel(shapeAppearanceModel);
		if (getIntent().getStringExtra("template type").equals("landscape")) {
			linear_card1.setVisibility(View.VISIBLE);
			linear_card2.setVisibility(View.GONE);
		} else {
			linear_card1.setVisibility(View.GONE);
			linear_card2.setVisibility(View.VISIBLE);
		}
		if (getIntent().getStringExtra("media type").equals("image")) {
			linear_bottom_card.setVisibility(View.GONE);
			linear45.setVisibility(View.GONE);
			linear_category.setVisibility(View.VISIBLE);
		} else {
			linear_bottom_card.setVisibility(View.VISIBLE);
			linear45.setVisibility(View.VISIBLE);
			linear_category.setVisibility(View.GONE);
		}
		// Start: "database"
		userRqMap = new HashMap<>(); 
		userRqMap.put("apikey", getString(R.string.database_api_key));
		userRq.setHeaders(userRqMap);
		userRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&", "", _userRq_request_listener);
		//End: "database"
		fasterDown = new FasterFileDownloader(ViewTemplatesActivity.this);
		//End: "ui & database related"
		// Start: "Access an token"
		try {
			    try (InputStream originalInputStream = getAssets().open("service-account.json")) {
				        byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
					            HashMap<String, Object> map = new Gson().fromJson(
					                jsonString,
					                new TypeToken<HashMap<String, Object>>(){}.getType()
					            );
					            ProjectID = map.get("project_id").toString();
					        }
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.OnTokenResponse() {
						                @Override
						                public void onSuccess(String token) {
							                    JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
							                    if (jsonResponse.has("access_token")) {
								                        accessToken = jsonResponse.get("access_token").getAsString();
								                    } else {
								                        accessToken = "error getting accessToken";
								                    }
							                }
						
						                @Override
						                public void onError(String error) {
							                    accessTokenError = error;
							                    runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
							                }
						            });
					        }
				    } catch (IOException e) {
				        accessTokenError = "Error reading service account file: " + e.getMessage();
				        runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
				    }
		} catch (Exception e) {
			    runOnUiThread(() -> _m3ErrorDialog("Unexpected error: " + e.getMessage()));
		}
		//End: "Access an token"
		// Start: "adLoader"
		adLoader = new FasterM3BottomSheetLoader(ViewTemplatesActivity.this);
		adLoader.setCancelableOnOutsideClick(false);
		DownLoader = new FasterM3BottomSheetLoader(ViewTemplatesActivity.this);
		DownLoader.setCancelableOnOutsideClick(false);
		purchaseLoader = new FasterM3BottomSheetLoader(ViewTemplatesActivity.this);
		purchaseLoader.setCancelableOnOutsideClick(false);
		//End: "adLoader"
		// Start: "Unity ads initialize"
		UnityAds.initialize(this, "000000", true, new IUnityAdsInitializationListener() {
			    @Override
			    public void onInitializationComplete() {}
			
			    @Override
			    public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
				       com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, message, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					    	@Override
					     	public void onClick(View _view) {}
					       }).show();
				    }
		});
		//End: "Unity ads initialize"
	}
	// Start: "Unity ad load listlinear"
	private final IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
		    @Override
		    public void onUnityAdsAdLoaded(String placementId) {
			        UnityAds.show(ViewTemplatesActivity.this, placementId, new UnityAdsShowOptions(), showListener);
			        adLoader.dismiss();
			    }
		
		    @Override
		    public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
			        adLoader.dismiss();
			        com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, message, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
			            .setAction("", new View.OnClickListener() {
				                @Override
				                public void onClick(View v) {}
				            }).show();
			    }
	};
	//End: "Unity ad load listlinear"
	// Start: "Unity ad show listlinear"
	private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
		    @Override
		    public void onUnityAdsShowFailure(String __UnityPlacementID, UnityAds.UnityAdsShowError IUnityAdErrorPlayBack, String message) {
			        com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, message, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
				       	@Override
				       	public void onClick(View _view) {}
				        }).show();
			    }
		
		    @Override
		    public void onUnityAdsShowStart(String __UnityPlacementID) {}
		    @Override
		    public void onUnityAdsShowClick(String __UnityPlacementID) {}
		    @Override
		    public void onUnityAdsShowComplete(String __UnityPlacementID, UnityAds.UnityAdsShowCompletionState __UnityAdsState) {
			        if (__UnityAdsState == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
				            if (__UnityPlacementID.equals("Rewarded_Android")) {
					                _purchase();
					            }
				
				            if (__UnityPlacementID.equals("Interstitial_Android")) {
					                _purchase();
					            }
				        } else if (__UnityAdsState == UnityAds.UnityAdsShowCompletionState.SKIPPED) {
				            if (__UnityPlacementID.equals("Rewarded_Android") || __UnityPlacementID.equals("Interstitial_Android")) {
					                _purchase();
					            }
				        }
			    }
	};
	{
		//End: "Unity ad show listlinear"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	public void _get_it() {
		if (userDataMap.get("account type").toString().equals("premium")) {
			if (extractMap.get("ad type").toString().equals("no ad")) {
				MaterialAlertDialogBuilder confirmDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
				confirmDialog.setTitle("Do you really want to take this?");
				confirmDialog.setMessage("If you really want to take this without the add, click the next button below.");
				confirmDialog.setPositiveButton("Next", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						        _purchase();
						    }
				});
				confirmDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						         
						    }
				});
				confirmDialog.setCancelable(true);
				confirmDialog.create().show();
			} else {
				if (userDataMap.get("account type").toString().equals("premium")) {
					MaterialAlertDialogBuilder confirmDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
					confirmDialog.setTitle("Do you really want to take this?");
					confirmDialog.setMessage("If you really want to take this without the add, click the next button below.");
					confirmDialog.setPositiveButton("Next", new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface _dialog, int _which) {
							        _purchase();
							    }
					});
					confirmDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface _dialog, int _which) {
							         
							    }
					});
					confirmDialog.setCancelable(true);
					confirmDialog.create().show();
				} else {
					MaterialAlertDialogBuilder adDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
					adDialog.setTitle("Ad watch need!");
					adDialog.setMessage("You need to watch an ad to continue purchasing.");
					adDialog.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface _dialog, int _which) {
							        adLoader.show("Loading ads....");
							if (extractMap.get("ad type").toString().equals("rewarded")) {
								// Start: "Load rewarded ad"
								UnityAds.load("Rewarded_Android", loadListener);
								//End: "Load rewarded ad"
							} else {
								// Start: "Load interstitial ad"
								UnityAds.load("Interstitial_Android", loadListener);
								//End: "Load interstitial ad"
							}
							    }
					});
					adDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface _dialog, int _which) {
							         
							    }
					});
					adDialog.setCancelable(true);
					adDialog.create().show();
				}
			}
		} else {
			if (extractMap.get("price").toString().equals("premium")) {
				MaterialAlertDialogBuilder premiumDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
				premiumDialog.setTitle("Premium purchase required!");
				premiumDialog.setMessage("If you want to get this template, you must have a premium account. If not, click the button below to purchase premium.");
				premiumDialog.setPositiveButton("I'm sorry", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						         
						    }
				});
				premiumDialog.setNegativeButton("Buy now!", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						        premiumIntent.setClass(getApplicationContext(), PlanActivity.class);
						ActivityOptions premiumIntentOp = ActivityOptions.makeCustomAnimation(ViewTemplatesActivity.this, R.anim.fade_in, R.anim.fade_out);
						startActivity(premiumIntent, premiumIntentOp.toBundle());

						finish();
						    }
				});
				premiumDialog.setCancelable(false);
				premiumDialog.create().show();
			} else {
				if (extractMap.get("ad type").toString().equals("no ad")) {
					MaterialAlertDialogBuilder confirmDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
					confirmDialog.setTitle("Do you really want to take this?");
					confirmDialog.setMessage("If you really want to take this without the add, click the next button below.");
					confirmDialog.setPositiveButton("Next", new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface _dialog, int _which) {
							        _purchase();
							    }
					});
					confirmDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface _dialog, int _which) {
							         
							    }
					});
					confirmDialog.setCancelable(true);
					confirmDialog.create().show();
				} else {
					if (userDataMap.get("account type").toString().equals("premium")) {
						MaterialAlertDialogBuilder confirmDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
						confirmDialog.setTitle("Do you really want to take this?");
						confirmDialog.setMessage("If you really want to take this without the add, click the next button below.");
						confirmDialog.setPositiveButton("Next", new DialogInterface.OnClickListener() {
							    @Override
							    public void onClick(DialogInterface _dialog, int _which) {
								        _purchase();
								    }
						});
						confirmDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
							    @Override
							    public void onClick(DialogInterface _dialog, int _which) {
								         
								    }
						});
						confirmDialog.setCancelable(true);
						confirmDialog.create().show();
					} else {
						MaterialAlertDialogBuilder adDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
						adDialog.setTitle("Ad watch need!");
						adDialog.setMessage("You need to watch an ad to continue purchasing.");
						adDialog.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
							    @Override
							    public void onClick(DialogInterface _dialog, int _which) {
								        adLoader.show("Loading ads....");
								if (extractMap.get("ad type").toString().equals("rewarded")) {
									// Start: "Load rewarded ad"
									UnityAds.load("Rewarded_Android", loadListener);
									//End: "Load rewarded ad"
								} else {
									// Start: "Load interstitial ad"
									UnityAds.load("Interstitial_Android", loadListener);
									//End: "Load interstitial ad"
								}
								    }
						});
						adDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
							    @Override
							    public void onClick(DialogInterface _dialog, int _which) {
								         
								    }
						});
						adDialog.setCancelable(true);
						adDialog.create().show();
					}
				}
			}
		}
	}
	
	
	public void _purchase() {
		if (extractMap.containsKey("template file type")) {
			if (extractMap.get("template file type").toString().equals("upload")) {
				_Database("upload");
			} else {
				if (extractMap.get("template file type").toString().equals("direct link")) {
					_Database("direct link");
				} else {
					if (extractMap.get("template file type").toString().equals("collect email")) {
						_purchase_mode("collect email");
					} else {
						if (extractMap.get("template file type").toString().equals("direct massage")) {
							_Database("direct massage");
						}
					}
				}
			}
		}
	}
	
	
	public void _Database(final String _mode) {
		purchaseLoader.show("Purchasing.....");
		date = Calendar.getInstance();
		if (_mode.equals("upload") || _mode.equals("direct link")) {
			DatabaseValueMap = new HashMap<>();
			DatabaseHeaderMap = new HashMap<>();
			getsRqMap = new Gson().fromJson("{" + "\"" + "gets" + "\":\"" + String.valueOf((long)(Double.parseDouble(extractMap.get("gets").toString()) + 1)) + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
			OkHttpClient client = new OkHttpClient();
			Request request = new Request.Builder()
			    .url(getString(R.string.database_url) + "/rest/v1/" + "templates" + "?main key=eq." + extractMap.get("main key").toString())
			    .addHeader("apikey", getString(R.string.database_api_key))
			    .patch(RequestBody.create(
			        MediaType.parse("application/json; charset=utf-8"),
			        new Gson().toJson(getsRqMap)
			    ))
			    .build();
			client.newCall(request).enqueue(new Callback() {
				    @Override
				    public void onFailure(Call call, IOException e) {
					        final String errorMessage = e.getMessage();
					        new Handler(Looper.getMainLooper()).post(new Runnable() {
						            @Override
						            public void run() {
							                com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
							            }
						        });
					    }
				    @Override
				    public void onResponse(Call call, Response response) throws IOException {
					        final String responseMessage = response.body().string(); 
					        if (response.isSuccessful()) {
						            new Handler(Looper.getMainLooper()).post(new Runnable() {
							                @Override
							                public void run() {
								                    DatabaseHeaderMap.put("apikey", getString(R.string.database_api_key));
								DatabaseHeaderMap.put("Content-Type", "application/json");
								purchase_key = title;
								DatabaseValueMap.put("uid", save.getString("user id", ""));
								DatabaseValueMap.put("purchase key", purchase_key);
								DatabaseValueMap.put("massage", fileUrl);
								DatabaseValueMap.put("file type", extractMap.get("template file type").toString());
								DatabaseValueMap.put("status", "success");
								DatabaseValueMap.put("date", new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a").format(date.getTime()));
								directionRq.setHeaders(DatabaseHeaderMap); directionRq.setParams(DatabaseValueMap, RequestNetworkController.REQUEST_PARAM); directionRq.startRequestNetwork(RequestNetworkController.POST, getString(R.string.database_url) + "/rest/v1/" + "template history", "upload", _directionRq_request_listener);
								_FasterNotificationSender("Template request received!", "key - ".concat(purchase_key), "", "", "admin", "", "");
								                }
							            });
						        } else {
						            new Handler(Looper.getMainLooper()).post(new Runnable() {
							                @Override
							                public void run() {
								                    com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, "There are some problems with this template, so data cannot be added.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
								                }
							            });
						        }
					    }
			});
		} else {
			getsRqMap = new Gson().fromJson("{" + "\"" + "gets" + "\":\"" + String.valueOf((long)(Double.parseDouble(extractMap.get("gets").toString()) + 1)) + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
			OkHttpClient client = new OkHttpClient();
			Request request = new Request.Builder()
			    .url(getString(R.string.database_url) + "/rest/v1/" + "templates" + "?main key=eq." + extractMap.get("main key").toString())
			    .addHeader("apikey", getString(R.string.database_api_key))
			    .patch(RequestBody.create(
			        MediaType.parse("application/json; charset=utf-8"),
			        new Gson().toJson(getsRqMap)
			    ))
			    .build();
			client.newCall(request).enqueue(new Callback() {
				    @Override
				    public void onFailure(Call call, IOException e) {
					        final String errorMessage = e.getMessage();
					        new Handler(Looper.getMainLooper()).post(new Runnable() {
						            @Override
						            public void run() {
							                com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
							            }
						        });
					    }
				    @Override
				    public void onResponse(Call call, Response response) throws IOException {
					        final String responseMessage = response.body().string(); 
					        if (response.isSuccessful()) {
						            new Handler(Looper.getMainLooper()).post(new Runnable() {
							                @Override
							                public void run() {
								                    DatabaseValueMap = new HashMap<>();
								DatabaseHeaderMap = new HashMap<>();
								DatabaseHeaderMap.put("apikey", getString(R.string.database_api_key));
								DatabaseHeaderMap.put("Content-Type", "application/json");
								purchase_key = title;
								DatabaseValueMap.put("uid", save.getString("user id", ""));
								DatabaseValueMap.put("purchase key", purchase_key);
								DatabaseValueMap.put("massage", email);
								DatabaseValueMap.put("file type", extractMap.get("template file type").toString());
								DatabaseValueMap.put("status", "pending");
								DatabaseValueMap.put("date", new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a").format(date.getTime()));
								directionRq.setHeaders(DatabaseHeaderMap); directionRq.setParams(DatabaseValueMap, RequestNetworkController.REQUEST_PARAM); directionRq.startRequestNetwork(RequestNetworkController.POST, getString(R.string.database_url) + "/rest/v1/" + "template history", "other", _directionRq_request_listener);
								_FasterNotificationSender("Template request received!", "key - ".concat(purchase_key), "", "", "admin", "", "");
								                }
							            });
						        } else {
						            new Handler(Looper.getMainLooper()).post(new Runnable() {
							                @Override
							                public void run() {
								                    com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, "There are some problems with this template, so data cannot be added.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
								                }
							            });
						        }
					    }
			});
		}
	}
	
	
	public void _purchase_mode(final String _mode) {
		if (_mode.equals("upload")) {
			MaterialAlertDialogBuilder DownloadDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
			DownloadDialog.setTitle("Do you want to download the template now?");
			DownloadDialog.setMessage("If you want to download the template file now, click on the Yes button. If you want to download it later, click on the Later button.");
			DownloadDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				    @Override
				    public void onClick(DialogInterface _dialog, int _which) {
					        if (fileUrl.isEmpty()) {
						com.google.android.material.snackbar.Snackbar.make(linear_bottom_content, "File not found!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					} else {
						DownLoader.show("Download starting....");
						fasterDown.startDownload(fileUrl, title + ".zip");
						fasterDown.setOnDownloadListener(new FasterFileDownloader.OnDownloadListener() {
							@Override
							public void onProgress(int percent) {
								DownLoader.updateMessage("Downloading ".concat(String.valueOf((long)(percent)).concat("/100%")));
							}
							@Override
							public void onSuccess(String savedFilePath) {
								DownLoader.dismiss();
								MaterialAlertDialogBuilder downloaderDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
								downloaderDialog.setTitle("Download success!");
								downloaderDialog.setMessage("Your file has been downloaded to: ".concat(savedFilePath));
								downloaderDialog.setPositiveButton("Okay!", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								downloaderDialog.setCancelable(true);
								downloaderDialog.create().show();
							}
							@Override
							public void onError(String reason) {
								DownLoader.dismiss();
								MaterialAlertDialogBuilder downloaderDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
								downloaderDialog.setTitle("Download success!");
								downloaderDialog.setMessage("Your template could not be downloaded! Reason: ".concat(reason));
								downloaderDialog.setPositiveButton("Okay!", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								downloaderDialog.setCancelable(true);
								downloaderDialog.create().show();
							}
						});
					}
					    }
			});
			DownloadDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
				    @Override
				    public void onClick(DialogInterface _dialog, int _which) {
					        MaterialAlertDialogBuilder purchaseSuccessfulDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
					purchaseSuccessfulDialog.setTitle("Purchase successful!");
					purchaseSuccessfulDialog.setMessage("You can now check the history if you want to see if the template was successful.");
					purchaseSuccessfulDialog.setPositiveButton("Check history!", new DialogInterface.OnClickListener() {
						    @Override
						    public void onClick(DialogInterface _dialog, int _which) {
							        successintent.setClass(getApplicationContext(), TemplateHistoryActivity.class);
							ActivityOptions successintentOp = ActivityOptions.makeCustomAnimation(ViewTemplatesActivity.this, R.anim.fade_in, R.anim.fade_out);
							startActivity(successintent, successintentOp.toBundle());

							finish();
							    }
					});
					purchaseSuccessfulDialog.setCancelable(false);
					purchaseSuccessfulDialog.create().show();
					    }
			});
			DownloadDialog.setCancelable(false);
			DownloadDialog.create().show();
		} else {
			if (_mode.equals("collect email")) {
				MaterialAlertDialogBuilder collectEmailDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
				collectEmailDialog.setTitle("Enter your email!");
				collectEmailDialog.setMessage("Enter your email below, the admin will check it and give you access to your template via email. You will then be given a link.");
				View collectEmailDesign = LayoutInflater.from(ViewTemplatesActivity.this).inflate(R.layout.collect_email_dialog, null);
				collectEmailDialog.setView(collectEmailDesign);

				final EditText edittext_email = collectEmailDesign.findViewById(R.id.edittext_email);
				collectEmailDialog.setPositiveButton("Next", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						        email = edittext_email.getText().toString();
						_Database("collect email");
						    }
				});
				collectEmailDialog.setCancelable(true);
				collectEmailDialog.create().show();
			}
		}
	}
	
	
	public void _FasterNotificationSender(final String _title, final String _body, final String _imageUrl, final String _contextactivity, final String _topic, final String _token, final String _extraText) {
		notification_map = new HashMap<>();
		notification_map.put("title", _title);
		notification_map.put("body", _body);
		if (!_imageUrl.equals("")) {
			notification_map.put("image", _imageUrl);
		}
		if (!_extraText.equals("")) {
			notification_map.put("extraData", _extraText);
		}
		if (!_contextactivity.equals("")) {
			notification_map.put("ContextActivity", _contextactivity);
		}
		if (_token.equals("")) {
			// Start: "Send notification with topic"
			    String topic = _topic;
			    String token = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with topic"
		} else {
			// Start: "Send notification with token"
			    String token = _token;
			    String topic = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with token"
		}
	}
	
	
	public void _m3ErrorDialog(final String _massage) {
		MaterialAlertDialogBuilder errorDialog = new MaterialAlertDialogBuilder(ViewTemplatesActivity.this);
		errorDialog.setTitle("Error!");
		errorDialog.setMessage(_massage);
		errorDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		errorDialog.setCancelable(true);
		errorDialog.create().show();
	}
	
}
