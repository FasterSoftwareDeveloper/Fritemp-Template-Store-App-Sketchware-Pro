package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;


public class ViewAllActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
RealTimeNetworkHelper networkHelper;
	
	private HashMap<String, Object> userRqMap = new HashMap<>();
	private HashMap<String, Object> userDataMap = new HashMap<>();
	private HashMap<String, Object> searchRqMap = new HashMap<>();
	private double peekPosition = 0;
	private PeekAndPop peekAndPop;
	private String isSearch = "";
	private double peekPosition2 = 0;
	
	private ArrayList<HashMap<String, Object>> userDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> templateListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> landscapeListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> portraitListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> searchListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private GridView gridview1;
	private ListView listview1;
	private LinearLayout linear_status;
	private TextInputLayout textinput_search;
	private EditText edittext_search;
	private TextView textview1;
	
	private RequestNetwork userRq;
	private RequestNetwork.RequestListener _userRq_request_listener;
	private RequestNetwork templateRq;
	private RequestNetwork.RequestListener _templateRq_request_listener;
	private SharedPreferences save;
	private RequestNetwork searchRq;
	private RequestNetwork.RequestListener _searchRq_request_listener;
	private Intent backIntent = new Intent();
	private Intent viewIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view_all);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		gridview1 = findViewById(R.id.gridview1);
		listview1 = findViewById(R.id.listview1);
		linear_status = findViewById(R.id.linear_status);
		textinput_search = findViewById(R.id.textinput_search);
		edittext_search = findViewById(R.id.edittext_search);
		textview1 = findViewById(R.id.textview1);
		userRq = new RequestNetwork(this);
		templateRq = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		searchRq = new RequestNetwork(this);
		
		edittext_search.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.equals("")) {
					if (getIntent().getStringExtra("template type").equals("landscape")) {
						listview1.setVisibility(View.VISIBLE);
						linear_status.setVisibility(View.GONE);
						gridview1.setVisibility(View.GONE);
					} else {
						listview1.setVisibility(View.GONE);
						linear_status.setVisibility(View.GONE);
						gridview1.setVisibility(View.VISIBLE);
					}
				} else {
					if (getIntent().getStringExtra("template type").equals("landscape")) {
						searchRqMap = new HashMap<>(); 
						searchRqMap.put("apikey", getString(R.string.database_api_key));
						searchRq.setHeaders(searchRqMap);
						searchRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "title" + "=ilike.*" + _charSeq + "*" + "&" + "item category" + "=eq." + getIntent().getStringExtra("item category") + "&" + "&" + "template type" + "=eq." + "landscape" + "&", "A", _searchRq_request_listener);
					} else {
						searchRqMap = new HashMap<>(); 
						searchRqMap.put("apikey", getString(R.string.database_api_key));
						searchRq.setHeaders(searchRqMap);
						searchRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "title" + "=ilike.*" + _charSeq + "*" + "&" + "item category" + "=eq." + getIntent().getStringExtra("item category") + "&" + "&" + "template type" + "=eq." + "portrait" + "&", "B", _searchRq_request_listener);
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_userRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (save.getString("authentication", "").equals("yes")) {
					try {
						userDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						userDataMap = userDataListMap.get((int)0);
						templateRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?apikey=" + getString(R.string.database_api_key), "", _templateRq_request_listener);
					} catch (Exception e) {
						 
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_templateRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				templateListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				if (getIntent().getStringExtra("template type").equals("landscape")) {
					listview1.setVisibility(View.VISIBLE);
					landscapeListMap.clear();
					for (HashMap<String, Object> item : templateListMap) {
						    if (getIntent().getStringExtra("item category").equals(String.valueOf(item.get("item category"))) &&
						        getIntent().getStringExtra("template type").equals(String.valueOf(item.get("template type")))) {
							        landscapeListMap.add(item);
							    }
					}
					listview1.setAdapter(new Listview1Adapter(landscapeListMap));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				} else {
					gridview1.setVisibility(View.VISIBLE);
					portraitListMap.clear();
					for (HashMap<String, Object> item : templateListMap) {
						    if (getIntent().getStringExtra("item category").equals(String.valueOf(item.get("item category"))) &&
						        getIntent().getStringExtra("template type").equals(String.valueOf(item.get("template type")))) {
							        portraitListMap.add(item);
							    }
					}
					gridview1.setAdapter(new Gridview1Adapter(portraitListMap));
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_searchRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				searchListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				isSearch = "yes";
				if (edittext_search.getText().toString().equals("")) {
					if (getIntent().getStringExtra("template type").equals("landscape")) {
						listview1.setVisibility(View.VISIBLE);
						gridview1.setVisibility(View.GONE);
						linear_status.setVisibility(View.GONE);
					} else {
						listview1.setVisibility(View.GONE);
						gridview1.setVisibility(View.VISIBLE);
						linear_status.setVisibility(View.GONE);
					}
				} else {
					if (_response.equals("[]")) {
							linear_status.setVisibility(View.VISIBLE);
						listview1.setVisibility(View.GONE);
						gridview1.setVisibility(View.GONE);
					} else {
							if (_tag.equals("A")) {
							listview1.setVisibility(View.VISIBLE);
							linear_status.setVisibility(View.GONE);
							gridview1.setVisibility(View.GONE);
							listview1.setAdapter(new Listview1Adapter(searchListMap));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						} else {
							listview1.setVisibility(View.GONE);
							linear_status.setVisibility(View.GONE);
							gridview1.setVisibility(View.VISIBLE);
							gridview1.setAdapter(new Gridview1Adapter(searchListMap));
						}
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "database"
		userRqMap = new HashMap<>(); 
		userRqMap.put("apikey", getString(R.string.database_api_key));
		userRq.setHeaders(userRqMap);
		userRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + save.getString("user id", "") + "&", "", _userRq_request_listener);
		//End: "database"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), DashboardActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(ViewAllActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());

				finish();
			}
		});

		gridview1.setVisibility(View.GONE);
		listview1.setVisibility(View.GONE);
		linear_status.setVisibility(View.GONE);
		isSearch = "";
		// Start: "over scroll checker"
		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
			if (save.getString("over scroll", "").equals("on")) {
				OverScrollDecoratorHelper.setUpOverScroll(listview1);
				OverScrollDecoratorHelper.setUpOverScroll(gridview1);
			}
		}
		//End: "over scroll checker"
		// Start: "Network checker"
		networkHelper = new RealTimeNetworkHelper(this, status -> {
			        switch (status) {
				            case NO_NETWORK:
				                Intent SecurityIntent = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent.putExtra("activity name", "no internet");
				                ActivityOptions SecurityIntentOp = ActivityOptions.makeCustomAnimation(ViewAllActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent, SecurityIntentOp.toBundle());
				                finish();
				                break;
				            case CONNECTED_NO_INTERNET:
				                Intent SecurityIntent2 = new Intent(getApplicationContext(), SecurityCheckerActivity.class);
				                SecurityIntent2.putExtra("activity name", "no internet access");
				                ActivityOptions SecurityIntentOp2 = ActivityOptions.makeCustomAnimation(ViewAllActivity.this, R.anim.fade_in, R.anim.fade_out);
				                startActivity(SecurityIntent2, SecurityIntentOp2.toBundle());
				                finish();
				                break;
				            case CONNECTED_WITH_INTERNET:
				                break;
				        }
			    });
		    networkHelper.register();
		//End: "Network checker"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (networkHelper != null) networkHelper.unregister();
	}
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.portrait, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        ViewAllActivity.this, linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition = _position;
							peekAndPop = new PeekAndPop.Builder(ViewAllActivity.this)
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							if (isSearch.equals("")) {
								peekText.setText(portraitListMap.get((int)peekPosition).get("category").toString());
								peekText2.setText(portraitListMap.get((int)peekPosition).get("media type").toString());
								peekText3.setText(portraitListMap.get((int)peekPosition).get("item category").toString());
							} else {
								peekText.setText(searchListMap.get((int)peekPosition).get("category").toString());
								peekText2.setText(searchListMap.get((int)peekPosition).get("media type").toString());
								peekText3.setText(searchListMap.get((int)peekPosition).get("item category").toString());
							}
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
			
			return _view;
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.landscape, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_body = _view.findViewById(R.id.linear_body);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final com.google.android.material.card.MaterialCardView linear_download = _view.findViewById(R.id.linear_download);
			final com.google.android.material.card.MaterialCardView linear_type = _view.findViewById(R.id.linear_type);
			final TextView textview_download = _view.findViewById(R.id.textview_download);
			final TextView textview_title = _view.findViewById(R.id.textview_title);
			
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("price")) {
				if (userDataMap.containsKey("account type")) {
					if (userDataMap.get("account type").toString().equals("premium")) {
						textview_title.setText("Unlocked");
					} else {
						if (_data.get((int)_position).get("price").toString().equals("free")) {
							textview_title.setText("Free");
						} else {
							textview_title.setText("Premium");
						}
					}
				} else {
					if (_data.get((int)_position).get("price").toString().equals("free")) {
						textview_title.setText("Free");
					} else {
						textview_title.setText("Premium");
					}
				}
			}
			if (_data.get((int)_position).containsKey("gets")) {
				textview_download.setText(_data.get((int)_position).get("gets").toString().concat(" gets"));
			}
			linear_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					viewIntent.setClass(getApplicationContext(), ViewTemplatesActivity.class);
					viewIntent.putExtra("key", _data.get((int)_position).get("main key").toString());
					viewIntent.putExtra("template type", _data.get((int)_position).get("template type").toString());
					viewIntent.putExtra("media type", _data.get((int)_position).get("media type").toString());
					ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(
					        ViewAllActivity.this, linear_body, "shared_product_container"
					    );
					startActivity(viewIntent, options.toBundle());
				}
			});
			linear_body.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					peekPosition2 = _position;
							peekAndPop = new PeekAndPop.Builder(ViewAllActivity.this)
							        .peekLayout(R.layout.peek_view)
					                .longClickViews(linear_body)
							        .build();
							
							peekAndPop.setOnGeneralActionListener(new PeekAndPop.OnGeneralActionListener() {
									    @Override
									    public void onPeek(View longClickView, int position) {
											        View peekView = peekAndPop.getPeekView();
											        TextView peekText = peekView.findViewById(R.id.textview_category);
											        TextView peekText2 = peekView.findViewById(R.id.textview_media_type);
											        TextView peekText3 = peekView.findViewById(R.id.textview_item_category);
							if (isSearch.equals("")) {
								peekText.setText(portraitListMap.get((int)peekPosition2).get("category").toString());
								peekText2.setText(portraitListMap.get((int)peekPosition2).get("media type").toString());
								peekText3.setText(portraitListMap.get((int)peekPosition2).get("item category").toString());
							} else {
								peekText.setText(searchListMap.get((int)peekPosition2).get("category").toString());
								peekText2.setText(searchListMap.get((int)peekPosition2).get("media type").toString());
								peekText3.setText(searchListMap.get((int)peekPosition2).get("item category").toString());
							}
											    }
									
									    @Override
									    public void onPop(View longClickView, int position) {
											    }
							});
					return true;
				}
			});
			
			return _view;
		}
	}
}
