package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.firebase.messaging.FirebaseMessaging;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> getDataMap = new HashMap<>();
	private String app_version = "";
	private String database_app_version = "";
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	
	private RelativeLayout relativelayout1;
	private ImageView animatedImage;
	
	private TimerTask timer;
	private Intent intent = new Intent();
	private SharedPreferences save;
	private Intent app_mode_intent = new Intent();
	private Calendar date = Calendar.getInstance();
	private OnCompleteListener needit_onCompleteListener;
	private Intent Open = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SplashScreen.installSplashScreen(this);
        }
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
    setContentView(R.layout.main);
    relativelayout1 = findViewById(R.id.relativelayout1);
    animatedImage = findViewById(R.id.animatedImage);

    timer = new TimerTask() {
        @Override
        public void run() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    _activity();
                    timer.cancel();
                }
            });
        }
    };

    _timer.schedule(timer,600);
}
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {


		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
	}
	
	private void initializeLogic() {
		// Start: "Theme Checker"
		if (save.contains("theme")) {
			if (save.getString("theme", "").equals("system default")) {
				AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
			} else {
				if (save.getString("theme", "").equals("light")) {
					AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
				} else {
					if (save.getString("theme", "").equals("dark")) {
						AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
					}
				}
			}
		} else {
			save.edit().putString("theme", "system default").commit();
		}
		//End: "Theme Checker"
		// Start: "Authentication & New user checker"
		if (!save.contains("authentication")) {
			save.edit().putString("authentication", "no").commit();
			save.edit().putString("email", "").commit();
			save.edit().putString("password", "").commit();
			save.edit().putString("user id", "").commit();
		}
		if (!save.contains("new_user")) {
			save.edit().putString("new_user", "yes").commit();
		}
		if (!save.contains("over scroll")) {
			save.edit().putString("over scroll", "on").commit();
		}
		if (!save.contains("blur")) {
			if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
				save.edit().putString("blur", "on").commit();
			} else {
				save.edit().putString("blur", "off").commit();
			}
		}
		//End: "Authentication & New user checker"
		// Start: "Enable Splash Screen API"
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
			            _activity();
			        }
		//End: "Enable Splash Screen API"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				finishAffinity();
			}
		});

		// Start: "Subscribe fcm topic"
		FirebaseMessaging.getInstance().subscribeToTopic("user")
		    .addOnCompleteListener(new OnCompleteListener<Void>() {
			        @Override
			        public void onComplete(@NonNull Task<Void> task) {
				            if (task.isSuccessful()) {
					            } else {
					            }
				        }
			    });
		//End: "Subscribe fcm topic"
		// Start: "Get user notification token"
		FirebaseMessaging.getInstance().getToken()
				.addOnCompleteListener(new OnCompleteListener<String>() {
					@Override
					public void onComplete(@NonNull Task<String> task) {
						if (task.isSuccessful()) {
							String token = task.getResult();
							save.edit().putString("notification token", token).commit();
						} else {
							save.edit().putString("notification token", "none").commit();
						}
					}
				});
		//End: "Get user notification token"
	}
	
	public void _activity() {
		if (getIntent().hasExtra("extraData")) {
			try {
				if (getIntent().getStringExtra("extraData").startsWith("http://") || getIntent().getStringExtra("extraData").startsWith("https://")) {
					Open.setAction(Intent.ACTION_VIEW);
					Open.setData(Uri.parse(getIntent().getStringExtra("extraData")));
					startActivity(Open);
				} else {
					_mainactivity();
				}
			} catch (Exception e) {
				_mainactivity();
			}
		} else {
			_mainactivity();
		}
	}
	
	
	public void _mainactivity() {
		if (save.getString("new_user", "").equals("yes")) {
			intent.setClass(getApplicationContext(), NewUserActivity.class);
			ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
			startActivity(intent, intentOp.toBundle());

			finish();
		} else {
			if (save.getString("authentication", "").equals("no")) {
				intent.setClass(getApplicationContext(), AuthenticationActivity.class);
				ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(intent, intentOp.toBundle());

				finish();
			} else {
				if (save.getString("authentication", "").equals("yes")) {
					intent.setClass(getApplicationContext(), DashboardActivity.class);
					ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
					startActivity(intent, intentOp.toBundle());

					finish();
				}
			}
		}
	}
	
}
