package yt.fritemp.faster;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.peekandpop.shalskar.peekandpop.*;
import com.unity3d.ads.*;
import eightbitlab.com.blurview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import me.everything.*;
import okhttp3.*;
import org.json.*;

public class VideoPlayerActivity extends AppCompatActivity {

private FasterM3BottomSheetLoader loader;
	
	private String url = "";
	private String videoUrl = "";
	
	private LinearLayout linear1;
	private VideoView videoview1;
	
	private Intent videoViewIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.video_player);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		videoview1 = findViewById(R.id.videoview1);
		MediaController videoview1_controller = new MediaController(this);
		videoview1.setMediaController(videoview1_controller);
		
		linear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				videoview1.performClick();
			}
		});
		
		videoview1.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
			@Override
			public void onPrepared(MediaPlayer _mediaPlayer) {
				loader.dismiss();
			}
		});
	}
	
	private void initializeLogic() {
		videoUrl = getIntent().getStringExtra("video url");
		videoview1.setVideoURI(Uri.parse(videoUrl));
		videoview1.start();
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				videoViewIntent.setClass(getApplicationContext(), ViewTemplatesActivity.class);
				videoViewIntent.putExtra("media type", getIntent().getStringExtra("media type"));
				videoViewIntent.putExtra("template type", getIntent().getStringExtra("template type"));
				videoViewIntent.putExtra("key", getIntent().getStringExtra("key"));
				ActivityOptions videoViewIntentOp = ActivityOptions.makeCustomAnimation(VideoPlayerActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(videoViewIntent, videoViewIntentOp.toBundle());

				finish();
			}
		});

		loader = new FasterM3BottomSheetLoader(VideoPlayerActivity.this);
		loader.setCancelableOnOutsideClick(false);
		loader.show("Video is preparing.....");
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		try {
			videoview1.stopPlayback();
		} catch (Exception e) {
			 
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		videoview1.start();
	}
}
