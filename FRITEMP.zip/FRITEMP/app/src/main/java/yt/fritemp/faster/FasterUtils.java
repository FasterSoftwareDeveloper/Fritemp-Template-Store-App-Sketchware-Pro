package yt.fritemp.faster;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.os.LocaleList;
import android.provider.Settings;

import java.util.Locale;

public class FasterUtils {

    // Call examples:
    // String deviceId = FasterUtils.getDeviceId(MainActivity.this);
    // FasterUtils.copyToClipboard(MainActivity.this, "Label", "Copied Text");

    public static String getSystemLanguage(Context context) {
        LocaleList localeList = context.getResources().getConfiguration().getLocales();
        if (!localeList.isEmpty()) {
            return localeList.get(0).getLanguage();
        }
        return Locale.getDefault().getLanguage();
    }

    public static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static void copyToClipboard(Context context, String label, String text) {
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText(label, text);
            clipboard.setPrimaryClip(clip);
        }
    }
}