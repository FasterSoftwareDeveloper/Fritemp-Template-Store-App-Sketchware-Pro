package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.*;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;
import android.transition.Transition;
import androidx.core.content.ContextCompat;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

public class DepositLisrActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }
	
	private HashMap<String, Object> searchData = new HashMap<>();
	private HashMap<String, Object> getDataMap2 = new HashMap<>();
	private HashMap<String, Object> getAndsetData = new HashMap<>();
	private HashMap<String, Object> requestDataMap = new HashMap<>();
	private HashMap<String, Object> updateDataMap = new HashMap<>();
	private HashMap<String, Object> updateDataMap2 = new HashMap<>();
	private String money = "";
	private String user_id = "";
	private HashMap<String, Object> dollarRqMap = new HashMap<>();
	private HashMap<String, Object> setDollarMap = new HashMap<>();
	private HashMap<String, Object> notification_map = new HashMap<>();
	private String notification_token = "";
	private HashMap<String, Object> rqMap = new HashMap<>();
	private HashMap<String, Object> tokenMap = new HashMap<>();
	private String key = "";
	private String onSuccess = "";
	private String onError = "";
	private String accessTokenError = "";
	private String accessToken = "";
	private String ProjectID = "";
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> getDataListMap2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> setDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> setDollarListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> tokenListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextInputLayout layout1;
	private MaterialButtonToggleGroup linear_selection;
	private LinearLayout linear_status;
	private ListView listview_pending;
	private ListView listview_success;
	private ListView listview_rejected;
	private EditText et1;
	private MaterialButton button_pending;
	private MaterialButton button5;
	private MaterialButton button6;
	private TextView textview2;
	
	private RequestNetwork rq_get_data;
	private RequestNetwork.RequestListener _rq_get_data_request_listener;
	private RequestNetwork deleteData;
	private RequestNetwork.RequestListener _deleteData_request_listener;
	private AlertDialog.Builder dialog;
	private Intent gointent = new Intent();
	private AlertDialog.Builder errorDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.deposit_lisr);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		layout1 = findViewById(R.id.layout1);
		linear_selection = findViewById(R.id.linear_selection);
		linear_status = findViewById(R.id.linear_status);
		listview_pending = findViewById(R.id.listview_pending);
		listview_success = findViewById(R.id.listview_success);
		listview_rejected = findViewById(R.id.listview_rejected);
		et1 = findViewById(R.id.et1);
		button_pending = findViewById(R.id.button_pending);
		button5 = findViewById(R.id.button5);
		button6 = findViewById(R.id.button6);
		textview2 = findViewById(R.id.textview2);
		rq_get_data = new RequestNetwork(this);
		deleteData = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		errorDialog = new AlertDialog.Builder(this);
		
		et1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				searchData = new HashMap<>(); 
				searchData.put("apikey", getString(R.string.database_api_key));
				rq_get_data.setHeaders(searchData);
				rq_get_data.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=ilike.*" + _charSeq + "*", "B", _rq_get_data_request_listener);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button_pending.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview_pending.setVisibility(View.VISIBLE);
				listview_success.setVisibility(View.GONE);
				listview_rejected.setVisibility(View.GONE);
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview_pending.setVisibility(View.GONE);
				listview_success.setVisibility(View.VISIBLE);
				listview_rejected.setVisibility(View.GONE);
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview_pending.setVisibility(View.GONE);
				listview_success.setVisibility(View.GONE);
				listview_rejected.setVisibility(View.VISIBLE);
			}
		});
		
		_rq_get_data_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						linear_status.setVisibility(View.VISIBLE);
					_TransitionManager(linear1, 300);
					com.google.android.material.snackbar.Snackbar.make(linear1, "Data get failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
						getDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					Collections.reverse(getDataListMap);
					listview_pending.setAdapter(new Listview_pendingAdapter(getDataListMap));
					((BaseAdapter)listview_pending.getAdapter()).notifyDataSetChanged();
					listview_success.setAdapter(new Listview_successAdapter(getDataListMap));
					((BaseAdapter)listview_success.getAdapter()).notifyDataSetChanged();
					listview_rejected.setAdapter(new Listview_rejectedAdapter(getDataListMap));
					((BaseAdapter)listview_rejected.getAdapter()).notifyDataSetChanged();
					linear_status.setVisibility(View.GONE);
					_TransitionManager(linear1, 300);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_deleteData_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						_TransitionManager(linear1, 300);
					linear_status.setVisibility(View.VISIBLE);
					com.google.android.material.snackbar.Snackbar.make(linear1, "Data get failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
						getDataListMap2 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					Collections.reverse(getDataListMap2);
					listview_pending.setAdapter(new Listview_pendingAdapter(getDataListMap2));
					((BaseAdapter)listview_pending.getAdapter()).notifyDataSetChanged();
					listview_success.setAdapter(new Listview_successAdapter(getDataListMap2));
					((BaseAdapter)listview_success.getAdapter()).notifyDataSetChanged();
					listview_rejected.setAdapter(new Listview_rejectedAdapter(getDataListMap2));
					((BaseAdapter)listview_rejected.getAdapter()).notifyDataSetChanged();
					linear_status.setVisibility(View.GONE);
					_TransitionManager(linear1, 300);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "ui"
		listview_success.setVisibility(View.GONE);
		listview_rejected.setVisibility(View.GONE);
		linear_status.setVisibility(View.GONE);
		//End: "ui"
		// Start: "get data"
		rq_get_data.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?apikey=" + getString(R.string.database_api_key), "A", _rq_get_data_request_listener);
		//End: "get data"
		// Start: "list view animation"
		Animation animation = AnimationUtils.loadAnimation(this, R.anim.listview_item_animation);
		listview_pending.setLayoutAnimation(new LayoutAnimationController(animation, 0.2f));
		Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.listview_item_animation);
		listview_success.setLayoutAnimation(new LayoutAnimationController(animation2, 0.2f));
		Animation animation3 = AnimationUtils.loadAnimation(this, R.anim.listview_item_animation);
		listview_rejected.setLayoutAnimation(new LayoutAnimationController(animation3, 0.2f));
		//End: "list view animation"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				gointent.setClass(getApplicationContext(), MainActivity.class);
				ActivityOptions gointentOp = ActivityOptions.makeCustomAnimation(DepositLisrActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(gointent, gointentOp.toBundle());
				finish();
			}
		});
		// Start: "Access an token"
		try {
			    try (InputStream originalInputStream = getAssets().open("service-account.json")) {
				        byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
					            HashMap<String, Object> map = new Gson().fromJson(
					                jsonString,
					                new TypeToken<HashMap<String, Object>>(){}.getType()
					            );
					            ProjectID = map.get("project_id").toString();
					        }
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.OnTokenResponse() {
						                @Override
						                public void onSuccess(String token) {
							                    JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
							                    if (jsonResponse.has("access_token")) {
								                        accessToken = jsonResponse.get("access_token").getAsString();
								                    } else {
								                        accessToken = "error getting accessToken";
								                    }
							                }
						
						                @Override
						                public void onError(String error) {
							                    accessTokenError = error;
							                    runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
							                }
						            });
					        }
				    } catch (IOException e) {
				        accessTokenError = "Error reading service account file: " + e.getMessage();
				        runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
				    }
		} catch (Exception e) {
			    runOnUiThread(() -> _m3ErrorDialog("Unexpected error: " + e.getMessage()));
		}
		//End: "Access an token"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _details_dialog(final String _key, final String _tag) {
		final
		com.google.android.material.bottomsheet.BottomSheetDialog DetailsDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(DepositLisrActivity.this);
		View detailsDialogDesign = getLayoutInflater().inflate(R.layout.details_sheet_dialog, null);
		DetailsDialog.setContentView(detailsDialogDesign);
		DetailsDialog.getWindow().getDecorView().setBackgroundColor(0);
		final TextView textview_id = detailsDialogDesign.findViewById(R.id.textview_id);
		final TextView textview_userid = detailsDialogDesign.findViewById(R.id.textview_userid);
		final TextView textview_status = detailsDialogDesign.findViewById(R.id.textview_status);
		final TextView textview3_date = detailsDialogDesign.findViewById(R.id.textview3_date);
		final TextView textview_key = detailsDialogDesign.findViewById(R.id.textview_key);
		final TextView textview_amount = detailsDialogDesign.findViewById(R.id.textview_amount);
		final Button button_reject = detailsDialogDesign.findViewById(R.id.button_reject);
		final Button button_success = detailsDialogDesign.findViewById(R.id.button_success);
		final LinearLayout linear_selection = detailsDialogDesign.findViewById(R.id.linear_selection);
		final LinearLayout linear1 = detailsDialogDesign.findViewById(R.id.linear1);
		if (_tag.equals("pending")) {
			linear_selection.setVisibility(View.VISIBLE);
		} else {
			linear_selection.setVisibility(View.GONE);
		}
		RequestNetwork getdatarq = new RequestNetwork(DepositLisrActivity.this);
		HashMap<String, Object> requestDataMap = new HashMap<>();
		requestDataMap.put("apikey", getString(R.string.database_api_key));
		getdatarq.setHeaders(requestDataMap);
		getdatarq.startRequestNetwork(RequestNetworkController.GET, 
		    getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=eq." + _key + "&", "", 
		    new RequestNetwork.RequestListener() {
				        @Override
				        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
				if (response.equals("[]")) {
						com.google.android.material.snackbar.Snackbar.make(linear1, "Data get failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
						setDataListMap = new Gson().fromJson(response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					getAndsetData = setDataListMap.get((int)0);
					textview_id.setText(getAndsetData.get("id").toString());
					textview_key.setText(getAndsetData.get("key").toString());
					textview_userid.setText(getAndsetData.get("user uid").toString());
					textview_amount.setText(getAndsetData.get("money").toString().concat("$"));
					textview3_date.setText(getAndsetData.get("date").toString());
					textview_status.setText(getAndsetData.get("status").toString());
					money = getAndsetData.get("money").toString();
					user_id = getAndsetData.get("user uid").toString();
					key = getAndsetData.get("key").toString();
					RequestNetwork tokenRq = new RequestNetwork(DepositLisrActivity.this);
					HashMap<String, Object> rqMap = new HashMap<>();
					rqMap.put("apikey", getString(R.string.database_api_key));
					tokenRq.setHeaders(rqMap);
					tokenRq.startRequestNetwork(RequestNetworkController.GET, 
					    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + getAndsetData.get("user uid").toString() + "&", "", 
					    new RequestNetwork.RequestListener() {
							        @Override
							        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
							tokenListMap = new Gson().fromJson(response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
							tokenMap = tokenListMap.get((int)0);
							notification_token = tokenMap.get("notification token").toString();
									        }
						
							        @Override
							        public void onErrorResponse(String tag, String message) {
							com.google.android.material.snackbar.Snackbar.make(linear1, "Notification token get failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
									        }
							    }
					);
				}
						        }
			
				        @Override
				        public void onErrorResponse(String tag, String message) {
				com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
						        }
				    }
		);
		button_success.setOnClickListener(v -> {
			FasterM3BottomSheetLoader newloader = new FasterM3BottomSheetLoader(DepositLisrActivity.this);
			newloader.setCancelableOnOutsideClick(false);
			newloader.show("Sending...");
			RequestNetwork dollarRq = new RequestNetwork(DepositLisrActivity.this);
			HashMap<String, Object> dollarRqMap = new HashMap<>();
			dollarRqMap.put("apikey", getString(R.string.database_api_key));
			dollarRq.setHeaders(dollarRqMap);
			dollarRq.startRequestNetwork(RequestNetworkController.GET, 
			    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + user_id, "", 
			    new RequestNetwork.RequestListener() {
					        @Override
					        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
					setDollarListMap = new Gson().fromJson(response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					setDollarMap = setDollarListMap.get((int)0);
					updateDataMap2 = new Gson().fromJson("{" + "\"" + "deposit balance" + "\":\"" + new DecimalFormat("0.00").format(Double.parseDouble(setDollarMap.get("deposit balance").toString()) + Double.parseDouble(money)) + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
					OkHttpClient client = new OkHttpClient();
					Request request = new Request.Builder()
					    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + user_id)
					    .addHeader("apikey", getString(R.string.database_api_key))
					    .patch(RequestBody.create(
					        MediaType.parse("application/json; charset=utf-8"),
					        new Gson().toJson(updateDataMap2)
					    ))
					    .build();
					client.newCall(request).enqueue(new Callback() {
						    @Override
						    public void onFailure(Call call, IOException e) {
							        final String errorMessage = e.getMessage();
							        new Handler(Looper.getMainLooper()).post(new Runnable() {
								            @Override
								            public void run() {
									                newloader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									            }
								        });
							    }
						    @Override
						    public void onResponse(Call call, Response response) throws IOException {
							        final String responseMessage = response.body().string(); 
							        if (response.isSuccessful()) {
								            new Handler(Looper.getMainLooper()).post(new Runnable() {
									                @Override
									                public void run() {
										                    updateDataMap = new Gson().fromJson("{" + "\"" + "status" + "\":\"" + "success" + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
										OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?key=eq." + _key)
										    .addHeader("apikey", getString(R.string.database_api_key))
										    .patch(RequestBody.create(
										        MediaType.parse("application/json; charset=utf-8"),
										        new Gson().toJson(updateDataMap)
										    ))
										    .build();
										client.newCall(request).enqueue(new Callback() {
											    @Override
											    public void onFailure(Call call, IOException e) {
												        final String errorMessage = e.getMessage();
												        new Handler(Looper.getMainLooper()).post(new Runnable() {
													            @Override
													            public void run() {
														                com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
														newloader.dismiss();
														            }
													        });
												    }
											    @Override
											    public void onResponse(Call call, Response response) throws IOException {
												        final String responseMessage = response.body().string(); 
												        if (response.isSuccessful()) {
													            new Handler(Looper.getMainLooper()).post(new Runnable() {
														                @Override
														                public void run() {
															                    DetailsDialog.dismiss();
															gointent.setClass(getApplicationContext(), LoginActivity.class);
															ActivityOptions gointentOp = ActivityOptions.makeCustomAnimation(DepositLisrActivity.this, R.anim.fade_in, R.anim.fade_out);
															startActivity(gointent, gointentOp.toBundle());
															newloader.dismiss();
															_FasterNotificationSender("Your recharge has been confirmed!", "Your ".concat(key.concat(" recharge has been confirmed and the money has been added.")), "", "RechargeActivity", "", notification_token, "");
															finish();
															                }
														            });
													        } else {
													            new Handler(Looper.getMainLooper()).post(new Runnable() {
														                @Override
														                public void run() {
															                    newloader.dismiss();
															com.google.android.material.snackbar.Snackbar.make(linear1, "status change failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
															                }
														            });
													        }
												    }
										});
										                }
									            });
								        } else {
								            new Handler(Looper.getMainLooper()).post(new Runnable() {
									                @Override
									                public void run() {
										                    newloader.dismiss();
										com.google.android.material.snackbar.Snackbar.make(linear1, "Money add failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
											@Override
											public void onClick(View _view) {
												 
											}
										}).show();
										                }
									            });
								        }
							    }
					});
							        }
				
					        @Override
					        public void onErrorResponse(String tag, String message) {
					newloader.dismiss();
					com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
							        }
					    }
			);
					        });
		button_reject.setOnClickListener(v -> {
			FasterM3BottomSheetLoader newloader = new FasterM3BottomSheetLoader(DepositLisrActivity.this);
			newloader.setCancelableOnOutsideClick(false);
			newloader.show("Sending...");
			updateDataMap2 = new Gson().fromJson("{" + "\"" + "status" + "\":\"" + "rejected" + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
			OkHttpClient client = new OkHttpClient();
			Request request = new Request.Builder()
			    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?key=eq." + _key)
			    .addHeader("apikey", getString(R.string.database_api_key))
			    .patch(RequestBody.create(
			        MediaType.parse("application/json; charset=utf-8"),
			        new Gson().toJson(updateDataMap2)
			    ))
			    .build();
			client.newCall(request).enqueue(new Callback() {
				    @Override
				    public void onFailure(Call call, IOException e) {
					        final String errorMessage = e.getMessage();
					        new Handler(Looper.getMainLooper()).post(new Runnable() {
						            @Override
						            public void run() {
							                newloader.dismiss();
							com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
							            }
						        });
					    }
				    @Override
				    public void onResponse(Call call, Response response) throws IOException {
					        final String responseMessage = response.body().string(); 
					        if (response.isSuccessful()) {
						            new Handler(Looper.getMainLooper()).post(new Runnable() {
							                @Override
							                public void run() {
								                    newloader.dismiss();
								DetailsDialog.dismiss();
								gointent.setClass(getApplicationContext(), LoginActivity.class);
								ActivityOptions gointentOp = ActivityOptions.makeCustomAnimation(DepositLisrActivity.this, R.anim.fade_in, R.anim.fade_out);
								startActivity(gointent, gointentOp.toBundle());
								_FasterNotificationSender("Your recharge has been rejected.", "Your ".concat(key.concat(" recharge has been rejected.")), "", "RechargeActivity", "", notification_token, "");
								finish();
								                }
							            });
						        } else {
						            new Handler(Looper.getMainLooper()).post(new Runnable() {
							                @Override
							                public void run() {
								                    newloader.dismiss();
								com.google.android.material.snackbar.Snackbar.make(linear1, "Money add failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
								                }
							            });
						        }
					    }
			});
					        });
		DetailsDialog.setCancelable(true);
		DetailsDialog.show();
	}
	
	
	public void _m3ErrorDialog(final String _massage) {
		MaterialAlertDialogBuilder errorDialog = new MaterialAlertDialogBuilder(DepositLisrActivity.this);
		errorDialog.setTitle("Error!");
		errorDialog.setMessage(_massage);
		errorDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		errorDialog.setCancelable(true);
		errorDialog.create().show();
	}
	
	
	public void _FasterNotificationSender(final String _title, final String _body, final String _imageUrl, final String _contextactivity, final String _topic, final String _token, final String _extraText) {
		notification_map = new HashMap<>();
		notification_map.put("title", _title);
		notification_map.put("body", _body);
		if (!_imageUrl.equals("")) {
			notification_map.put("image", _imageUrl);
		}
		if (!_extraText.equals("")) {
			notification_map.put("extraData", _extraText);
		}
		if (!_contextactivity.equals("")) {
			notification_map.put("ContextActivity", _contextactivity);
		}
		if (_token.equals("")) {
			// Start: "Send notification with topic"
			    String topic = _topic;
			    String token = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with topic"
		} else {
			// Start: "Send notification with token"
			    String token = _token;
			    String topic = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with token"
		}
	}
	
	public class Listview_pendingAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview_pendingAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.deposit_cus, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("pending")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("money")) {
						money.setText("+".concat(_data.get((int)_position).get("money").toString().concat("$")));
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("key")) {
						name.setText(_data.get((int)_position).get("key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_primary));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_details_dialog(_data.get((int)_position).get("key").toString(), "pending");
						}
					});
					linear_main.setOnLongClickListener(new View.OnLongClickListener() {
						@Override
						public boolean onLongClick(View _view) {
							if (_data.get((int)_position).containsKey("key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(DepositLisrActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=eq." + _data.get((int)_position).get("key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															getDataMap2 = new HashMap<>(); 
															getDataMap2.put("apikey", getString(R.string.database_api_key));
															deleteData.setHeaders(getDataMap2);
															deleteData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + _data.get((int)_position).get("user uid").toString() + "&", "B", _deleteData_request_listener);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear1, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(DepositLisrActivity.this, "", _data.get((int)_position).get("key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
							return true;
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
			
			return _view;
		}
	}
	
	public class Listview_successAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview_successAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.deposit_cus, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("success")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("money")) {
						money.setText("+".concat(_data.get((int)_position).get("money").toString().concat("$")));
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("key")) {
						name.setText(_data.get((int)_position).get("key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(Color.parseColor("#4caf50"));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_details_dialog(_data.get((int)_position).get("key").toString(), "success");
						}
					});
					linear_main.setOnLongClickListener(new View.OnLongClickListener() {
						@Override
						public boolean onLongClick(View _view) {
							if (_data.get((int)_position).containsKey("key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(DepositLisrActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=eq." + _data.get((int)_position).get("key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															getDataMap2 = new HashMap<>(); 
															getDataMap2.put("apikey", getString(R.string.database_api_key));
															deleteData.setHeaders(getDataMap2);
															deleteData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + _data.get((int)_position).get("user uid").toString() + "&", "B", _deleteData_request_listener);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear1, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(DepositLisrActivity.this, "", _data.get((int)_position).get("key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
							return true;
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
			
			return _view;
		}
	}
	
	public class Listview_rejectedAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview_rejectedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.deposit_cus, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("rejected")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("money")) {
						money.setText("+".concat(_data.get((int)_position).get("money").toString().concat("$")));
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("key")) {
						name.setText(_data.get((int)_position).get("key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(Color.parseColor("#f44336"));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_details_dialog(_data.get((int)_position).get("key").toString(), "rejected");
						}
					});
					linear_main.setOnLongClickListener(new View.OnLongClickListener() {
						@Override
						public boolean onLongClick(View _view) {
							if (_data.get((int)_position).containsKey("key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(DepositLisrActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "key" + "=eq." + _data.get((int)_position).get("key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															getDataMap2 = new HashMap<>(); 
															getDataMap2.put("apikey", getString(R.string.database_api_key));
															deleteData.setHeaders(getDataMap2);
															deleteData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "user uid" + "=eq." + _data.get((int)_position).get("user uid").toString() + "&", "B", _deleteData_request_listener);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear1, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(DepositLisrActivity.this, "", _data.get((int)_position).get("key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
							return true;
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
			
			return _view;
		}
	}
}