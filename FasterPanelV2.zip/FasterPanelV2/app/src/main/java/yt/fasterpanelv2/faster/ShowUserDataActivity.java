package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.card.*;
import com.google.android.material.chip.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;

public class ShowUserDataActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }

private FasterM3BottomSheetLoader MainLoader;
	
	private HashMap<String, Object> DetailsMap = new HashMap<>();
	private HashMap<String, Object> riskMap = new HashMap<>();
	private HashMap<String, Object> Deletemap = new HashMap<>();
	private String password = "";
	
	private ArrayList<HashMap<String, Object>> DetailsListMap = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private TextView textview3;
	private LinearLayout linear_details;
	private Button button_delete;
	private LinearLayout linear12;
	private MaterialCardView linear_box5;
	private MaterialCardView linear_box6;
	private LinearLayout linear28;
	private LinearLayout linear33;
	private MaterialCardView linear_box11;
	private MaterialCardView linear_box13;
	private LinearLayout linear_box12;
	private LinearLayout linear40;
	private LinearLayout linear39;
	private LinearLayout linear19;
	private LinearLayout linear14;
	private MaterialCardView linear_box1;
	private MaterialCardView linear_box4;
	private LinearLayout linear4;
	private MaterialCardView linear_img_body;
	private LinearLayout linear6;
	private ImageView imageview_logo;
	private TextView textview1;
	private TextView textview_name;
	private LinearLayout linear21;
	private TextView textview10;
	private TextView textview_device_id;
	private MaterialCardView linear_box2;
	private MaterialCardView linear_box3;
	private LinearLayout linear8;
	private TextView textview4;
	private TextView textview_depositBalance;
	private LinearLayout linear18;
	private TextView textview8;
	private TextView textview_account_type;
	private LinearLayout linear23;
	private TextView textview12;
	private TextView textview_email;
	private LinearLayout linear25;
	private TextView textview14;
	private TextView textview_user_id;
	private MaterialCardView linear_box7;
	private MaterialCardView linear_box8;
	private LinearLayout linear30;
	private TextView textview18;
	private TextView textview_country;
	private LinearLayout linear32;
	private TextView textview20;
	private TextView textview_password;
	private MaterialCardView linear_box9;
	private MaterialCardView linear_box10;
	private LinearLayout linear35;
	private TextView textview22;
	private TextView textview_question1;
	private LinearLayout linear37;
	private TextView textview24;
	private TextView textview_question2;
	private LinearLayout linear38;
	private TextView textview26;
	private TextView textview_register_date;
	private LinearLayout linear42;
	private TextView textview31;
	private TextView textview_token;
	private TextView textview30;
	private TextView textview_expired_date;
	private TextView textview29;
	private Button button_show;
	private TextView textview28;
	private Chip checkbox1;
	private Chip checkbox2;
	
	private RequestNetwork show_data;
	private RequestNetwork.RequestListener _show_data_request_listener;
	private Intent viewUrl = new Intent();
	private AlertDialog.Builder dialog;
	private Intent backIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.show_user_data);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		textview3 = findViewById(R.id.textview3);
		linear_details = findViewById(R.id.linear_details);
		button_delete = findViewById(R.id.button_delete);
		linear12 = findViewById(R.id.linear12);
		linear_box5 = findViewById(R.id.linear_box5);
		linear_box6 = findViewById(R.id.linear_box6);
		linear28 = findViewById(R.id.linear28);
		linear33 = findViewById(R.id.linear33);
		linear_box11 = findViewById(R.id.linear_box11);
		linear_box13 = findViewById(R.id.linear_box13);
		linear_box12 = findViewById(R.id.linear_box12);
		linear40 = findViewById(R.id.linear40);
		linear39 = findViewById(R.id.linear39);
		linear19 = findViewById(R.id.linear19);
		linear14 = findViewById(R.id.linear14);
		linear_box1 = findViewById(R.id.linear_box1);
		linear_box4 = findViewById(R.id.linear_box4);
		linear4 = findViewById(R.id.linear4);
		linear_img_body = findViewById(R.id.linear_img_body);
		linear6 = findViewById(R.id.linear6);
		imageview_logo = findViewById(R.id.imageview_logo);
		textview1 = findViewById(R.id.textview1);
		textview_name = findViewById(R.id.textview_name);
		linear21 = findViewById(R.id.linear21);
		textview10 = findViewById(R.id.textview10);
		textview_device_id = findViewById(R.id.textview_device_id);
		linear_box2 = findViewById(R.id.linear_box2);
		linear_box3 = findViewById(R.id.linear_box3);
		linear8 = findViewById(R.id.linear8);
		textview4 = findViewById(R.id.textview4);
		textview_depositBalance = findViewById(R.id.textview_depositBalance);
		linear18 = findViewById(R.id.linear18);
		textview8 = findViewById(R.id.textview8);
		textview_account_type = findViewById(R.id.textview_account_type);
		linear23 = findViewById(R.id.linear23);
		textview12 = findViewById(R.id.textview12);
		textview_email = findViewById(R.id.textview_email);
		linear25 = findViewById(R.id.linear25);
		textview14 = findViewById(R.id.textview14);
		textview_user_id = findViewById(R.id.textview_user_id);
		linear_box7 = findViewById(R.id.linear_box7);
		linear_box8 = findViewById(R.id.linear_box8);
		linear30 = findViewById(R.id.linear30);
		textview18 = findViewById(R.id.textview18);
		textview_country = findViewById(R.id.textview_country);
		linear32 = findViewById(R.id.linear32);
		textview20 = findViewById(R.id.textview20);
		textview_password = findViewById(R.id.textview_password);
		linear_box9 = findViewById(R.id.linear_box9);
		linear_box10 = findViewById(R.id.linear_box10);
		linear35 = findViewById(R.id.linear35);
		textview22 = findViewById(R.id.textview22);
		textview_question1 = findViewById(R.id.textview_question1);
		linear37 = findViewById(R.id.linear37);
		textview24 = findViewById(R.id.textview24);
		textview_question2 = findViewById(R.id.textview_question2);
		linear38 = findViewById(R.id.linear38);
		textview26 = findViewById(R.id.textview26);
		textview_register_date = findViewById(R.id.textview_register_date);
		linear42 = findViewById(R.id.linear42);
		textview31 = findViewById(R.id.textview31);
		textview_token = findViewById(R.id.textview_token);
		textview30 = findViewById(R.id.textview30);
		textview_expired_date = findViewById(R.id.textview_expired_date);
		textview29 = findViewById(R.id.textview29);
		button_show = findViewById(R.id.button_show);
		textview28 = findViewById(R.id.textview28);
		checkbox1 = findViewById(R.id.checkbox1);
		checkbox2 = findViewById(R.id.checkbox2);
		show_data = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		
		button_delete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FasterM3BottomSheetLoader deletPremiumLoader = new FasterM3BottomSheetLoader(ShowUserDataActivity.this);
				deletPremiumLoader.setCancelableOnOutsideClick(false);
				deletPremiumLoader.show("Removing....");
				Deletemap = new Gson().fromJson("{" + "\"" + "account type" + "\":\"" + "free" + "\"," + "\"" + "expired date" + "\":\"" + "none" + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + textview_user_id.getText().toString())
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(Deletemap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                deletPremiumLoader.dismiss();
								com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    deletPremiumLoader.dismiss();
									backIntent.setClass(getApplicationContext(), ListUserActivity.class);
									backIntent.putExtra("mode", getIntent().getStringExtra("mode"));
									ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(ShowUserDataActivity.this, R.anim.fade_in, R.anim.fade_out);
									startActivity(backIntent, backIntentOp.toBundle());
									finish();
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    deletPremiumLoader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear1, "Something went wrong!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									                }
								            });
							        }
						    }
				});
			}
		});
		
		linear_box5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("User email", textview_email.getText().toString());
			}
		});
		
		linear_box6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("User id", textview_user_id.getText().toString());
			}
		});
		
		linear_box11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Register date", textview_register_date.getText().toString());
			}
		});
		
		linear_box13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Notification token", textview_token.getText().toString());
			}
		});
		
		linear_box12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Premium expired date", textview_expired_date.getText().toString());
			}
		});
		
		linear_box1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("User name", textview_name.getText().toString());
			}
		});
		
		linear_box4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Device id", textview_device_id.getText().toString());
			}
		});
		
		linear_box2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Deposit balance", textview_depositBalance.getText().toString());
			}
		});
		
		linear_box3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Account type", textview_account_type.getText().toString());
			}
		});
		
		linear_box7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("User country", textview_country.getText().toString());
			}
		});
		
		linear_box8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Password (secret)", password);
			}
		});
		
		linear_box9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Question 1", textview_question1.getText().toString());
			}
		});
		
		linear_box10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ShowDetails("Question 2", textview_question2.getText().toString());
			}
		});
		
		checkbox1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox2.setChecked(false);
				checkbox1.setChecked(true);
				riskMap = new Gson().fromJson("{" + "\"" + "risk type" + "\":\"" + "ban" + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + getIntent().getStringExtra("uid"))
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(riskMap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    com.google.android.material.snackbar.Snackbar.make(linear1, "Banning the user was successful!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    com.google.android.material.snackbar.Snackbar.make(linear1, "Banning the user was unsuccessful!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									                }
								            });
							        }
						    }
				});
			}
		});
		
		checkbox2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(true);
				riskMap = new Gson().fromJson("{" + "\"" + "risk type" + "\":\"" + "none" + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?uid=eq." + getIntent().getStringExtra("uid"))
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(riskMap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                com.google.android.material.snackbar.Snackbar.make(linear1, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    com.google.android.material.snackbar.Snackbar.make(linear1, "unbanning the user was successful!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                    com.google.android.material.snackbar.Snackbar.make(linear1, "unbanning the user was unsuccessful!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
									                }
								            });
							        }
						    }
				});
			}
		});
		
		_show_data_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						MainLoader.dismiss();
					com.google.android.material.snackbar.Snackbar.make(linear1, "Details not found!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
						DetailsListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					DetailsMap = DetailsListMap.get((int)0);
					MainLoader.dismiss();
					if (DetailsMap.containsKey("logo url")) {
						if (DetailsMap.get("logo url").toString().equals("none")) {
							imageview_logo.setImageResource(R.drawable.user_default_icon);
						} else {
							Glide.with(getApplicationContext()).load(Uri.parse(DetailsMap.get("logo url").toString())).into(imageview_logo);
						}
					}
					if (DetailsMap.containsKey("uid")) {
						textview_user_id.setText(DetailsMap.get("uid").toString());
					}
					if (DetailsMap.containsKey("notification token")) {
						textview_token.setText(DetailsMap.get("notification token").toString());
					}
					if (DetailsMap.containsKey("name")) {
						textview_name.setText(DetailsMap.get("name").toString());
					}
					if (DetailsMap.containsKey("email")) {
						textview_email.setText(DetailsMap.get("email").toString());
					}
					if (DetailsMap.containsKey("deposit balance")) {
						textview_depositBalance.setText(DetailsMap.get("deposit balance").toString());
					}
					if (DetailsMap.containsKey("device id")) {
						textview_device_id.setText(DetailsMap.get("device id").toString());
					}
					if (DetailsMap.containsKey("country")) {
						textview_country.setText(DetailsMap.get("country").toString());
					}
					if (DetailsMap.containsKey("password")) {
						password = DetailsMap.get("password").toString();
					}
					if (DetailsMap.containsKey("question1")) {
						textview_question1.setText(DetailsMap.get("question1").toString());
					}
					if (DetailsMap.containsKey("question2")) {
						textview_question2.setText(DetailsMap.get("question2").toString());
					}
					if (DetailsMap.containsKey("register date")) {
						textview_register_date.setText(DetailsMap.get("register date").toString());
					}
					if (DetailsMap.containsKey("social media")) {
						button_show.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								viewUrl.setAction(Intent.ACTION_VIEW);
								viewUrl.setData(Uri.parse("https://".concat(DetailsMap.get("social media").toString())));
								startActivity(viewUrl);
							}
						});
					}
					if (DetailsMap.containsKey("risk type")) {
						if (DetailsMap.get("risk type").toString().equals("none")) {
							checkbox1.setChecked(false);
							checkbox2.setChecked(true);
						} else {
							if (DetailsMap.get("risk type").toString().equals("ban")) {
								checkbox1.setChecked(true);
								checkbox2.setChecked(false);
							}
						}
					}
					if (DetailsMap.containsKey("account type")) {
						textview_account_type.setText(DetailsMap.get("account type").toString());
						if (DetailsMap.get("account type").toString().equals("free")) {
							linear_box12.setVisibility(View.GONE);
							button_delete.setVisibility(View.GONE);
						} else {
							if (DetailsMap.get("account type").toString().equals("premium")) {
								linear_box12.setVisibility(View.VISIBLE);
								button_delete.setVisibility(View.VISIBLE);
							}
						}
					}
					if (DetailsMap.containsKey("expired date")) {
						if (DetailsMap.get("expired date").toString().equals("none")) {
							textview_expired_date.setText("He didn't buy premium!");
						} else {
							long timestamp = Long.parseLong(DetailsMap.get("expired date").toString());
							Date date = new Date(timestamp);
							DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a", Locale.getDefault());
							String formattedDate = format.format(date);
							textview_expired_date.setText(formattedDate);
						}
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				com.google.android.material.snackbar.Snackbar.make(linear1, "Details not found!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			}
		};
	}
	
	private void initializeLogic() {
		_GetTransition(linear_img_body, "img animation");
		MainLoader = new FasterM3BottomSheetLoader(ShowUserDataActivity.this);
		MainLoader.setCancelableOnOutsideClick(false);
		MainLoader.show("Finding details....");
		DetailsMap = new HashMap<>(); 
		DetailsMap.put("apikey", getString(R.string.database_api_key));
		show_data.setHeaders(DetailsMap);
		show_data.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + getIntent().getStringExtra("uid"), "A", _show_data_request_listener);
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), ListUserActivity.class);
				backIntent.putExtra("mode", getIntent().getStringExtra("mode"));
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(ShowUserDataActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());
				finish();
			}
		});
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	public void _GetTransition(final View _view, final String _name) {
		_view.setTransitionName(_name); 
	}
	
	
	public void _ShowDetails(final String _title, final String _massage) {
		MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(ShowUserDataActivity.this);
		dialog.setTitle(_title);
		dialog.setMessage(_massage);
		dialog.setPositiveButton("Copy", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				        FasterUtils.copyToClipboard(ShowUserDataActivity.this, "", _massage);
				    }
		});
		dialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		dialog.setCancelable(true);
		dialog.create().show();
	}
	
}