package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.*;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;
import androidx.core.content.ContextCompat;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TemplateHistoryActivity extends AppCompatActivity {
	
	private HashMap<String, Object> searchData = new HashMap<>();
	private String getmassage = "";
	private HashMap<String, Object> addMap = new HashMap<>();
	private HashMap<String, Object> notification_map = new HashMap<>();
	private String onError = "";
	private String onSuccess = "";
	private String ProjectID = "";
	private String accessTokenError = "";
	private String accessToken = "";
	private HashMap<String, Object> tokenMap = new HashMap<>();
	private HashMap<String, Object> rqMap = new HashMap<>();
	private String notification_token = "";
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> tokenListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextInputLayout layout1;
	private MaterialButtonToggleGroup linear_selection;
	private LinearLayout linear_status;
	private ListView listview_pending;
	private ListView listview_success;
	private EditText et1;
	private MaterialButton button_pending;
	private MaterialButton button5;
	private TextView textview2;
	
	private Intent backIntent = new Intent();
	private RequestNetwork getDataRq;
	private RequestNetwork.RequestListener _getDataRq_request_listener;
	private AlertDialog.Builder dialog;
	private AlertDialog.Builder errorDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.template_history);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		layout1 = findViewById(R.id.layout1);
		linear_selection = findViewById(R.id.linear_selection);
		linear_status = findViewById(R.id.linear_status);
		listview_pending = findViewById(R.id.listview_pending);
		listview_success = findViewById(R.id.listview_success);
		et1 = findViewById(R.id.et1);
		button_pending = findViewById(R.id.button_pending);
		button5 = findViewById(R.id.button5);
		textview2 = findViewById(R.id.textview2);
		getDataRq = new RequestNetwork(this);
		dialog = new AlertDialog.Builder(this);
		errorDialog = new AlertDialog.Builder(this);
		
		et1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				searchData = new HashMap<>(); 
				searchData.put("apikey", getString(R.string.database_api_key));
				getDataRq.setHeaders(searchData);
				getDataRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "template history" + "?" + "purchase key" + "=ilike.*" + _charSeq + "*", "B", _getDataRq_request_listener);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button_pending.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview_pending.setVisibility(View.VISIBLE);
				listview_success.setVisibility(View.GONE);
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview_pending.setVisibility(View.GONE);
				listview_success.setVisibility(View.VISIBLE);
			}
		});
		
		_getDataRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						linear_status.setVisibility(View.VISIBLE);
					_TransitionManager(linear1, 300);
					com.google.android.material.snackbar.Snackbar.make(linear1, "Data get failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
						getDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					Collections.reverse(getDataListMap);
					listview_pending.setAdapter(new Listview_pendingAdapter(getDataListMap));
					((BaseAdapter)listview_pending.getAdapter()).notifyDataSetChanged();
					listview_success.setAdapter(new Listview_successAdapter(getDataListMap));
					((BaseAdapter)listview_success.getAdapter()).notifyDataSetChanged();
					_TransitionManager(linear1, 300);
					linear_status.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), MainActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(TemplateHistoryActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());
				finish();
			}
		});
		Animation animation = AnimationUtils.loadAnimation(this, R.anim.listview_item_animation);
		listview_pending.setLayoutAnimation(new LayoutAnimationController(animation, 0.2f));
		Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.listview_item_animation);
		listview_success.setLayoutAnimation(new LayoutAnimationController(animation2, 0.2f));
		// Start: "get data"
		getDataRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "template history" + "?apikey=" + getString(R.string.database_api_key), "A", _getDataRq_request_listener);
		//End: "get data"
		listview_success.setVisibility(View.GONE);
		// Start: "Access an token"
		try {
			    try (InputStream originalInputStream = getAssets().open("service-account.json")) {
				        byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
					            HashMap<String, Object> map = new Gson().fromJson(
					                jsonString,
					                new TypeToken<HashMap<String, Object>>(){}.getType()
					            );
					            ProjectID = map.get("project_id").toString();
					        }
				
				        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
					            AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.OnTokenResponse() {
						                @Override
						                public void onSuccess(String token) {
							                    JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
							                    if (jsonResponse.has("access_token")) {
								                        accessToken = jsonResponse.get("access_token").getAsString();
								                    } else {
								                        accessToken = "error getting accessToken";
								                    }
							                }
						
						                @Override
						                public void onError(String error) {
							                    accessTokenError = error;
							                    runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
							                }
						            });
					        }
				    } catch (IOException e) {
				        accessTokenError = "Error reading service account file: " + e.getMessage();
				        runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
				    }
		} catch (Exception e) {
			    runOnUiThread(() -> _m3ErrorDialog("Unexpected error: " + e.getMessage()));
		}
		//End: "Access an token"
	}
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _FasterNotificationSender(final String _title, final String _body, final String _imageUrl, final String _contextactivity, final String _topic, final String _token, final String _extraText) {
		notification_map = new HashMap<>();
		notification_map.put("title", _title);
		notification_map.put("body", _body);
		if (!_imageUrl.equals("")) {
			notification_map.put("image", _imageUrl);
		}
		if (!_extraText.equals("")) {
			notification_map.put("extraData", _extraText);
		}
		if (!_contextactivity.equals("")) {
			notification_map.put("ContextActivity", _contextactivity);
		}
		if (_token.equals("")) {
			// Start: "Send notification with topic"
			    String topic = _topic;
			    String token = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with topic"
		} else {
			// Start: "Send notification with token"
			    String token = _token;
			    String topic = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with token"
		}
	}
	
	
	public void _m3ErrorDialog(final String _massage) {
		MaterialAlertDialogBuilder errorDialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
		errorDialog.setTitle("Error!");
		errorDialog.setMessage(_massage);
		errorDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		errorDialog.setCancelable(true);
		errorDialog.create().show();
	}
	
	public class Listview_pendingAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview_pendingAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.deposit_cus, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("pending")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("file type")) {
						money.setText(_data.get((int)_position).get("file type").toString());
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("purchase key")) {
						name.setText(_data.get((int)_position).get("purchase key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_primary));
					money.setTextColor(Color.parseColor("#4caf50"));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (_data.get((int)_position).containsKey("purchase key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "template history" + "?" + "purchase key" + "=eq." + _data.get((int)_position).get("purchase key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_main, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															linear_main.setVisibility(View.GONE);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear_main, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(TemplateHistoryActivity.this, "", _data.get((int)_position).get("purchase key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
						}
					});
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							final
							com.google.android.material.bottomsheet.BottomSheetDialog viewdialog = new com.google.android.material.bottomsheet.BottomSheetDialog(TemplateHistoryActivity.this);
							View viewdesign = getLayoutInflater().inflate(R.layout.template_history_cus, null);
							viewdialog.setContentView(viewdesign);
							viewdialog.getWindow().getDecorView().setBackgroundColor(0);
							final TextView textview_key = viewdesign.findViewById(R.id.textview_key);
							final TextView textview_email = viewdesign.findViewById(R.id.textview_email);
							final TextView textview_userid = viewdesign.findViewById(R.id.textview_userid);
							final TextView textview_date = viewdesign.findViewById(R.id.textview_date);
							final TextView textview_filetype = viewdesign.findViewById(R.id.textview_filetype);
							final TextView textview_status = viewdesign.findViewById(R.id.textview_status);
							final LinearLayout linear_email = viewdesign.findViewById(R.id.linear_email);
							final EditText et1 = viewdesign.findViewById(R.id.et1);
							final Button button_success = viewdesign.findViewById(R.id.button_success);
							final TextInputLayout layout1 = viewdesign.findViewById(R.id.layout1);
							if (_data.get((int)_position).get("file type").toString().equals("collect email")) {
								linear_email.setVisibility(View.VISIBLE);
								layout1.setVisibility(View.VISIBLE);
							} else {
								if (_data.get((int)_position).get("file type").toString().equals("direct link") || _data.get((int)_position).get("file type").toString().equals("upload")) {
									linear_email.setVisibility(View.GONE);
									layout1.setVisibility(View.GONE);
								} else {
									linear_email.setVisibility(View.GONE);
									layout1.setVisibility(View.VISIBLE);
								}
							}
							textview_key.setText(_data.get((int)_position).get("purchase key").toString());
							textview_email.setText(_data.get((int)_position).get("massage").toString());
							et1.setText(_data.get((int)_position).get("massage").toString());
							textview_userid.setText(_data.get((int)_position).get("uid").toString());
							textview_date.setText(_data.get((int)_position).get("date").toString());
							textview_filetype.setText(_data.get((int)_position).get("file type").toString());
							textview_status.setText(_data.get((int)_position).get("status").toString());
							RequestNetwork tokenRq = new RequestNetwork(TemplateHistoryActivity.this);
							HashMap<String, Object> rqMap = new HashMap<>();
							rqMap.put("apikey", getString(R.string.database_api_key));
							tokenRq.setHeaders(rqMap);
							tokenRq.startRequestNetwork(RequestNetworkController.GET, 
							    getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "uid" + "=eq." + _data.get((int)_position).get("uid").toString() + "&", "", 
							    new RequestNetwork.RequestListener() {
									        @Override
									        public void onResponse(String tag, String response, HashMap<String, Object> responseHeaders) {
									tokenListMap = new Gson().fromJson(response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
									tokenMap = tokenListMap.get((int)0);
									notification_token = tokenMap.get("notification token").toString();
											        }
								
									        @Override
									        public void onErrorResponse(String tag, String message) {
									com.google.android.material.snackbar.Snackbar.make(linear_main, "Notification token get failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
											        }
									    }
							);
							button_success.setOnClickListener(v -> {
								viewdialog.dismiss();
								getmassage = et1.getText().toString();
								FasterM3BottomSheetLoader dataaddloader = new FasterM3BottomSheetLoader(TemplateHistoryActivity.this);
								dataaddloader.setCancelableOnOutsideClick(false);
								dataaddloader.show("Delivering....");
								addMap = new Gson().fromJson("{" + "\"" + "status" + "\":\"" + "success" + "\"," + "\"" + "massage" + "\":\"" + getmassage + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
								OkHttpClient client = new OkHttpClient();
								Request request = new Request.Builder()
								    .url(getString(R.string.database_url) + "/rest/v1/" + "template history" + "?purchase key=eq." + _data.get((int)_position).get("purchase key").toString())
								    .addHeader("apikey", getString(R.string.database_api_key))
								    .patch(RequestBody.create(
								        MediaType.parse("application/json; charset=utf-8"),
								        new Gson().toJson(addMap)
								    ))
								    .build();
								client.newCall(request).enqueue(new Callback() {
									    @Override
									    public void onFailure(Call call, IOException e) {
										        final String errorMessage = e.getMessage();
										        new Handler(Looper.getMainLooper()).post(new Runnable() {
											            @Override
											            public void run() {
												                dataaddloader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear_main, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
												            }
											        });
										    }
									    @Override
									    public void onResponse(Call call, Response response) throws IOException {
										        final String responseMessage = response.body().string(); 
										        if (response.isSuccessful()) {
											            new Handler(Looper.getMainLooper()).post(new Runnable() {
												                @Override
												                public void run() {
													                    dataaddloader.dismiss();
													backIntent.setClass(getApplicationContext(), LoginActivity.class);
													ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(TemplateHistoryActivity.this, R.anim.fade_in, R.anim.fade_out);
													startActivity(backIntent, backIntentOp.toBundle());
													_FasterNotificationSender("The template has been provided to you!", _data.get((int)_position).get("purchase key").toString(), "", "TemplateHistoryActivity", "", notification_token, "");
													finish();
													                }
												            });
											        } else {
											            new Handler(Looper.getMainLooper()).post(new Runnable() {
												                @Override
												                public void run() {
													                    dataaddloader.dismiss();
													com.google.android.material.snackbar.Snackbar.make(linear_main, "Something went wrong!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
														@Override
														public void onClick(View _view) {
															 
														}
													}).show();
													                }
												            });
											        }
										    }
								});
										        });
							viewdialog.setCancelable(true);
							viewdialog.show();
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
			
			return _view;
		}
	}
	
	public class Listview_successAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview_successAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.deposit_cus, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear_main = _view.findViewById(R.id.linear_main);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView name = _view.findViewById(R.id.name);
			final TextView date = _view.findViewById(R.id.date);
			final TextView money = _view.findViewById(R.id.money);
			final TextView status = _view.findViewById(R.id.status);
			
			if (_data.get((int)_position).containsKey("status")) {
				if (_data.get((int)_position).get("status").toString().equals("success")) {
					linear_main.setVisibility(View.VISIBLE);
					if (_data.get((int)_position).containsKey("file type")) {
						money.setText(_data.get((int)_position).get("file type").toString());
					}
					if (_data.get((int)_position).containsKey("date")) {
						date.setText(_data.get((int)_position).get("date").toString());
					}
					if (_data.get((int)_position).containsKey("purchase key")) {
						name.setText(_data.get((int)_position).get("purchase key").toString());
					}
					status.setText(_data.get((int)_position).get("status").toString());
					status.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_primary));
					money.setTextColor(Color.parseColor("#4caf50"));
					linear_main.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (_data.get((int)_position).containsKey("purchase key")) {
								MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(TemplateHistoryActivity.this);
								dialog.setMessage("Do you want to delete this history?");
								dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(getString(R.string.database_url) + "/rest/v1/" + "template history" + "?" + "purchase key" + "=eq." + _data.get((int)_position).get("purchase key").toString())
										    .delete()
										    .addHeader("apikey", getString(R.string.database_api_key)) 
										    .addHeader("Content-Type", "application/json")
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														com.google.android.material.snackbar.Snackbar.make(linear_main, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												if (response.isSuccessful()) {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															linear_main.setVisibility(View.GONE);
															 }
													});
												}
												else {
													runOnUiThread(new Runnable() {
														@Override
														public void run() {
															com.google.android.material.snackbar.Snackbar.make(linear_main, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												}
											}
										});
										    }
								});
								dialog.setNegativeButton("Copy Id", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										        FasterUtils.copyToClipboard(TemplateHistoryActivity.this, "", _data.get((int)_position).get("purchase key").toString());
										    }
								});
								dialog.setNeutralButton("Close", new DialogInterface.OnClickListener() {
									    @Override
									    public void onClick(DialogInterface _dialog, int _which) {
										         
										    }
								});
								dialog.setCancelable(true);
								dialog.create().show();
							}
						}
					});
				} else {
					linear_main.setVisibility(View.GONE);
				}
			}
			
			return _view;
		}
	}
}