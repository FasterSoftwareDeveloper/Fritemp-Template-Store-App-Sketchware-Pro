package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;
import com.google.android.material.transition.platform.MaterialSharedAxis;
import android.app.ActivityOptions;
import android.transition.Transition;

public class ListUserActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }

private FasterM3BottomSheetLoader loader;
	
	private HashMap<String, Object> getDataMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listview_map = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextInputLayout layout1;
	private ListView listview1;
	private LinearLayout linear_status;
	private EditText et1;
	private TextView textview2;
	
	private RequestNetwork getDataToListMap;
	private RequestNetwork.RequestListener _getDataToListMap_request_listener;
	private Intent detailsIntent = new Intent();
	private Intent backIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.list_user);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		layout1 = findViewById(R.id.layout1);
		listview1 = findViewById(R.id.listview1);
		linear_status = findViewById(R.id.linear_status);
		et1 = findViewById(R.id.et1);
		textview2 = findViewById(R.id.textview2);
		getDataToListMap = new RequestNetwork(this);
		
		et1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (getIntent().getStringExtra("mode").equals("premium")) {
					getDataMap = new HashMap<>(); 
					getDataMap.put("apikey", getString(R.string.database_api_key));
					getDataToListMap.setHeaders(getDataMap);
					getDataToListMap.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "account type" + "=eq." + "premium" + "&" + "&" + "email" + "=ilike.*" + _charSeq + "*", "B", _getDataToListMap_request_listener);
				} else {
					getDataMap = new HashMap<>(); 
					getDataMap.put("apikey", getString(R.string.database_api_key));
					getDataToListMap.setHeaders(getDataMap);
					getDataToListMap.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "account type" + "=eq." + "free" + "&" + "&" + "email" + "=ilike.*" + _charSeq + "*", "B", _getDataToListMap_request_listener);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_getDataToListMap_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						if (!_tag.equals("B")) {
						loader.dismiss();
					}
					linear_status.setVisibility(View.VISIBLE);
					listview1.setVisibility(View.GONE);
				} else {
						if (_tag.equals("B")) {
						listview_map = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						Collections.reverse(listview_map);
						listview1.setAdapter(new Listview1Adapter(listview_map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						_TransitionManager(linear1, 200);
					} else {
						loader.dismiss();
						listview_map = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						Collections.reverse(listview_map);
						listview1.setAdapter(new Listview1Adapter(listview_map));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					linear_status.setVisibility(View.GONE);
					listview1.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		loader = new FasterM3BottomSheetLoader(ListUserActivity.this);
		loader.setCancelableOnOutsideClick(false);
		loader.show("Getting data....");
		if (getIntent().getStringExtra("mode").equals("free")) {
			getDataMap = new HashMap<>(); 
			getDataMap.put("apikey", getString(R.string.database_api_key));
			getDataToListMap.setHeaders(getDataMap);
			getDataToListMap.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "account type" + "=eq." + "free", "A", _getDataToListMap_request_listener);
			textview1.setText("Manage all normal users");
		} else {
			getDataMap = new HashMap<>(); 
			getDataMap.put("apikey", getString(R.string.database_api_key));
			getDataToListMap.setHeaders(getDataMap);
			getDataToListMap.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "account type" + "=eq." + "premium", "A", _getDataToListMap_request_listener);
			textview1.setText("Manage all premium users");
		}
		Animation animation = AnimationUtils.loadAnimation(this, R.anim.listview_item_animation);
		listview1.setLayoutAnimation(new LayoutAnimationController(animation, 0.2f));
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), MainActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(ListUserActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());
				finish();
			}
		});
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	public void _setSelected(final TextView _textview) {
		_textview.setSelected(true);
	}
	
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _StartTransitionActivity(final Intent _intent, final View _view, final String _name) {
		_view.setTransitionName(_name); 
		android.app.ActivityOptions optionsCompat = android.app.ActivityOptions.makeSceneTransitionAnimation(ListUserActivity.this, _view, _name); 
		startActivity(_intent, optionsCompat.toBundle());
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.list_user_cus, null);
			}
			
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final com.google.android.material.card.MaterialCardView linear_main_body = _view.findViewById(R.id.linear_main_body);
			final LinearLayout linear_content = _view.findViewById(R.id.linear_content);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear_content2 = _view.findViewById(R.id.linear_content2);
			final com.google.android.material.card.MaterialCardView linear_img_body = _view.findViewById(R.id.linear_img_body);
			final ImageView imageview_logo = _view.findViewById(R.id.imageview_logo);
			final TextView textview_name = _view.findViewById(R.id.textview_name);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final TextView textview_doller = _view.findViewById(R.id.textview_doller);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview_email = _view.findViewById(R.id.textview_email);
			final TextView textview_uid = _view.findViewById(R.id.textview_uid);
			
			if (_data.get((int)_position).containsKey("name")) {
				textview_name.setText(_data.get((int)_position).get("name").toString());
			}
			if (_data.get((int)_position).containsKey("email")) {
				textview_email.setText(_data.get((int)_position).get("email").toString());
			}
			if (_data.get((int)_position).containsKey("deposit balance")) {
				textview_doller.setText(new DecimalFormat("0.00").format(Double.parseDouble(_data.get((int)_position).get("deposit balance").toString())).concat("$"));
			}
			if (_data.get((int)_position).containsKey("uid")) {
				textview_uid.setText(_data.get((int)_position).get("uid").toString());
			}
			if (_data.get((int)_position).containsKey("logo url")) {
				if (_data.get((int)_position).get("logo url").toString().equals("none")) {
					imageview_logo.setImageResource(R.drawable.user_default_icon);
				} else {
					Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("logo url").toString())).into(imageview_logo);
				}
			}
			linear_main_body.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					detailsIntent.setClass(getApplicationContext(), ShowUserDataActivity.class);
					detailsIntent.putExtra("uid", _data.get((int)_position).get("uid").toString());
					detailsIntent.putExtra("mode", getIntent().getStringExtra("mode"));
					_StartTransitionActivity(detailsIntent, linear_img_body, "img animation");
				}
			});
			
			return _view;
		}
	}
}