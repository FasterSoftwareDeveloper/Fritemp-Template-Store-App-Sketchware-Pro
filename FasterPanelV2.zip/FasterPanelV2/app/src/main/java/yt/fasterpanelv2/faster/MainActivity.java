package yt.fasterpanelv2.faster;

import yt.fasterpanelv2.faster.LoginActivity;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.*;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;

import com.google.firebase.messaging.*;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;
import androidx.core.content.ContextCompat;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.Manifest;
import android.content.pm.PackageManager;
import android.text.method.ScrollingMovementMethod;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }

private FasterM3BottomSheetLoader dataLoader;
private ActivityResultLauncher<String> requestPermissionLauncher;
	
	private HashMap<String, Object> getDataMap = new HashMap<>();
	private String passwordGet = "";
	private String usernameGet = "";
	private boolean ss = false;
	private HashMap<String, Object> getDataUpdateMap = new HashMap<>();
	private HashMap<String, Object> insertDataUpdateMap = new HashMap<>();
	private HashMap<String, Object> insertDataUpdateMap2 = new HashMap<>();
	private HashMap<String, Object> getDataMaintenanceMap = new HashMap<>();
	private HashMap<String, Object> insertDataMaintenanceMap = new HashMap<>();
	private HashMap<String, Object> countUsersMap = new HashMap<>();
	private HashMap<String, Object> countPremiumUsersMap = new HashMap<>();
	private HashMap<String, Object> countDepositMqp = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> getDataListUpdateMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> getDataListMaintenanceMap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> countPremiumUsersMap2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> countUsersMap2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> countDepositMap = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear_content;
	private LinearLayout linear2;
	private LinearLayout linear_item1;
	private LinearLayout linear_item2;
	private LinearLayout linear27;
	private TextView textview1;
	private ImageView imageview7;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private MaterialCardView linear_total_user;
	private MaterialCardView linear_premium_user;
	private LinearLayout linear9;
	private TextView textview2;
	private TextView textview_users_count;
	private LinearLayout linear10;
	private TextView textview4;
	private TextView textview_premium_users_count;
	private MaterialCardView linear_deposit;
	private LinearLayout linear12;
	private TextView textview6;
	private TextView textview_total_pending_deposit;
	private MaterialCardView linear_developer;
	private MaterialCardView linear_template_history;
	private MaterialCardView linear_update;
	private MaterialCardView linear_maintenance;
	private MaterialCardView linear_notification;
	private MaterialCardView linear_storage;
	private LinearLayout linear32;
	private LinearLayout linear33;
	private ImageView imageview6;
	private TextView textview20;
	private TextView textview21;
	private LinearLayout linear35;
	private LinearLayout linear36;
	private ImageView imageview8;
	private TextView textview22;
	private TextView textview23;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private ImageView imageview1;
	private TextView textview9;
	private TextView textview10;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private ImageView imageview2;
	private TextView textview11;
	private TextView textview12;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private ImageView imageview3;
	private TextView textview13;
	private TextView textview14;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private ImageView imageview4;
	private TextView textview15;
	private TextView textview16;
	
	private AlertDialog.Builder loginDialog;
	private RequestNetwork Network;
	private RequestNetwork.RequestListener _Network_request_listener;
	private ObjectAnimator animation1 = new ObjectAnimator();
	private AlertDialog.Builder InfoDialog;
	private Intent totalUserIntent = new Intent();
	private Intent totalPremiumUsersIntent = new Intent();
	private RequestNetwork getAndCountData;
	private RequestNetwork.RequestListener _getAndCountData_request_listener;
	private Intent intent = new Intent();
	private Intent depositIntent = new Intent();
	private OnCompleteListener needit_onCompleteListener;
	private Intent developer = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear_content = findViewById(R.id.linear_content);
		linear2 = findViewById(R.id.linear2);
		linear_item1 = findViewById(R.id.linear_item1);
		linear_item2 = findViewById(R.id.linear_item2);
		linear27 = findViewById(R.id.linear27);
		textview1 = findViewById(R.id.textview1);
		imageview7 = findViewById(R.id.imageview7);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear_total_user = findViewById(R.id.linear_total_user);
		linear_premium_user = findViewById(R.id.linear_premium_user);
		linear9 = findViewById(R.id.linear9);
		textview2 = findViewById(R.id.textview2);
		textview_users_count = findViewById(R.id.textview_users_count);
		linear10 = findViewById(R.id.linear10);
		textview4 = findViewById(R.id.textview4);
		textview_premium_users_count = findViewById(R.id.textview_premium_users_count);
		linear_deposit = findViewById(R.id.linear_deposit);
		linear12 = findViewById(R.id.linear12);
		textview6 = findViewById(R.id.textview6);
		textview_total_pending_deposit = findViewById(R.id.textview_total_pending_deposit);
		linear_developer = findViewById(R.id.linear_developer);
		linear_template_history = findViewById(R.id.linear_template_history);
		linear_update = findViewById(R.id.linear_update);
		linear_maintenance = findViewById(R.id.linear_maintenance);
		linear_notification = findViewById(R.id.linear_notification);
		linear_storage = findViewById(R.id.linear_storage);
		linear32 = findViewById(R.id.linear32);
		linear33 = findViewById(R.id.linear33);
		imageview6 = findViewById(R.id.imageview6);
		textview20 = findViewById(R.id.textview20);
		textview21 = findViewById(R.id.textview21);
		linear35 = findViewById(R.id.linear35);
		linear36 = findViewById(R.id.linear36);
		imageview8 = findViewById(R.id.imageview8);
		textview22 = findViewById(R.id.textview22);
		textview23 = findViewById(R.id.textview23);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		imageview1 = findViewById(R.id.imageview1);
		textview9 = findViewById(R.id.textview9);
		textview10 = findViewById(R.id.textview10);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		imageview2 = findViewById(R.id.imageview2);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		linear21 = findViewById(R.id.linear21);
		linear22 = findViewById(R.id.linear22);
		imageview3 = findViewById(R.id.imageview3);
		textview13 = findViewById(R.id.textview13);
		textview14 = findViewById(R.id.textview14);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		imageview4 = findViewById(R.id.imageview4);
		textview15 = findViewById(R.id.textview15);
		textview16 = findViewById(R.id.textview16);
		loginDialog = new AlertDialog.Builder(this);
		Network = new RequestNetwork(this);
		InfoDialog = new AlertDialog.Builder(this);
		getAndCountData = new RequestNetwork(this);
		
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MaterialAlertDialogBuilder InfoDialog = new MaterialAlertDialogBuilder(MainActivity.this);
				InfoDialog.setTitle("Full App Creator Info");
				InfoDialog.setMessage("App Name: Fritemp  \nVersion: 1.0  \nReleased: 2025  \nPlatform: Android (Sketchware Pro, Android Studio)\n\nDeveloped by:  \nFaster Software Developer  \nTakbir Hassan  \nTelegram: https://t.me/fastersoftwaredeveloper\nGitHub: https://github.com/FasterSoftwareDeveloper\n\nConcept, design, backend, and frontend by Takbir Hassan (Faster Software Developer).  \nBuilt using Sketchware Pro, Android studio with custom APIs and modern Android libraries.\n\nSpecial Thanks:  \n- Sketchware Pro Community  \n- Supabase Team (Auth & Storage)  \n- Cloudinary (Media Hosting)  \n- Firebase (Push Notifications)  \n- Google Material Design (UI)  \n- Unity Ads (Monetization SDK)  \n- Open-source library  \n\nTools and Tech Used:  \n- Java  \n- XML  \n- Supabase REST API  \n- Cloudinary REST API  \n- Firebase Messaging SDK  \n- Glide, OkHttp3, BlurView, OverScrollDecor, Peek & Pop, and more\n\n♥️ Support and Donations\nIf you appreciate the hard work behind this project, consider supporting the creator:\n\nBinance Pay ID: 766720837\nEvery donation helps us continue to improve and grow. Thank you for your generosity!\n\nBuilt with care for creators, editors, and designers across the world.  \nYour creativity deserves a home — welcome to Fritemp.\n\nDesigned to be Fast. Powerful. Modern.  \nCreated by Faster Software Developer.");
				InfoDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
					    @Override
					    public void onClick(DialogInterface _dialog, int _which) {
						         
						    }
				});
				InfoDialog.setCancelable(true);
				InfoDialog.create().show();
			}
		});
		
		linear_total_user.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				totalUserIntent.setClass(getApplicationContext(), ListUserActivity.class);
				totalUserIntent.putExtra("mode", "free");
				ActivityOptions totalUserIntentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(totalUserIntent, totalUserIntentOp.toBundle());
			}
		});
		
		linear_premium_user.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				totalPremiumUsersIntent.setClass(getApplicationContext(), ListUserActivity.class);
				totalPremiumUsersIntent.putExtra("mode", "premium");
				ActivityOptions totalPremiumUsersIntentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(totalPremiumUsersIntent, totalPremiumUsersIntentOp.toBundle());
			}
		});
		
		linear_deposit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				depositIntent.setClass(getApplicationContext(), DepositLisrActivity.class);
				ActivityOptions depositIntentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(depositIntent, depositIntentOp.toBundle());
				finish();
			}
		});
		
		linear_developer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				developer.setClass(getApplicationContext(), DeveloperOptionActivity.class);
				ActivityOptions developerOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(developer, developerOp.toBundle());
				finish();
			}
		});
		
		linear_template_history.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), TemplateHistoryActivity.class);
				ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(intent, intentOp.toBundle());
				finish();
			}
		});
		
		linear_update.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Network.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "app_mode" + "?apikey=" + getString(R.string.database_api_key), "B", _Network_request_listener);
			}
		});
		
		linear_maintenance.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Network.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "app_mode" + "?apikey=" + getString(R.string.database_api_key), "C", _Network_request_listener);
			}
		});
		
		linear_notification.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				depositIntent.setClass(getApplicationContext(), NotificationActivity.class);
				ActivityOptions depositIntentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(depositIntent, depositIntentOp.toBundle());
				finish();
			}
		});
		
		linear_storage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				depositIntent.setClass(getApplicationContext(), TemplateListActivity.class);
				ActivityOptions depositIntentOp = ActivityOptions.makeCustomAnimation(MainActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(depositIntent, depositIntentOp.toBundle());
			}
		});
		
		_Network_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("B")) {
					// Start: "convert json response to map"
					getDataListUpdateMap.clear();
					getDataUpdateMap.clear();
					getDataListUpdateMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					getDataUpdateMap = getDataListUpdateMap.get((int)0);
					//End: "convert json response to map"
					_updateBottomSheet();
				}
				if (_tag.equals("C")) {
					// Start: "convert json response to map"
					getDataListMaintenanceMap.clear();
					getDataMaintenanceMap.clear();
					getDataListMaintenanceMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					getDataMaintenanceMap = getDataListMaintenanceMap.get((int)0);
					//End: "convert json response to map"
					_maintenance();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				if (_tag.equals("B")) {
					com.google.android.material.snackbar.Snackbar.make(linear_content, "No Internet Connection", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				}
				if (_tag.equals("C")) {
					com.google.android.material.snackbar.Snackbar.make(linear_content, "No Internet Connection", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				}
			}
		};
		
		_getAndCountData_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("free")) {
					countUsersMap2 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					textview_users_count.setText(String.valueOf((long)(countUsersMap2.size())));
				} else {
					if (_tag.equals("premium")) {
						countPremiumUsersMap2 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						textview_premium_users_count.setText(String.valueOf((long)(countPremiumUsersMap2.size())));
					} else {
						if (_tag.equals("deposit")) {
							countDepositMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
							textview_total_pending_deposit.setText(String.valueOf((long)(countDepositMap.size())));
						}
					}
				}
				dataLoader.dismiss();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// Start: "Notification permission"
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			requestPermissionLauncher = registerForActivityResult(
			            new ActivityResultContracts.RequestPermission(),
			            isGranted -> {
				                if (isGranted) {
					                } else {
					                }
				            }
			        );
		} else {
		}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS)
			                    == PackageManager.PERMISSION_DENIED) {
				                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
				            } else {
				}
		}else {
		}
		//End: "Notification permission"
		// Start: "Subscribe fcm topic"
		FirebaseMessaging.getInstance().subscribeToTopic("admin")
		    .addOnCompleteListener(new OnCompleteListener<Void>() {
			        @Override
			        public void onComplete(@NonNull Task<Void> task) {
				            if (task.isSuccessful()) {
					            } else {
					            }
				        }
			    });
		//End: "Subscribe fcm topic"
		// Start: "remove unnecessary imports"
		//End: "remove unnecessary imports"
		// Start: "Loader"
		dataLoader = new FasterM3BottomSheetLoader(MainActivity.this);
		dataLoader.setCancelableOnOutsideClick(false);
		//End: "Loader"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
		// Start: "Loader"
		dataLoader.show("counting data...");
		//End: "Loader"
		// Start: "count data"
		countPremiumUsersMap = new HashMap<>(); 
		countPremiumUsersMap.put("apikey", getString(R.string.database_api_key));
		getAndCountData.setHeaders(countPremiumUsersMap);
		getAndCountData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "account type" + "=eq." + "premium", "premium", _getAndCountData_request_listener);
		countUsersMap = new HashMap<>(); 
		countUsersMap.put("apikey", getString(R.string.database_api_key));
		getAndCountData.setHeaders(countUsersMap);
		getAndCountData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "allaccountdata" + "?" + "account type" + "=eq." + "free", "free", _getAndCountData_request_listener);
		countDepositMqp = new HashMap<>(); 
		countDepositMqp.put("apikey", getString(R.string.database_api_key));
		getAndCountData.setHeaders(countDepositMqp);
		getAndCountData.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "history" + "?" + "status" + "=eq." + "pending", "deposit", _getAndCountData_request_listener);
		//End: "count data"
	}
	
	public void _switch_on(final View _bg, final View _thumb1, final View _thumb2) {
		ss = true;
		_bg.setBackground(new GradientDrawable() {
			    public GradientDrawable getIns(int a, int b) {
				        this.setCornerRadius(a);
				        this.setColor(b);
				        return this;
				    }
		}.getIns(360, ContextCompat.getColor(this, R.color.switchBgColor)));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() - 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _switch_off(final View _bg, final View _thumb1, final View _thumb2) {
		ss = false;
		_bg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)6, 0xFF808C98, 0x33B4B6B9));
		_thumb2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF808C98));
		_thumb1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, Color.TRANSPARENT));
		animation1.setTarget(_thumb1);
		animation1.setPropertyName("translationX");
		animation1.setFloatValues((float)(_thumb1.getTranslationX() + 35), (float)(_thumb1.getTranslationX()));
		animation1.setDuration((int)(200));
		animation1.start();
	}
	
	
	public void _updateBottomSheet() {
		final
		com.google.android.material.bottomsheet.BottomSheetDialog UpdateBottomSheet = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
		View UpdateDesign = getLayoutInflater().inflate(R.layout.m3_bottom_sheet, null);
		UpdateBottomSheet.setContentView(UpdateDesign);
		UpdateBottomSheet.getWindow().getDecorView().setBackgroundColor(0);
		final TextView t1 = UpdateDesign.findViewById(R.id.t1);
		final LinearLayout switch_bg = UpdateDesign.findViewById(R.id.switch_bg);
		final LinearLayout switch_thumb = UpdateDesign.findViewById(R.id.switch_thumb);
		final LinearLayout SD2 = UpdateDesign.findViewById(R.id.SD2);
		final LinearLayout linear_body = UpdateDesign.findViewById(R.id.linear_body);
		final Button bt1 = UpdateDesign.findViewById(R.id.bt1);
		final Button bt2 = UpdateDesign.findViewById(R.id.bt2);
		final EditText et1 = UpdateDesign.findViewById(R.id.et1);
		final EditText et2 = UpdateDesign.findViewById(R.id.et2);
		final EditText et3 = UpdateDesign.findViewById(R.id.et3);
		t1.setText("Update Manager");
		et1.setHint("App Link");
		et2.setHint("Version (e.g 1.0)");
		et3.setHint("What's New?");
		et1.setText(getDataUpdateMap.get("app_link").toString());
		et2.setText(getDataUpdateMap.get("app_version").toString());
		et3.setText(getDataUpdateMap.get("about").toString());
		if (getDataUpdateMap.get("update_mode").toString().equals("on")) {
			_switch_on(switch_bg, switch_thumb, SD2);
			switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
			et1.setEnabled(true);
			et2.setEnabled(true);
			et3.setEnabled(true);
			ss = true;
		} else {
			if (getDataUpdateMap.get("update_mode").toString().equals("off")) {
				_switch_off(switch_bg, switch_thumb, SD2);
				switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				et1.setEnabled(false);
				et2.setEnabled(false);
				et3.setEnabled(false);
				ss = false;
			}
		}
		bt1.setOnClickListener(v -> {
			UpdateBottomSheet.dismiss();
					        });
		bt2.setOnClickListener(v -> {
			if (et1.getText().toString().isEmpty() || (et2.getText().toString().isEmpty() || et3.getText().toString().isEmpty())) {
				com.google.android.material.snackbar.Snackbar.make(linear_body, "You left some details empty.", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			} else {
				UpdateBottomSheet.dismiss();
				insertDataUpdateMap.clear();
				if (ss) {
					insertDataUpdateMap = new Gson().fromJson("{" + "\"" + "app_link" + "\":\"" + et1.getText().toString() + "\"," + "\"" + "app_version" + "\":\"" + et2.getText().toString() + "\"," + "\"" + "about" + "\":\"" + et3.getText().toString() + "\"," + "\"" + "update_mode" + "\":\"" + "on" + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
				} else {
					insertDataUpdateMap = new Gson().fromJson("{" + "\"" + "app_link" + "\":\"" + et1.getText().toString() + "\"," + "\"" + "app_version" + "\":\"" + et2.getText().toString() + "\"," + "\"" + "about" + "\":\"" + et3.getText().toString() + "\"," + "\"" + "update_mode" + "\":\"" + "off" + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
				}
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "app_mode" + "?id=eq." + "1")
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(insertDataUpdateMap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                 
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                     
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                     
									                }
								            });
							        }
						    }
				});
			}
					        });
		switch_bg.setOnClickListener(v -> {
			if (ss) {
				_switch_off(switch_bg, switch_thumb, SD2);
				switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				et1.setEnabled(false);
				et2.setEnabled(false);
				et3.setEnabled(false);
				ss = false;
			} else {
				_switch_on(switch_bg, switch_thumb, SD2);
				switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
				ss = true;
				et1.setEnabled(true);
				et2.setEnabled(true);
				et3.setEnabled(true);
			}
					        });
		UpdateBottomSheet.setCancelable(true);
		UpdateBottomSheet.show();
	}
	
	
	public void _maintenance() {
		final
		com.google.android.material.bottomsheet.BottomSheetDialog MaintenanceBottomSheet = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
		View MaintenanceDesign = getLayoutInflater().inflate(R.layout.m3_bottom_sheet, null);
		MaintenanceBottomSheet.setContentView(MaintenanceDesign);
		MaintenanceBottomSheet.getWindow().getDecorView().setBackgroundColor(0);
		final TextView t1 = MaintenanceDesign.findViewById(R.id.t1);
		final LinearLayout switch_bg = MaintenanceDesign.findViewById(R.id.switch_bg);
		final LinearLayout switch_thumb = MaintenanceDesign.findViewById(R.id.switch_thumb);
		final LinearLayout SD2 = MaintenanceDesign.findViewById(R.id.SD2);
		final LinearLayout linear_content = MaintenanceDesign.findViewById(R.id.linear_content);
		t1.setText("Maintenance Mode");
		linear_content.setVisibility(View.GONE);
		if (getDataMaintenanceMap.get("maintenance_mode").toString().equals("on")) {
			_switch_on(switch_bg, switch_thumb, SD2);
			switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
			ss = true;
		} else {
			if (getDataMaintenanceMap.get("maintenance_mode").toString().equals("off")) {
				_switch_off(switch_bg, switch_thumb, SD2);
				switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				ss = false;
			}
		}
		switch_bg.setOnClickListener(v -> {
			if (ss) {
				_switch_off(switch_bg, switch_thumb, SD2);
				switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				ss = false;
				insertDataMaintenanceMap = new Gson().fromJson("{" + "\"" + "maintenance_mode" + "\":\"" + "off" + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "app_mode" + "?id=eq." + "1")
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(insertDataMaintenanceMap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                 
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                     
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                     
									                }
								            });
							        }
						    }
				});
			} else {
				_switch_on(switch_bg, switch_thumb, SD2);
				switch_bg.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
				ss = true;
				insertDataMaintenanceMap = new Gson().fromJson("{" + "\"" + "maintenance_mode" + "\":\"" + "on" + "\"" + "}", new TypeToken<HashMap<String, Object>>(){}.getType());
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "app_mode" + "?id=eq." + "1")
				    .addHeader("apikey", getString(R.string.database_api_key))
				    .patch(RequestBody.create(
				        MediaType.parse("application/json; charset=utf-8"),
				        new Gson().toJson(insertDataMaintenanceMap)
				    ))
				    .build();
				client.newCall(request).enqueue(new Callback() {
					    @Override
					    public void onFailure(Call call, IOException e) {
						        final String errorMessage = e.getMessage();
						        new Handler(Looper.getMainLooper()).post(new Runnable() {
							            @Override
							            public void run() {
								                 
								            }
							        });
						    }
					    @Override
					    public void onResponse(Call call, Response response) throws IOException {
						        final String responseMessage = response.body().string(); 
						        if (response.isSuccessful()) {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                     
									                }
								            });
							        } else {
							            new Handler(Looper.getMainLooper()).post(new Runnable() {
								                @Override
								                public void run() {
									                     
									                }
								            });
							        }
						    }
				});
			}
					        });
		MaintenanceBottomSheet.setCancelable(true);
		MaintenanceBottomSheet.show();
	}
	
}