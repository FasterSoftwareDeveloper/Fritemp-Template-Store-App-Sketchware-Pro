package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.chip.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class NotificationActivity extends AppCompatActivity {
	
	private String ProjectID = "";
	private String accessToken = "";
	private String accessTokenError = "";
	private HashMap<String, Object> notification_map = new HashMap<>();
	private String onSuccess = "";
	private String onError = "";
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextInputLayout input1;
	private TextInputLayout input2;
	private TextInputLayout input3;
	private TextInputLayout input4;
	private LinearLayout linear3;
	private TextInputLayout input5;
	private TextInputLayout textinput_question1;
	private LinearLayout linear2;
	private EditText et1;
	private EditText et2;
	private EditText et3;
	private EditText et4;
	private Chip linear_topic;
	private Chip linear_token;
	private EditText et5;
	private AutoCompleteTextView autocomplete_question1;
	private Button button_access;
	private Button button_send;
	
	private AlertDialog.Builder errorDialog;
	private Intent backIntent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.notification);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		input1 = findViewById(R.id.input1);
		input2 = findViewById(R.id.input2);
		input3 = findViewById(R.id.input3);
		input4 = findViewById(R.id.input4);
		linear3 = findViewById(R.id.linear3);
		input5 = findViewById(R.id.input5);
		textinput_question1 = findViewById(R.id.textinput_question1);
		linear2 = findViewById(R.id.linear2);
		et1 = findViewById(R.id.et1);
		et2 = findViewById(R.id.et2);
		et3 = findViewById(R.id.et3);
		et4 = findViewById(R.id.et4);
		linear_topic = findViewById(R.id.linear_topic);
		linear_token = findViewById(R.id.linear_token);
		et5 = findViewById(R.id.et5);
		autocomplete_question1 = findViewById(R.id.autocomplete_question1);
		button_access = findViewById(R.id.button_access);
		button_send = findViewById(R.id.button_send);
		errorDialog = new AlertDialog.Builder(this);
		
		linear_topic.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_topic.setChecked(true);
				linear_token.setChecked(false);
			}
		});
		
		linear_token.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_topic.setChecked(false);
				linear_token.setChecked(true);
			}
		});
		
		button_access.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					    try (InputStream originalInputStream = getAssets().open("service-account.json")) {
						        byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
						
						        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
							            String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
							            HashMap<String, Object> map = new Gson().fromJson(
							                jsonString,
							                new TypeToken<HashMap<String, Object>>(){}.getType()
							            );
							            ProjectID = map.get("project_id").toString();
							        }
						
						        try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
							            AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.OnTokenResponse() {
								                @Override
								                public void onSuccess(String token) {
									                    JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
									                    if (jsonResponse.has("access_token")) {
										                        accessToken = jsonResponse.get("access_token").getAsString();
										                        runOnUiThread(() -> {
											                            button_send.setVisibility(View.VISIBLE);
											                            button_access.setVisibility(View.GONE);
											                            _TransitionManager(linear1, 250);
											                        });
										                    } else {
										                        accessToken = "error getting accessToken";
										                    }
									                }
								
								                @Override
								                public void onError(String error) {
									                    accessTokenError = error;
									                    runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
									                }
								            });
							        }
						    } catch (IOException e) {
						        accessTokenError = "Error reading service account file: " + e.getMessage();
						        runOnUiThread(() -> _m3ErrorDialog(accessTokenError));
						    }
				} catch (Exception e) {
					    runOnUiThread(() -> _m3ErrorDialog("Unexpected error: " + e.getMessage()));
				}
			}
		});
		
		button_send.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (et4.getText().toString().isEmpty()) {
					com.google.android.material.snackbar.Snackbar.make(linear1, "Notification token/topic is empty!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
					button_send.setEnabled(false);
					if (linear_topic.isChecked()) {
						_FasterNotificationSender(et1.getText().toString(), et2.getText().toString(), et3.getText().toString(), autocomplete_question1.getText().toString(), et4.getText().toString(), "", et5.getText().toString());
					} else {
						_FasterNotificationSender(et1.getText().toString(), et2.getText().toString(), et3.getText().toString(), autocomplete_question1.getText().toString(), "", et4.getText().toString(), et5.getText().toString());
					}
				}
			}
		});
	}
	
	private void initializeLogic() {
		// Start: "others"
		button_send.setVisibility(View.GONE);
		autocomplete_question1.setInputType(InputType.TYPE_NULL);
		String[] type = new String[] {"MainActivity","DashboardActivity","RechargeActivity","PlanActivity","TemplateHistoryActivity"};
		        ArrayAdapter<String> adapter =
		                new ArrayAdapter<>(
		                        this,
		                        R.layout.spinner_cus,
		                        R.id.textview1,
		                        type);
		        autocomplete_question1.setAdapter(adapter);
		//End: "others"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), MainActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(NotificationActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());
				finish();
			}
		});
	}
	
	public void _m3ErrorDialog(final String _massage) {
		MaterialAlertDialogBuilder errorDialog = new MaterialAlertDialogBuilder(NotificationActivity.this);
		errorDialog.setTitle("Error!");
		errorDialog.setMessage(_massage);
		errorDialog.setNegativeButton("Close", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				         
				    }
		});
		errorDialog.setCancelable(true);
		errorDialog.create().show();
	}
	
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _FasterNotificationSender(final String _title, final String _body, final String _imageUrl, final String _contextactivity, final String _topic, final String _token, final String _extraText) {
		notification_map = new HashMap<>();
		notification_map.put("title", _title);
		notification_map.put("body", _body);
		if (!_imageUrl.equals("")) {
			notification_map.put("image", _imageUrl);
		}
		if (!_extraText.equals("")) {
			notification_map.put("extraData", _extraText);
		}
		if (!_contextactivity.equals("")) {
			notification_map.put("ContextActivity", _contextactivity);
		}
		if (_token.equals("")) {
			// Start: "Send notification with topic"
			    String topic = _topic;
			    String token = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					runOnUiThread(() -> {
						com.google.android.material.snackbar.Snackbar.make(linear1, "Notification send success", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
						et1.setText("");
						et2.setText("");
						et3.setText("");
						et4.setText("");
						et5.setText("");
						button_send.setEnabled(true);
						linear_topic.setChecked(true);
						linear_token.setChecked(false);
					});
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						_m3ErrorDialog(onError);
						button_send.setEnabled(true);
					});
					        }
				    });
			//End: "Send notification with topic"
		} else {
			// Start: "Send notification with token"
			    String token = _token;
			    String topic = "";
			    String projectId = ProjectID;
			    String tokenaccess = accessToken; 
			    FCMNotificationSender.sendNotification(notification_map, topic, token, projectId, tokenaccess, new FCMNotificationSender.OnResponse() {
				        @Override
				        public void onSuccess(String response) {
					            onSuccess = response;
					runOnUiThread(() -> {
						com.google.android.material.snackbar.Snackbar.make(linear1, "Notification send success", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
						et1.setText("");
						et2.setText("");
						et3.setText("");
						et4.setText("");
						et5.setText("");
						button_send.setEnabled(true);
						linear_topic.setChecked(true);
						linear_token.setChecked(false);
					});
					        }
				
				        @Override
				        public void onError(String error) {
					            onError = error;
					runOnUiThread(() -> {
						button_send.setEnabled(true);
						_m3ErrorDialog(onError);
					});
					        }
				    });
			//End: "Send notification with token"
		}
	}
	
}