package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;

public class TemplateListActivity extends AppCompatActivity {

private FasterM3BottomSheetLoader loader;
	
	private FloatingActionButton _fab;
	private HashMap<String, Object> getDataMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> TemplateMap = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextInputLayout layout1;
	private ListView listview1;
	private LinearLayout linear_status;
	private EditText et1;
	private TextView textview2;
	
	private Intent intent_add = new Intent();
	private RequestNetwork rq_for_data;
	private RequestNetwork.RequestListener _rq_for_data_request_listener;
	private Intent view_intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.template_list);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		layout1 = findViewById(R.id.layout1);
		listview1 = findViewById(R.id.listview1);
		linear_status = findViewById(R.id.linear_status);
		et1 = findViewById(R.id.et1);
		textview2 = findViewById(R.id.textview2);
		rq_for_data = new RequestNetwork(this);
		
		et1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				getDataMap = new HashMap<>(); 
				getDataMap.put("apikey", getString(R.string.database_api_key));
				rq_for_data.setHeaders(getDataMap);
				rq_for_data.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "title" + "=ilike.*" + _charSeq + "*", "B", _rq_for_data_request_listener);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent_add.setClass(getApplicationContext(), AddTemplateActivity.class);
				ActivityOptions intent_addOp = ActivityOptions.makeCustomAnimation(TemplateListActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(intent_add, intent_addOp.toBundle());
			}
		});
		
		_rq_for_data_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						if (!_tag.equals("B")) {
						loader.dismiss();
					}
					linear_status.setVisibility(View.VISIBLE);
					listview1.setVisibility(View.GONE);
				} else {
						if (_tag.equals("B")) {
						TemplateMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						Collections.reverse(TemplateMap);
						listview1.setAdapter(new Listview1Adapter(TemplateMap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						_TransitionManager(linear1, 300);
					} else {
						loader.dismiss();
						TemplateMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						Collections.reverse(TemplateMap);
						listview1.setAdapter(new Listview1Adapter(TemplateMap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					linear_status.setVisibility(View.GONE);
					listview1.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		rq_for_data.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?apikey=" + getString(R.string.database_api_key), "A", _rq_for_data_request_listener);
		loader = new FasterM3BottomSheetLoader(TemplateListActivity.this);
		loader.setCancelableOnOutsideClick(false);
		loader.show("Getting data.....");
		Animation animation = AnimationUtils.loadAnimation(this, R.anim.listview_item_animation);
		listview1.setLayoutAnimation(new LayoutAnimationController(animation, 0.2f));
		linear_status.setVisibility(View.GONE);
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				intent_add.setClass(getApplicationContext(), MainActivity.class);
				ActivityOptions intent_addOp = ActivityOptions.makeCustomAnimation(TemplateListActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(intent_add, intent_addOp.toBundle());
				finish();
			}
		});
	}
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.templates_cus, null);
			}
			
			final com.google.android.material.card.MaterialCardView linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final com.google.android.material.card.MaterialCardView img_main = _view.findViewById(R.id.img_main);
			final ImageView img = _view.findViewById(R.id.img);
			final TextView title = _view.findViewById(R.id.title);
			final HorizontalScrollView hscroll1 = _view.findViewById(R.id.hscroll1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final com.google.android.material.chip.Chip chip_item_category = _view.findViewById(R.id.chip_item_category);
			final com.google.android.material.chip.Chip chip_category = _view.findViewById(R.id.chip_category);
			final com.google.android.material.chip.Chip chip_type = _view.findViewById(R.id.chip_type);
			final com.google.android.material.chip.Chip chip_template_type = _view.findViewById(R.id.chip_template_type);
			final com.google.android.material.chip.Chip chip_price = _view.findViewById(R.id.chip_price);
			final com.google.android.material.chip.Chip chip_gets = _view.findViewById(R.id.chip_gets);
			
			if (_data.get((int)_position).containsKey("title")) {
				title.setText(_data.get((int)_position).get("title").toString());
			}
			if (_data.get((int)_position).containsKey("image")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image").toString())).into(img);
			}
			if (_data.get((int)_position).containsKey("category")) {
				chip_category.setText(_data.get((int)_position).get("category").toString());
			}
			if (_data.get((int)_position).containsKey("media type")) {
				chip_type.setText(_data.get((int)_position).get("media type").toString());
			}
			if (_data.get((int)_position).containsKey("price")) {
				chip_price.setText(_data.get((int)_position).get("price").toString());
			}
			if (_data.get((int)_position).containsKey("template type")) {
				chip_template_type.setText(_data.get((int)_position).get("template type").toString());
			}
			if (_data.get((int)_position).containsKey("gets")) {
				chip_gets.setText(_data.get((int)_position).get("gets").toString());
			}
			if (_data.get((int)_position).containsKey("item category")) {
				chip_item_category.setText(_data.get((int)_position).get("item category").toString());
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					view_intent.setClass(getApplicationContext(), AddTemplateActivity.class);
					view_intent.putExtra("key", _data.get((int)_position).get("main key").toString());
					ActivityOptions view_intentOp = ActivityOptions.makeCustomAnimation(TemplateListActivity.this, R.anim.fade_in, R.anim.fade_out);
					startActivity(view_intent, view_intentOp.toBundle());
					finish();
				}
			});
			
			return _view;
		}
	}
}