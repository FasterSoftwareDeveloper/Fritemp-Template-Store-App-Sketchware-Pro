package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.google.android.material.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;

public class LoginActivity extends AppCompatActivity {

private FasterM3BottomSheetLoader loader;
	
	private String usernameGet = "";
	private String passwordGet = "";
	private HashMap<String, Object> getDataMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	
	private LinearLayout linear1;
	
	private RequestNetwork Network;
	private RequestNetwork.RequestListener _Network_request_listener;
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		Network = new RequestNetwork(this);
		
		_Network_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_tag.equals("A")) {
					// Start: "convert json response to map"
					getDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					getDataMap = getDataListMap.get((int)0);
					//End: "convert json response to map"
					// Start: "Check Details"
					if (getDataMap.containsKey("username")) {
						if (getDataMap.containsKey("password")) {
							if (usernameGet.equals(getDataMap.get("username").toString()) && passwordGet.equals(getDataMap.get("password").toString())) {
								loader.dismiss();
								intent.setClass(getApplicationContext(), MainActivity.class);
								ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(LoginActivity.this, R.anim.fade_in, R.anim.fade_out);
								startActivity(intent, intentOp.toBundle());
								finish();
							} else {
								loader.dismiss();
								_login();
								com.google.android.material.snackbar.Snackbar.make(linear1, "Details Not Match", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							}
						}
					}
					passwordGet = "";
					usernameGet = "";
					//End: "Check Details"
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				if (_tag.equals("A")) {
					loader.dismiss();
					_login();
					com.google.android.material.snackbar.Snackbar.make(linear1, "No Internet Connection", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				}
			}
		};
	}
	
	private void initializeLogic() {
		loader = new FasterM3BottomSheetLoader(LoginActivity.this);
		loader.setCancelableOnOutsideClick(false);
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				finishAffinity();
			}
		});
		_login();
	}
	
	public void _login() {
		MaterialAlertDialogBuilder loginDialog = new MaterialAlertDialogBuilder(LoginActivity.this);
		loginDialog.setTitle("Authentication Need!");
		loginDialog.setMessage("Type admin login details to access the panel.");
		loginDialog.setIcon(R.drawable.icon_login);
		View loginView = LayoutInflater.from(LoginActivity.this).inflate(R.layout.text_input_dialog, null);
		loginDialog.setView(loginView);
		final EditText et1 = loginView.findViewById(R.id.et1);
		final EditText et2 = loginView.findViewById(R.id.et2);
		et1.setHint("Username");
		et2.setHint("Password");
		loginDialog.setPositiveButton("Login", new DialogInterface.OnClickListener() {
			    @Override
			    public void onClick(DialogInterface _dialog, int _which) {
				        loader.show("Checking.....");
				Network.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "FasterPanel" + "?apikey=" + getString(R.string.database_api_key), "A", _Network_request_listener);
				usernameGet = et1.getText().toString();
				passwordGet = et2.getText().toString();
				    }
		});
		loginDialog.setCancelable(false);
		loginDialog.create().show();
	}
	
}