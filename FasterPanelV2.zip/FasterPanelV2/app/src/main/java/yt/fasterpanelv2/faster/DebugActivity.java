package yt.fasterpanelv2.faster;

import android.app.Activity;

public class DebugActivity extends Activity {
}
