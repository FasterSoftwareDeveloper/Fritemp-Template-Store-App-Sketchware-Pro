package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.android.material.card.*;
import com.google.android.material.chip.*;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.activity.result.ActivityResultCallback;
import java.io.InputStream;
import android.database.Cursor;
import com.bumptech.glide.Glide;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import android.provider.OpenableColumns;

public class AddTemplateActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }

private FasterM3BottomSheetLoader uploader;
ActivityResultLauncher<String> launcher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri) {
                    if (uri == null) {
                    } else {
                        imagePath = _saveUriToFile(uri.toString());
                        Glide.with(getApplicationContext()).load(uri).into(imageviewPortrait);
                        Glide.with(getApplicationContext()).load(uri).into(imageviewLandscape);
                        imageviewLandscape.setVisibility(View.VISIBLE);
                        imageviewPortrait.setVisibility(View.VISIBLE);
                    }
                }
            });
            
ActivityResultLauncher<String> videoLauncher = registerForActivityResult(
    new ActivityResultContracts.GetContent(),
    new ActivityResultCallback<Uri>() {
        @Override
        public void onActivityResult(Uri uri) {
            if (uri == null) {
            } else {
                videoPath = _saveVideoUriToFile(uri.toString());
                button_promo.setText("Re-select");
            }
        }
    });
    
ActivityResultLauncher<String> templateFilePicker = registerForActivityResult(
    new ActivityResultContracts.GetContent(),
    new ActivityResultCallback<Uri>() {
        @Override
        public void onActivityResult(Uri uri) {
            if (uri != null) {
                String zipPath = _savePickedFileAndZipIt(uri);
                if (zipPath != null && !zipPath.isEmpty()) {
                    pickedTemplatePath = zipPath;
                    button_upload_file.setText("Re-select");
                } else {
                    pickedTemplatePath = "";
                    _showError();
                }
            }
        }
    });

private FasterM3BottomSheetLoader loader;
	
	private String mediaType = "";
	private String templateType = "";
	private String imagePath = "";
	private String videoPath = "";
	private String pickedTemplatePath = "";
	private String chip_template_file_type_str = "";
	private String chip_ad_type_str = "";
	private String price_str = "";
	private String media1_token = "";
	private String media2_file_name = "";
	private String media3_token = "";
	private HashMap<String, Object> databaseHeaderMap = new HashMap<>();
	private HashMap<String, Object> databaseValueMap = new HashMap<>();
	private String imageUrl = "";
	private String videoUrl = "";
	private String fileUrl = "";
	private HashMap<String, Object> getDatarq = new HashMap<>();
	private HashMap<String, Object> setDataMap = new HashMap<>();
	private HashMap<String, Object> updateMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> setDataListMap = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear_body;
	private LinearLayout linear5;
	private MaterialCardView linear_promo;
	private LinearLayout linear10;
	private LinearLayout linear36;
	private MaterialCardView linear_portrait;
	private MaterialCardView linear_Landscape;
	private RelativeLayout relativelayout1;
	private ImageView imageviewPortrait;
	private MaterialButton button_Portrait;
	private RelativeLayout relativelayout2;
	private ImageView imageviewLandscape;
	private MaterialButton button_Landscape;
	private LinearLayout linear9;
	private LinearLayout linear8;
	private MaterialButton button_promo;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3;
	private LinearLayout linear28;
	private LinearLayout linear32;
	private MaterialCardView linear_file;
	private TextInputLayout layout_direct_file_link;
	private Chip linear_chip_UploadFile;
	private Chip linear_chip_direct_file_link;
	private Chip linear_chip_email;
	private Chip linear_chip_direct_massage;
	private LinearLayout linear34;
	private LinearLayout linear35;
	private MaterialButton button_upload_file;
	private TextView textview_upload_file_title;
	private TextView textview_upload_file_helper;
	private EditText et_direct_file_link;
	private TextView textview4;
	private TextInputLayout layout_title;
	private TextInputLayout layout_description;
	private TextInputLayout textinputlayout_duration;
	private LinearLayout linear40;
	private LinearLayout linear44;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear37;
	private TextView textview_file_url;
	private LinearLayout linear39;
	private EditText edittext_title;
	private EditText edittext_description;
	private EditText edittext_duration;
	private TextInputLayout textinput_category;
	private MaterialButton textview_clear1;
	private AutoCompleteTextView autocomplete_category;
	private TextInputLayout textinputlayout_item_category;
	private MaterialButton textview_clear2;
	private AutoCompleteTextView autocomplete_item_category;
	private LinearLayout linear38;
	private Chip linear_rewarded_ads;
	private Chip linear_Interstitial;
	private Chip linear_no_ads;
	private Chip linear_chip_free;
	private Chip linear_premium_need;
	private Button button_publish;
	private Button button_delete;
	
	private AlertDialog.Builder templateDialog;
	private RequestNetwork databaseRq;
	private RequestNetwork.RequestListener _databaseRq_request_listener;
	private Intent backIntent = new Intent();
	private RequestNetwork setDataRq;
	private RequestNetwork.RequestListener _setDataRq_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.add_template);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear_body = findViewById(R.id.linear_body);
		linear5 = findViewById(R.id.linear5);
		linear_promo = findViewById(R.id.linear_promo);
		linear10 = findViewById(R.id.linear10);
		linear36 = findViewById(R.id.linear36);
		linear_portrait = findViewById(R.id.linear_portrait);
		linear_Landscape = findViewById(R.id.linear_Landscape);
		relativelayout1 = findViewById(R.id.relativelayout1);
		imageviewPortrait = findViewById(R.id.imageviewPortrait);
		button_Portrait = findViewById(R.id.button_Portrait);
		relativelayout2 = findViewById(R.id.relativelayout2);
		imageviewLandscape = findViewById(R.id.imageviewLandscape);
		button_Landscape = findViewById(R.id.button_Landscape);
		linear9 = findViewById(R.id.linear9);
		linear8 = findViewById(R.id.linear8);
		button_promo = findViewById(R.id.button_promo);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		linear28 = findViewById(R.id.linear28);
		linear32 = findViewById(R.id.linear32);
		linear_file = findViewById(R.id.linear_file);
		layout_direct_file_link = findViewById(R.id.layout_direct_file_link);
		linear_chip_UploadFile = findViewById(R.id.linear_chip_UploadFile);
		linear_chip_direct_file_link = findViewById(R.id.linear_chip_direct_file_link);
		linear_chip_email = findViewById(R.id.linear_chip_email);
		linear_chip_direct_massage = findViewById(R.id.linear_chip_direct_massage);
		linear34 = findViewById(R.id.linear34);
		linear35 = findViewById(R.id.linear35);
		button_upload_file = findViewById(R.id.button_upload_file);
		textview_upload_file_title = findViewById(R.id.textview_upload_file_title);
		textview_upload_file_helper = findViewById(R.id.textview_upload_file_helper);
		et_direct_file_link = findViewById(R.id.et_direct_file_link);
		textview4 = findViewById(R.id.textview4);
		layout_title = findViewById(R.id.layout_title);
		layout_description = findViewById(R.id.layout_description);
		textinputlayout_duration = findViewById(R.id.textinputlayout_duration);
		linear40 = findViewById(R.id.linear40);
		linear44 = findViewById(R.id.linear44);
		hscroll1 = findViewById(R.id.hscroll1);
		linear37 = findViewById(R.id.linear37);
		textview_file_url = findViewById(R.id.textview_file_url);
		linear39 = findViewById(R.id.linear39);
		edittext_title = findViewById(R.id.edittext_title);
		edittext_description = findViewById(R.id.edittext_description);
		edittext_duration = findViewById(R.id.edittext_duration);
		textinput_category = findViewById(R.id.textinput_category);
		textview_clear1 = findViewById(R.id.textview_clear1);
		autocomplete_category = findViewById(R.id.autocomplete_category);
		textinputlayout_item_category = findViewById(R.id.textinputlayout_item_category);
		textview_clear2 = findViewById(R.id.textview_clear2);
		autocomplete_item_category = findViewById(R.id.autocomplete_item_category);
		linear38 = findViewById(R.id.linear38);
		linear_rewarded_ads = findViewById(R.id.linear_rewarded_ads);
		linear_Interstitial = findViewById(R.id.linear_Interstitial);
		linear_no_ads = findViewById(R.id.linear_no_ads);
		linear_chip_free = findViewById(R.id.linear_chip_free);
		linear_premium_need = findViewById(R.id.linear_premium_need);
		button_publish = findViewById(R.id.button_publish);
		button_delete = findViewById(R.id.button_delete);
		templateDialog = new AlertDialog.Builder(this);
		databaseRq = new RequestNetwork(this);
		setDataRq = new RequestNetwork(this);
		
		button_Portrait.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				launcher.launch("image/*");
			}
		});
		
		button_Landscape.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				launcher.launch("image/*");
			}
		});
		
		button_promo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				videoLauncher.launch("video/*");
			}
		});
		
		linear_chip_UploadFile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_autoTransitionScroll(vscroll1);
				linear_chip_UploadFile.setChecked(true);
				linear_chip_direct_file_link.setChecked(false);
				linear_chip_email.setChecked(false);
				linear_chip_direct_massage.setChecked(false);
				button_upload_file.setVisibility(View.VISIBLE);
				layout_direct_file_link.setVisibility(View.GONE);
				et_direct_file_link.setText("");
				if (mediaType.equals("image")) {
					textview_upload_file_title.setText("Upload template file");
					textview_upload_file_helper.setText("Maximum file upload size 50mb (Supabase)");
				} else {
					textview_upload_file_title.setText("Upload template file");
					textview_upload_file_helper.setText("Maximum file upload size 50mb (Supabase)");
				}
			}
		});
		
		linear_chip_direct_file_link.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_autoTransitionScroll(vscroll1);
				linear_chip_UploadFile.setChecked(false);
				linear_chip_direct_file_link.setChecked(true);
				linear_chip_email.setChecked(false);
				linear_chip_direct_massage.setChecked(false);
				button_upload_file.setVisibility(View.GONE);
				layout_direct_file_link.setVisibility(View.VISIBLE);
				textview_upload_file_title.setText("How does it work?");
				textview_upload_file_helper.setText("If your supabase hosting storage is full, you can upload the file to another hosting and provide a direct link here!");
				et_direct_file_link.setText("");
			}
		});
		
		linear_chip_email.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_autoTransitionScroll(vscroll1);
				linear_chip_UploadFile.setChecked(false);
				linear_chip_direct_file_link.setChecked(false);
				linear_chip_email.setChecked(true);
				linear_chip_direct_massage.setChecked(false);
				button_upload_file.setVisibility(View.GONE);
				layout_direct_file_link.setVisibility(View.GONE);
				textview_upload_file_title.setText("How does it work?");
				textview_upload_file_helper.setText("This is an Email Collect system — user’ll access the template using the email user provide.");
				et_direct_file_link.setText("");
			}
		});
		
		linear_chip_direct_massage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_autoTransitionScroll(vscroll1);
				linear_chip_UploadFile.setChecked(false);
				linear_chip_direct_file_link.setChecked(false);
				linear_chip_email.setChecked(false);
				linear_chip_direct_massage.setChecked(true);
				button_upload_file.setVisibility(View.GONE);
				layout_direct_file_link.setVisibility(View.GONE);
				textview_upload_file_title.setText("How does it work?");
				textview_upload_file_helper.setText("When a template is purchased, the admin panel can send the download link along with a custom message to the user.");
				et_direct_file_link.setText("");
			}
		});
		
		button_upload_file.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				templateFilePicker.launch("*/*");
			}
		});
		
		textview_clear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_autoTransitionScroll(vscroll1);
				autocomplete_category.setText("");
				textview_clear1.setVisibility(View.GONE);
			}
		});
		
		autocomplete_category.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (!_charSeq.equals("")) {
					_autoTransitionScroll(vscroll1);
					textview_clear1.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview_clear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_autoTransitionScroll(vscroll1);
				autocomplete_item_category.setText("");
				textview_clear2.setVisibility(View.GONE);
			}
		});
		
		autocomplete_item_category.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (!_charSeq.equals("")) {
					_autoTransitionScroll(vscroll1);
					textview_clear2.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		linear_rewarded_ads.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_Interstitial.setChecked(false);
				linear_rewarded_ads.setChecked(true);
				linear_no_ads.setChecked(false);
			}
		});
		
		linear_Interstitial.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_Interstitial.setChecked(true);
				linear_rewarded_ads.setChecked(false);
				linear_no_ads.setChecked(false);
			}
		});
		
		linear_no_ads.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_Interstitial.setChecked(false);
				linear_rewarded_ads.setChecked(false);
				linear_no_ads.setChecked(true);
			}
		});
		
		linear_chip_free.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_chip_free.setChecked(true);
				linear_premium_need.setChecked(false);
				linear_Interstitial.setChecked(false);
				linear_rewarded_ads.setChecked(true);
				linear_no_ads.setChecked(false);
				linear_Interstitial.setEnabled(true);
				linear_rewarded_ads.setEnabled(true);
				linear_no_ads.setEnabled(true);
			}
		});
		
		linear_premium_need.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear_chip_free.setChecked(false);
				linear_premium_need.setChecked(true);
				linear_Interstitial.setChecked(false);
				linear_rewarded_ads.setChecked(false);
				linear_no_ads.setChecked(true);
				linear_Interstitial.setEnabled(false);
				linear_rewarded_ads.setEnabled(false);
				linear_no_ads.setEnabled(false);
			}
		});
		
		button_publish.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_title.getText().toString().isEmpty()) {
					com.google.android.material.snackbar.Snackbar.make(linear_body, "Enter the title of your template!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
					if (edittext_description.getText().toString().isEmpty()) {
						com.google.android.material.snackbar.Snackbar.make(linear_body, "Enter the description of your template!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					} else {
						if (autocomplete_category.getText().toString().isEmpty()) {
							com.google.android.material.snackbar.Snackbar.make(linear_body, "select the category of your template!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
						} else {
							if (autocomplete_item_category.getText().toString().isEmpty()) {
								com.google.android.material.snackbar.Snackbar.make(linear_body, "select the item category of your template!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							} else {
								if (getIntent().hasExtra("key")) {
									if (linear_chip_UploadFile.isChecked()) {
										chip_template_file_type_str = "upload";
									} else {
										if (linear_chip_direct_file_link.isChecked()) {
											chip_template_file_type_str = "direct link";
										} else {
											if (linear_chip_email.isChecked()) {
												chip_template_file_type_str = "collect email";
											} else {
												if (linear_chip_direct_massage.isChecked()) {
													chip_template_file_type_str = "direct massage";
												}
											}
										}
									}
									if (linear_chip_direct_file_link.isChecked()) {
										if (et_direct_file_link.getText().toString().isEmpty()) {
											com.google.android.material.snackbar.Snackbar.make(linear_body, "Please enter direct file download link!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										} else {
											if (mediaType.equals("image")) {
												_templatePublish("image");
											} else {
												_templatePublish("video");
											}
										}
									} else {
										if (mediaType.equals("image")) {
											_templatePublish("image");
										} else {
											_templatePublish("video");
										}
									}
								} else {
									if (mediaType.equals("image")) {
										if (imagePath.isEmpty()) {
											com.google.android.material.snackbar.Snackbar.make(linear_body, "Please upload promo image!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										} else {
											if (linear_chip_UploadFile.isChecked()) {
												if (pickedTemplatePath.isEmpty()) {
													com.google.android.material.snackbar.Snackbar.make(linear_body, "Please upload main template file!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
														@Override
														public void onClick(View _view) {
															 
														}
													}).show();
												} else {
													_templatePublish("image");
													chip_template_file_type_str = "upload";
												}
											} else {
												if (linear_chip_direct_file_link.isChecked()) {
													if (et_direct_file_link.getText().toString().isEmpty()) {
														com.google.android.material.snackbar.Snackbar.make(linear_body, "Please enter direct file download link!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													} else {
														chip_template_file_type_str = "direct link";
														_templatePublish("image");
													}
												} else {
													if (linear_chip_email.isChecked()) {
														chip_template_file_type_str = "collect email";
														_templatePublish("image");
													} else {
														if (linear_chip_direct_massage.isChecked()) {
															chip_template_file_type_str = "direct massage";
															_templatePublish("image");
														}
													}
												}
											}
										}
									} else {
										if (videoPath.isEmpty()) {
											com.google.android.material.snackbar.Snackbar.make(linear_body, "Please upload promo video!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										} else {
											if (imagePath.isEmpty()) {
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Please upload promo image!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											} else {
												if (linear_chip_UploadFile.isChecked()) {
													if (pickedTemplatePath.isEmpty()) {
														com.google.android.material.snackbar.Snackbar.make(linear_body, "Please upload main template file!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													} else {
														_templatePublish("video");
														chip_template_file_type_str = "upload";
													}
												} else {
													if (linear_chip_direct_file_link.isChecked()) {
														if (et_direct_file_link.getText().toString().isEmpty()) {
															com.google.android.material.snackbar.Snackbar.make(linear_body, "Please enter direct file download link!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														} else {
															chip_template_file_type_str = "direct link";
															_templatePublish("video");
														}
													} else {
														if (linear_chip_email.isChecked()) {
															chip_template_file_type_str = "collect email";
															_templatePublish("video");
														} else {
															if (linear_chip_direct_massage.isChecked()) {
																chip_template_file_type_str = "direct massage";
																_templatePublish("video");
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		});
		
		button_delete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FasterM3BottomSheetLoader deleteLoader = new FasterM3BottomSheetLoader(AddTemplateActivity.this);
				deleteLoader.setCancelableOnOutsideClick(false);
				deleteLoader.show("Deleting data.....");
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
				    .url(getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "main key" + "=eq." + getIntent().getStringExtra("key"))
				    .delete()
				    .addHeader("apikey", getString(R.string.database_api_key)) 
				    .addHeader("Content-Type", "application/json")
				    .build();
				
				client.newCall(request).enqueue(new Callback() {
					@Override
					public void onFailure(Call call, IOException e) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								deleteLoader.dismiss();
								com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							}
						});
					}
					@Override
					public void onResponse(Call call, Response response) throws IOException {
						if (response.isSuccessful()) {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (fileUrl.equals("")) {
										deleteLoader.updateMessage("Deleting image....");
										FasterCloudinaryUploader.deleteByPublicId(AddTemplateActivity.this, media3_token, new FasterCloudinaryUploader.UploadCallback() {
											@Override
											public void onSuccess(String msg, String nothing) {
												if (mediaType.equals("video")) {
													deleteLoader.updateMessage("Deleting video file.....");
													FasterCloudinaryUploader.deleteByPublicId(AddTemplateActivity.this, media1_token, new FasterCloudinaryUploader.UploadCallback() {
														@Override
														public void onSuccess(String msg, String nothing) {
															deleteLoader.dismiss();
															backIntent.setClass(getApplicationContext(), TemplateListActivity.class);
															ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(AddTemplateActivity.this, R.anim.fade_in, R.anim.fade_out);
															startActivity(backIntent, backIntentOp.toBundle());
															finish();
														}
														@Override
														public void onFailure(String error) {
															deleteLoader.dismiss();
															com.google.android.material.snackbar.Snackbar.make(linear_body, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													});
												} else {
													deleteLoader.dismiss();
													backIntent.setClass(getApplicationContext(), TemplateListActivity.class);
													ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(AddTemplateActivity.this, R.anim.fade_in, R.anim.fade_out);
													startActivity(backIntent, backIntentOp.toBundle());
													finish();
												}
											}
											@Override
											public void onFailure(String error) {
												deleteLoader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear_body, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										});
									} else {
										deleteLoader.updateMessage("Deleting template file....");
										OkHttpClient client = new OkHttpClient();
										Request request = new Request.Builder()
										    .url(fileUrl.replace("public/", ""))
										    .delete()
										    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
										    .build();
										
										client.newCall(request).enqueue(new Callback() {
											@Override
											public void onFailure(Call call, IOException e) {
												final String errorMessage = e.getMessage();
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														deleteLoader.dismiss();
														com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												});
											}
											@Override
											public void onResponse(Call call, Response response) throws IOException {
												final boolean isSuccessful = response.isSuccessful();
												final String responseBody = response.body().string();
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														if (isSuccessful) {
															deleteLoader.updateMessage("Deleting image....");
															FasterCloudinaryUploader.deleteByPublicId(AddTemplateActivity.this, media3_token, new FasterCloudinaryUploader.UploadCallback() {
																@Override
																public void onSuccess(String msg, String nothing) {
																	if (mediaType.equals("video")) {
																		deleteLoader.updateMessage("Deleting video file.....");
																		FasterCloudinaryUploader.deleteByPublicId(AddTemplateActivity.this, media1_token, new FasterCloudinaryUploader.UploadCallback() {
																			@Override
																			public void onSuccess(String msg, String nothing) {
																				deleteLoader.dismiss();
																				backIntent.setClass(getApplicationContext(), TemplateListActivity.class);
																				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(AddTemplateActivity.this, R.anim.fade_in, R.anim.fade_out);
																				startActivity(backIntent, backIntentOp.toBundle());
																				finish();
																			}
																			@Override
																			public void onFailure(String error) {
																				deleteLoader.dismiss();
																				com.google.android.material.snackbar.Snackbar.make(linear_body, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																					@Override
																					public void onClick(View _view) {
																						 
																					}
																				}).show();
																			}
																		});
																	} else {
																		deleteLoader.dismiss();
																		backIntent.setClass(getApplicationContext(), TemplateListActivity.class);
																		ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(AddTemplateActivity.this, R.anim.fade_in, R.anim.fade_out);
																		startActivity(backIntent, backIntentOp.toBundle());
																		finish();
																	}
																}
																@Override
																public void onFailure(String error) {
																	deleteLoader.dismiss();
																	com.google.android.material.snackbar.Snackbar.make(linear_body, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																		@Override
																		public void onClick(View _view) {
																			 
																		}
																	}).show();
																}
															});
														} else {
															deleteLoader.dismiss();
															com.google.android.material.snackbar.Snackbar.make(linear_body, "Template file delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
														}
													}
												});
											}
										});
									}
									 }
							});
						}
						else {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									deleteLoader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear_body, "Delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								}
							});
						}
					}
				});
			}
		});
		
		_databaseRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_setDataRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				// Start: "setup"
				setDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				setDataMap = setDataListMap.get((int)0);
				//End: "setup"
				if (setDataMap.containsKey("title")) {
					edittext_title.setText(setDataMap.get("title").toString());
				}
				if (setDataMap.containsKey("description")) {
					edittext_description.setText(setDataMap.get("description").toString());
				}
				if (setDataMap.containsKey("category")) {
					autocomplete_category.setText(setDataMap.get("category").toString());
				}
				if (setDataMap.containsKey("ad type")) {
					if (setDataMap.get("ad type").toString().equals("no ad")) {
						linear_no_ads.setChecked(true);
					} else {
						if (setDataMap.get("ad type").toString().equals("interstitial")) {
							linear_Interstitial.setChecked(true);
						} else {
							if (setDataMap.get("ad type").toString().equals("rewarded")) {
								linear_rewarded_ads.setChecked(true);
							} else {
								linear_rewarded_ads.setChecked(true);
							}
						}
					}
				}
				if (setDataMap.containsKey("price")) {
					if (setDataMap.get("price").toString().equals("premium")) {
						linear_premium_need.setChecked(true);
						linear_premium_need.performClick();
					} else {
						if (setDataMap.get("price").toString().equals("free")) {
							linear_chip_free.setChecked(true);
						}
					}
				}
				if (setDataMap.containsKey("template file type")) {
					if (setDataMap.get("template file type").toString().equals("upload")) {
						linear_chip_UploadFile.setChecked(true);
						linear_chip_UploadFile.performClick();
					} else {
						if (setDataMap.get("template file type").toString().equals("direct link")) {
							linear_chip_direct_file_link.setChecked(true);
							linear_chip_direct_file_link.performClick();
						} else {
							if (setDataMap.get("template file type").toString().equals("collect email")) {
								linear_chip_email.setChecked(true);
								linear_chip_email.performClick();
							} else {
								if (setDataMap.get("template file type").toString().equals("direct massage")) {
									linear_chip_direct_massage.setChecked(true);
									linear_chip_direct_massage.performClick();
								}
							}
						}
					}
				}
				if (setDataMap.containsKey("media type")) {
					if (setDataMap.get("media type").toString().equals("image")) {
						linear_promo.setVisibility(View.GONE);
						imageUrl = setDataMap.get("image").toString();
						media3_token = setDataMap.get("image delete token").toString();
						mediaType = "image";
						textinputlayout_duration.setVisibility(View.GONE);
					} else {
						if (setDataMap.get("media type").toString().equals("video")) {
							linear_promo.setVisibility(View.GONE);
							button_promo.setText("Change");
							videoUrl = setDataMap.get("video").toString();
							media1_token = setDataMap.get("video delete token").toString();
							mediaType = "video";
							imageUrl = setDataMap.get("image").toString();
							media3_token = setDataMap.get("image delete token").toString();
						}
					}
				}
				if (setDataMap.containsKey("template type")) {
					if (setDataMap.get("template type").toString().equals("landscape")) {
						linear_portrait.setVisibility(View.GONE);
						linear_Landscape.setVisibility(View.VISIBLE);
						Glide.with(getApplicationContext()).load(Uri.parse(setDataMap.get("image").toString())).into(imageviewLandscape);
						templateType = "landscape";
					} else {
						if (setDataMap.get("template type").toString().equals("portrait")) {
							linear_portrait.setVisibility(View.VISIBLE);
							linear_Landscape.setVisibility(View.GONE);
							Glide.with(getApplicationContext()).load(Uri.parse(setDataMap.get("image").toString())).into(imageviewPortrait);
							templateType = "portrait";
						}
					}
				}
				button_publish.setText("Update");
				if (setDataMap.containsKey("direct download link")) {
					et_direct_file_link.setText(setDataMap.get("direct download link").toString());
				}
				if (setDataMap.containsKey("template file")) {
					fileUrl = setDataMap.get("template file").toString();
					button_upload_file.setText("Change");
				}
				if (setDataMap.containsKey("item category")) {
					autocomplete_item_category.setText(setDataMap.get("item category").toString());
				}
				if (setDataMap.containsKey("duration")) {
					edittext_duration.setText(setDataMap.get("duration").toString());
				}
				loader.dismiss();
				linear_body.setVisibility(View.VISIBLE);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (getIntent().hasExtra("key")) {
			getDatarq = new HashMap<>(); 
			getDatarq.put("apikey", getString(R.string.database_api_key));
			setDataRq.setHeaders(getDatarq);
			setDataRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "templates" + "?" + "main key" + "=eq." + getIntent().getStringExtra("key") + "&", "B", _setDataRq_request_listener);
			autocomplete_category.setInputType(InputType.TYPE_NULL);
			String[] type = new String[] {
				    "Canva",
				    "Adobe Photoshop",
				    "CapCut",
				    "Adobe Premiere Pro",
				    "Pixellab",
				    "Figma",
				    "Lightroom",
				    "Picsart",
				    "VN Video Editor",
				    "KineMaster",
				    "InShot",
				    "After Effects",
				    "Filmora",
				    "Snapseed",
				    "Photopea",
				    "CorelDRAW",
				    "Blender",
				    "DaVinci Resolve",
				    "GIMP",
				    "InDesign",
				    "Illustrator",
				    "Sony Vegas Pro",
				    "Sketch",
				    "Affinity Designer",
				    "Alight Motion",
				    "PixArt Editor",
				    "YouCut",
				    "VideoShow",
				    "Movavi",
				    "VSCO"
			};
			        ArrayAdapter<String> adapter =
			                new ArrayAdapter<>(
			                        this,
			                        R.layout.spinner_cus,
			                        R.id.textview1,
			                        type);
			        autocomplete_category.setAdapter(adapter);
			autocomplete_item_category.setInputType(InputType.TYPE_NULL);
			String[] type2 = new String[] {
				    "Most Popular",
				    "Editor Choice",
				    "Landscape Template",
				    "Gaming Landscape Template",
				    "Business Template",
				    "Social Media Template",
				    "Educational Template",
				    "Video Template",
				    "Marketing Template",
			};
			        ArrayAdapter<String> adapter2 =
			                new ArrayAdapter<>(
			                        this,
			                        R.layout.spinner_cus,
			                        R.id.textview1,
			                        type2);
			        autocomplete_item_category.setAdapter(adapter2);
			linear_chip_UploadFile.setText("Upload file");
			linear_chip_direct_file_link.setText("Direct file download link");
			linear_chip_email.setText("Collect email");
			linear_chip_direct_massage.setText("Manually with admin");
			linear_premium_need.setText("Premium need");
			linear_chip_free.setText("Free template");
			linear_rewarded_ads.setText("Rewarded ad");
			linear_Interstitial.setText("Interstitial ad");
			linear_no_ads.setText("No ad");
			button_delete.setVisibility(View.VISIBLE);
			loader = new FasterM3BottomSheetLoader(AddTemplateActivity.this);
			loader.setCancelableOnOutsideClick(false);
			loader.show("Setting up datas...");
			linear_body.setVisibility(View.GONE);
			button_Portrait.setVisibility(View.GONE);
			button_Landscape.setVisibility(View.GONE);
		} else {
			// Start: "Important dialog"
			MaterialAlertDialogBuilder templateDialog = new MaterialAlertDialogBuilder(AddTemplateActivity.this);
			templateDialog.setTitle("Setup the Template");
			View templateDialogDesign = LayoutInflater.from(AddTemplateActivity.this).inflate(R.layout.template_type, null);
			templateDialog.setView(templateDialogDesign);
			final RadioButton radiobutton1 = templateDialogDesign.findViewById(R.id.radiobutton1);
			final RadioButton radiobutton2 = templateDialogDesign.findViewById(R.id.radiobutton2);
			final RadioButton radiobutton3 = templateDialogDesign.findViewById(R.id.radiobutton3);
			final RadioButton radiobutton4 = templateDialogDesign.findViewById(R.id.radiobutton4);
			linear_body.setVisibility(View.GONE);
			radiobutton1.setChecked(true);
			radiobutton3.setChecked(true);
			radiobutton1.setOnClickListener(v -> {
				radiobutton1.setChecked(true);
				radiobutton2.setChecked(false);
			});
			radiobutton2.setOnClickListener(v -> {
				radiobutton1.setChecked(false);
				radiobutton2.setChecked(true);
			});
			radiobutton3.setOnClickListener(v -> {
				radiobutton3.setChecked(true);
				radiobutton4.setChecked(false);
			});
			radiobutton4.setOnClickListener(v -> {
				radiobutton3.setChecked(false);
				radiobutton4.setChecked(true);
			});
			templateDialog.setPositiveButton("Done", new DialogInterface.OnClickListener() {
				    @Override
				    public void onClick(DialogInterface _dialog, int _which) {
					        _autoTransitionScroll(vscroll1);
					if (radiobutton3.isChecked()) {
						linear_promo.setVisibility(View.GONE);
						textinputlayout_duration.setVisibility(View.GONE);
						mediaType = "image";
						if (radiobutton1.isChecked()) {
							linear_Landscape.setVisibility(View.VISIBLE);
							linear_portrait.setVisibility(View.GONE);
							templateType = "landscape";
						} else {
							if (radiobutton2.isChecked()) {
								linear_Landscape.setVisibility(View.GONE);
								linear_portrait.setVisibility(View.VISIBLE);
								templateType = "portrait";
							}
						}
					} else {
						if (radiobutton4.isChecked()) {
							linear_promo.setVisibility(View.VISIBLE);
							textinputlayout_duration.setVisibility(View.VISIBLE);
							mediaType = "video";
							if (radiobutton1.isChecked()) {
								linear_Landscape.setVisibility(View.VISIBLE);
								linear_portrait.setVisibility(View.GONE);
								templateType = "landscape";
							} else {
								if (radiobutton2.isChecked()) {
									linear_Landscape.setVisibility(View.GONE);
									linear_portrait.setVisibility(View.VISIBLE);
									templateType = "portrait";
								}
							}
						}
					}
					linear_body.setVisibility(View.VISIBLE);
					    }
			});
			templateDialog.setCancelable(false);
			templateDialog.create().show();
			//End: "Important dialog"
			// Start: "Others ui setup"
			linear_chip_UploadFile.setChecked(true);
			linear_chip_free.setChecked(true);
			linear_rewarded_ads.setChecked(true);
			layout_direct_file_link.setVisibility(View.GONE);
			imageviewLandscape.setVisibility(View.GONE);
			button_delete.setVisibility(View.GONE);
			imageviewPortrait.setVisibility(View.GONE);
			linear_chip_UploadFile.setText("Upload file");
			linear_chip_direct_file_link.setText("Direct file download link");
			linear_chip_email.setText("Collect email");
			linear_chip_direct_massage.setText("Manually with admin");
			linear_premium_need.setText("Premium need");
			linear_chip_free.setText("Free template");
			linear_rewarded_ads.setText("Rewarded ad");
			linear_Interstitial.setText("Interstitial ad");
			linear_no_ads.setText("No ad");
			autocomplete_category.setInputType(InputType.TYPE_NULL);
			String[] type = new String[] {
				    "Canva",
				    "Adobe Photoshop",
				    "CapCut",
				    "Adobe Premiere Pro",
				    "Pixellab",
				    "Figma",
				    "Lightroom",
				    "Picsart",
				    "VN Video Editor",
				    "KineMaster",
				    "InShot",
				    "After Effects",
				    "Filmora",
				    "Snapseed",
				    "Photopea",
				    "CorelDRAW",
				    "Blender",
				    "DaVinci Resolve",
				    "GIMP",
				    "InDesign",
				    "Illustrator",
				    "Sony Vegas Pro",
				    "Sketch",
				    "Affinity Designer",
				    "Alight Motion",
				    "PixArt Editor",
				    "YouCut",
				    "VideoShow",
				    "Movavi",
				    "VSCO"
			};
			        ArrayAdapter<String> adapter =
			                new ArrayAdapter<>(
			                        this,
			                        R.layout.spinner_cus,
			                        R.id.textview1,
			                        type);
			        autocomplete_category.setAdapter(adapter);
			autocomplete_item_category.setInputType(InputType.TYPE_NULL);
			String[] type2 = new String[] {
				    "Most Popular",
				    "Editor Choice",
				    "Landscape Template",
				    "Gaming Landscape Template",
				    "Business Template",
				    "Social Media Template",
				    "Educational Template",
				    "Video Template",
				    "Marketing Template",
			};
			        ArrayAdapter<String> adapter2 =
			                new ArrayAdapter<>(
			                        this,
			                        R.layout.spinner_cus,
			                        R.id.textview1,
			                        type2);
			        autocomplete_item_category.setAdapter(adapter2);
			if (mediaType.equals("image")) {
				textview_upload_file_title.setText("Upload image file");
				textview_upload_file_helper.setText("Maximum file upload size 50mb (Supabase)");
			} else {
				textview_upload_file_title.setText("Upload video file");
				textview_upload_file_helper.setText("Maximum file upload size 50mb (Supabase)");
			}
			//End: "Others ui setup"
		}
		// Start: "Image, video & template file picker"
		//End: "Image, video & template file picker"
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				backIntent.setClass(getApplicationContext(), TemplateListActivity.class);
				ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(AddTemplateActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(backIntent, backIntentOp.toBundle());
				finish();
			}
		});
		// Start: "Create private loader"
		uploader = new FasterM3BottomSheetLoader(AddTemplateActivity.this);
		uploader.setCancelableOnOutsideClick(false);
		//End: "Create private loader"
		// Start: "forceEnglishLocale"
		//End: "forceEnglishLocale"
	}
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _autoTransitionScroll(final View _scroll) {
		android.transition.TransitionManager.beginDelayedTransition((ScrollView)_scroll, new android.transition.AutoTransition());
	}
	
	
	public String _saveUriToFile(final String _uri) {
		    try {  
			        ContentResolver contentResolver = getContentResolver();  
			        Uri uri = Uri.parse(_uri);
			        InputStream inputStream = contentResolver.openInputStream(uri);  
			        File file = new File(getExternalFilesDir(null), "picked_image.jpg");  
			        FileOutputStream outputStream = new FileOutputStream(file);  
			
			        byte[] buffer = new byte[1024];  
			        int length;  
			        while ((length = inputStream.read(buffer)) > 0) {  
				            outputStream.write(buffer, 0, length);  
				        }  
			
			        outputStream.close();  
			        inputStream.close();  
			
			        return file.getAbsolutePath();
			    } catch (Exception e) {  
			        e.printStackTrace();  
			        return null;  
			    }
	}
	
	
	public String _saveVideoUriToFile(final String _uri) {
		try {
			        ContentResolver contentResolver = getContentResolver();
			        Uri uri = Uri.parse(_uri);
			        InputStream inputStream = contentResolver.openInputStream(uri);
			        File file = new File(getExternalFilesDir(null), "picked_video.mp4");
			        FileOutputStream outputStream = new FileOutputStream(file);
			
			        byte[] buffer = new byte[1024];
			        int length;
			        while ((length = inputStream.read(buffer)) > 0) {
				            outputStream.write(buffer, 0, length);
				        }
			
			        outputStream.close();
			        inputStream.close();
			
			        return file.getAbsolutePath();
			    } catch (Exception e) {
			        e.printStackTrace();
			        return null;
			    }
	}
	
	
	public boolean _isTemplateFile(final String _filePath) {
		String[] allowedExtensions = {
			        ".psd", ".capcut", ".aep", ".prproj", ".cpt", ".fig", ".lrtemplate", ".pix", ".blend",
			        ".drp", ".xd", ".indd", ".ai", ".veg", ".sketch", ".afdesign", ".xml", ".cep", ".zip", 
			        ".proj", ".pea", ".cdr", ".template", ".motion", ".amproj", ".movavi", ".vsco"
			    };
		
		    String path = _filePath.toLowerCase();
		    for (String ext : allowedExtensions) {
			        if (path.endsWith(ext)) return true;
			    }
		    return false;
	}
	
	
	public void _templatePublish(final String _MediaType) {
		final String[] fileUrlWrapper = new String[1];
		fileUrlWrapper[0] = getString(R.string.database_url) + "/storage/v1/object/public/" + "fritemp" + "/" + media2_file_name;
		if (linear_rewarded_ads.isChecked()) {
			chip_ad_type_str = "rewarded";
		} else {
			if (linear_Interstitial.isChecked()) {
				chip_ad_type_str = "interstitial";
			} else {
				if (linear_no_ads.isChecked()) {
					chip_ad_type_str = "no ad";
				}
			}
		}
		if (linear_premium_need.isChecked()) {
			price_str = "premium";
		} else {
			if (linear_chip_free.isChecked()) {
				price_str = "free";
			}
		}
		uploader.show("Uploading media1......");
		if (_MediaType.equals("image")) {
			if (getIntent().hasExtra("key")) {
				if (chip_template_file_type_str.equals("upload")) {
					if (pickedTemplatePath.equals("")) {
						uploader.updateMessage("Publishing.....");
						_update_database();
					} else {
						if (fileUrl.equals("")) {
							uploader.updateMessage("Uploading template file.....");
							media2_file_name = "MeDiA2".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(00000010), (int)(100000000)))));
							OkHttpClient client = new OkHttpClient();
							
							File file = new File(pickedTemplatePath);
							RequestBody fileBody = RequestBody.create(MediaType.parse("application/zip"), file);
							
							Request request = new Request.Builder()
							    .url(getString(R.string.database_url) + "/storage/v1/object/" + "fritemp" + "/" + media2_file_name)
							    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
							    .post(fileBody)
							    .build();
							
							client.newCall(request).enqueue(new Callback() {
								@Override
								public void onFailure(Call call, IOException e) {
									final String errorMessage = e.getMessage();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											uploader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									});
								}
								@Override
								public void onResponse(Call call, Response response) throws IOException {
									final boolean isSuccessful = response.isSuccessful();
									final String responseBody = response.body().string();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (isSuccessful) {
												textview_file_url.setText(getString(R.string.database_url) + "/storage/v1/object/public/" + "fritemp" + "/" + media2_file_name);
												uploader.updateMessage("Publishing.....");
												_update_database();
											} else {
												uploader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Media 2 upload failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										}
									});
								}
							});
						} else {
							uploader.updateMessage("Deleting template file......");
							OkHttpClient client = new OkHttpClient();
							Request request = new Request.Builder()
							    .url(fileUrl.replace("public/", ""))
							    .delete()
							    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
							    .build();
							
							client.newCall(request).enqueue(new Callback() {
								@Override
								public void onFailure(Call call, IOException e) {
									final String errorMessage = e.getMessage();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											uploader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									});
								}
								@Override
								public void onResponse(Call call, Response response) throws IOException {
									final boolean isSuccessful = response.isSuccessful();
									final String responseBody = response.body().string();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (isSuccessful) {
												uploader.updateMessage("Uploading template file.....");
												media2_file_name = "MeDiA2".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(00000010), (int)(100000000)))));
												OkHttpClient client = new OkHttpClient();
												
												File file = new File(pickedTemplatePath);
												RequestBody fileBody = RequestBody.create(MediaType.parse("application/zip"), file);
												
												Request request = new Request.Builder()
												    .url(getString(R.string.database_url) + "/storage/v1/object/" + "fritemp" + "/" + media2_file_name)
												    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
												    .post(fileBody)
												    .build();
												
												client.newCall(request).enqueue(new Callback() {
													@Override
													public void onFailure(Call call, IOException e) {
														final String errorMessage = e.getMessage();
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																uploader.dismiss();
																com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																	@Override
																	public void onClick(View _view) {
																		 
																	}
																}).show();
															}
														});
													}
													@Override
													public void onResponse(Call call, Response response) throws IOException {
														final boolean isSuccessful = response.isSuccessful();
														final String responseBody = response.body().string();
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																if (isSuccessful) {
																	textview_file_url.setText(getString(R.string.database_url) + "/storage/v1/object/public/" + "fritemp" + "/" + media2_file_name);
																	uploader.updateMessage("Publishing.....");
																	_update_database();
																} else {
																	uploader.dismiss();
																	com.google.android.material.snackbar.Snackbar.make(linear_body, "Media 2 upload failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																		@Override
																		public void onClick(View _view) {
																			 
																		}
																	}).show();
																}
															}
														});
													}
												});
											} else {
												uploader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Template file delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										}
									});
								}
							});
						}
					}
				} else {
					uploader.updateMessage("Publishing.....");
					_update_database();
				}
			} else {
				FasterCloudinaryUploader.uploadMedia(AddTemplateActivity.this, imagePath, new FasterCloudinaryUploader.UploadCallback() {
					@Override
					public void onSuccess(String fileUrl, String
					publicId) {
						media3_token = publicId;
						media2_file_name = "MeDiA2".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(00000010), (int)(100000000)))));
						imageUrl = fileUrl;
						if (chip_template_file_type_str.equals("upload")) {
							uploader.updateMessage("Uploading media2....");
							OkHttpClient client = new OkHttpClient();
							
							File file = new File(pickedTemplatePath);
							RequestBody fileBody = RequestBody.create(MediaType.parse("application/zip"), file);
							
							Request request = new Request.Builder()
							    .url(getString(R.string.database_url) + "/storage/v1/object/" + "fritemp" + "/" + media2_file_name)
							    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
							    .post(fileBody)
							    .build();
							
							client.newCall(request).enqueue(new Callback() {
								@Override
								public void onFailure(Call call, IOException e) {
									final String errorMessage = e.getMessage();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											uploader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									});
								}
								@Override
								public void onResponse(Call call, Response response) throws IOException {
									final boolean isSuccessful = response.isSuccessful();
									final String responseBody = response.body().string();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (isSuccessful) {
												textview_file_url.setText(getString(R.string.database_url) + "/storage/v1/object/public/" + "fritemp" + "/" + media2_file_name);
												uploader.updateMessage("Publishing.....");
												_database();
											} else {
												uploader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Media 2 upload failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										}
									});
								}
							});
						} else {
							uploader.updateMessage("Publishing.....");
							_database();
						}
					}
					@Override
					public void onFailure(String error) {
						uploader.dismiss();
						com.google.android.material.snackbar.Snackbar.make(linear_body, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					}
				});
			}
		} else {
			if (getIntent().hasExtra("key")) {
				if (chip_template_file_type_str.equals("upload")) {
					if (pickedTemplatePath.equals("")) {
						uploader.updateMessage("Publishing.....");
						_update_database();
					} else {
						if (fileUrl.equals("")) {
							uploader.updateMessage("Uploading template file.....");
							media2_file_name = "MeDiA2".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(00000010), (int)(100000000)))));
							OkHttpClient client = new OkHttpClient();
							
							File file = new File(pickedTemplatePath);
							RequestBody fileBody = RequestBody.create(MediaType.parse("application/zip"), file);
							
							Request request = new Request.Builder()
							    .url(getString(R.string.database_url) + "/storage/v1/object/" + "fritemp" + "/" + media2_file_name)
							    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
							    .post(fileBody)
							    .build();
							
							client.newCall(request).enqueue(new Callback() {
								@Override
								public void onFailure(Call call, IOException e) {
									final String errorMessage = e.getMessage();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											uploader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									});
								}
								@Override
								public void onResponse(Call call, Response response) throws IOException {
									final boolean isSuccessful = response.isSuccessful();
									final String responseBody = response.body().string();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (isSuccessful) {
												textview_file_url.setText(getString(R.string.database_url) + "/storage/v1/object/public/" + "fritemp" + "/" + media2_file_name);
												uploader.updateMessage("Publishing.....");
												_update_database();
											} else {
												uploader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Media 2 upload failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										}
									});
								}
							});
						} else {
							uploader.updateMessage("Deleting template file......");
							OkHttpClient client = new OkHttpClient();
							Request request = new Request.Builder()
							    .url(fileUrl.replace("public/", ""))
							    .delete()
							    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
							    .build();
							
							client.newCall(request).enqueue(new Callback() {
								@Override
								public void onFailure(Call call, IOException e) {
									final String errorMessage = e.getMessage();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											uploader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									});
								}
								@Override
								public void onResponse(Call call, Response response) throws IOException {
									final boolean isSuccessful = response.isSuccessful();
									final String responseBody = response.body().string();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (isSuccessful) {
												uploader.updateMessage("Uploading template file.....");
												media2_file_name = "MeDiA2".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(00000010), (int)(100000000)))));
												OkHttpClient client = new OkHttpClient();
												
												File file = new File(pickedTemplatePath);
												RequestBody fileBody = RequestBody.create(MediaType.parse("application/zip"), file);
												
												Request request = new Request.Builder()
												    .url(getString(R.string.database_url) + "/storage/v1/object/" + "fritemp" + "/" + media2_file_name)
												    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
												    .post(fileBody)
												    .build();
												
												client.newCall(request).enqueue(new Callback() {
													@Override
													public void onFailure(Call call, IOException e) {
														final String errorMessage = e.getMessage();
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																uploader.dismiss();
																com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																	@Override
																	public void onClick(View _view) {
																		 
																	}
																}).show();
															}
														});
													}
													@Override
													public void onResponse(Call call, Response response) throws IOException {
														final boolean isSuccessful = response.isSuccessful();
														final String responseBody = response.body().string();
														runOnUiThread(new Runnable() {
															@Override
															public void run() {
																if (isSuccessful) {
																	textview_file_url.setText(getString(R.string.database_url) + "/storage/v1/object/public/" + "fritemp" + "/" + media2_file_name);
																	uploader.updateMessage("Publishing.....");
																	_update_database();
																} else {
																	uploader.dismiss();
																	com.google.android.material.snackbar.Snackbar.make(linear_body, "Media 2 upload failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																		@Override
																		public void onClick(View _view) {
																			 
																		}
																	}).show();
																}
															}
														});
													}
												});
											} else {
												uploader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear_body, "Template file delete failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
											}
										}
									});
								}
							});
						}
					}
				} else {
					uploader.updateMessage("Publishing.....");
					_update_database();
				}
			} else {
				FasterCloudinaryUploader.uploadMedia(AddTemplateActivity.this, videoPath, new FasterCloudinaryUploader.UploadCallback() {
					@Override
					public void onSuccess(String fileUrl, String
					publicId) {
						media1_token = publicId;
						videoUrl = fileUrl;
						uploader.updateMessage("uploading media2....");
						FasterCloudinaryUploader.uploadMedia(AddTemplateActivity.this, imagePath, new FasterCloudinaryUploader.UploadCallback() {
							@Override
							public void onSuccess(String fileUrl, String
							publicId) {
								media3_token = publicId;
								imageUrl = fileUrl;
								media2_file_name = "MeDiA2".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(00000010), (int)(100000000)))));
								uploader.updateMessage("Uploading media3....");
								if (chip_template_file_type_str.equals("upload")) {
									OkHttpClient client = new OkHttpClient();
									
									File file = new File(pickedTemplatePath);
									RequestBody fileBody = RequestBody.create(MediaType.parse("application/zip"), file);
									
									Request request = new Request.Builder()
									    .url(getString(R.string.database_url) + "/storage/v1/object/" + "fritemp" + "/" + media2_file_name)
									    .header("Authorization", "Bearer " + getString(R.string.database_api_key))
									    .post(fileBody)
									    .build();
									
									client.newCall(request).enqueue(new Callback() {
										@Override
										public void onFailure(Call call, IOException e) {
											final String errorMessage = e.getMessage();
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													uploader.dismiss();
													com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
														@Override
														public void onClick(View _view) {
															 
														}
													}).show();
												}
											});
										}
										@Override
										public void onResponse(Call call, Response response) throws IOException {
											final boolean isSuccessful = response.isSuccessful();
											final String responseBody = response.body().string();
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													if (isSuccessful) {
														textview_file_url.setText(getString(R.string.database_url) + "/storage/v1/object/public/" + "fritemp" + "/" + media2_file_name);
														uploader.updateMessage("Publishing.....");
														_database();
													} else {
														uploader.dismiss();
														com.google.android.material.snackbar.Snackbar.make(linear_body, "Media 2 upload failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
															@Override
															public void onClick(View _view) {
																 
															}
														}).show();
													}
												}
											});
										}
									});
								} else {
									uploader.updateMessage("Publishing.....");
									_database();
								}
							}
							@Override
							public void onFailure(String error) {
								uploader.dismiss();
								com.google.android.material.snackbar.Snackbar.make(linear_body, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {
										 
									}
								}).show();
							}
						});
					}
					@Override
					public void onFailure(String error) {
						uploader.dismiss();
						com.google.android.material.snackbar.Snackbar.make(linear_body, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					}
				});
			}
		}
	}
	
	
	public void _database() {
		databaseValueMap = new HashMap<>();
		databaseHeaderMap = new HashMap<>();
		databaseHeaderMap.put("apikey", getString(R.string.database_api_key));
		databaseHeaderMap.put("Content-Type", "application/json");
		databaseValueMap.put("main key", edittext_title.getText().toString().trim().toLowerCase().replace(" ", "_").concat("-".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(000001), (int)(100000)))))));
		databaseValueMap.put("title", edittext_title.getText().toString().trim());
		databaseValueMap.put("description", edittext_description.getText().toString().trim());
		databaseValueMap.put("category", autocomplete_category.getText().toString());
		databaseValueMap.put("direct download link", et_direct_file_link.getText().toString().trim());
		databaseValueMap.put("item category", autocomplete_item_category.getText().toString());
		databaseValueMap.put("ad type", chip_ad_type_str);
		databaseValueMap.put("price", price_str);
		databaseValueMap.put("media type", mediaType);
		databaseValueMap.put("template type", templateType);
		databaseValueMap.put("image", imageUrl);
		databaseValueMap.put("video", videoUrl);
		databaseValueMap.put("template file type", chip_template_file_type_str);
		databaseValueMap.put("template file", textview_file_url.getText().toString());
		databaseValueMap.put("image delete token", media3_token);
		databaseValueMap.put("video delete token", media1_token);
		databaseValueMap.put("gets", "0");
		databaseValueMap.put("duration", edittext_duration.getText().toString());
		databaseRq.setHeaders(databaseHeaderMap); databaseRq.setParams(databaseValueMap, RequestNetworkController.REQUEST_PARAM); databaseRq.startRequestNetwork(RequestNetworkController.POST, getString(R.string.database_url) + "/rest/v1/" + "templates", "", _databaseRq_request_listener);
		uploader.dismiss();
		backIntent.setClass(getApplicationContext(), TemplateListActivity.class);
		ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(AddTemplateActivity.this, R.anim.fade_in, R.anim.fade_out);
		startActivity(backIntent, backIntentOp.toBundle());
		finish();
	}
	
	
	public void _showError() {
		com.google.android.material.snackbar.Snackbar.make(linear_body, "Unsupported file extension!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
			@Override
			public void onClick(View _view) {
				 
			}
		}).show();
	}
	
	
	public String _savePickedFileAndZipIt(final Uri _uri) {
		
		    try {
			        ContentResolver contentResolver = getContentResolver();
			
			        // Get filename and extension
			        String extension = "";
			        String filename = "picked_template";
			
			        String mime = contentResolver.getType(_uri);
			        if (mime != null) {
				            extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
				            if (extension != null) extension = "." + extension;
				        }
			
			        if (extension == null || extension.isEmpty()) {
				            Cursor cursor = contentResolver.query(_uri, null, null, null, null);
				            if (cursor != null && cursor.moveToFirst()) {
					                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
					                if (nameIndex != -1) {
						                    filename = cursor.getString(nameIndex);
						                    extension = filename.substring(filename.lastIndexOf("."));
						                }
					                cursor.close();
					            }
				        }
			
			        File originalFile = new File(getExternalFilesDir(null), "picked_template" + extension);
			
			        InputStream inputStream = contentResolver.openInputStream(_uri);
			        FileOutputStream outputStream = new FileOutputStream(originalFile);
			        byte[] buffer = new byte[1024];
			        int length;
			        while ((length = inputStream.read(buffer)) > 0) {
				            outputStream.write(buffer, 0, length);
				        }
			        inputStream.close();
			        outputStream.close();
			
			        if (!_isTemplateFile(originalFile.getAbsolutePath())) {
				            originalFile.delete();
				            return null;
				        }
			
			        File zipFile = new File(getExternalFilesDir(null), "template_compressed.zip");
			        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile));
			        FileInputStream fis = new FileInputStream(originalFile);
			        ZipEntry zipEntry = new ZipEntry(originalFile.getName());
			        zos.putNextEntry(zipEntry);
			        while ((length = fis.read(buffer)) > 0) {
				            zos.write(buffer, 0, length);
				        }
			        zos.closeEntry();
			        fis.close();
			        zos.close();
			
			        originalFile.delete();
			
			        return zipFile.getAbsolutePath();
			    } catch (Exception e) {
			        e.printStackTrace();
			        return null;
			    }
	}
	
	
	public void _update_database() {
		if (!textview_file_url.getText().toString().equals("")) {
			fileUrl = textview_file_url.getText().toString();
		}
		updateMap = new Gson().fromJson("{" + "\"" + "title" + "\":\"" + edittext_title.getText().toString() + "\",\"" + "description" + "\":\"" + edittext_description.getText().toString() + "\",\"" + "category" + "\":\"" + autocomplete_category.getText().toString() + "\",\"" + "ad type" + "\":\"" + chip_ad_type_str + "\",\"" + "price" + "\":\"" + price_str + "\",\"" + "template file type" + "\":\"" + chip_template_file_type_str + "\",\"" + "template file" + "\":\"" + fileUrl + "\",\"" + "direct download link" + "\":\"" + et_direct_file_link.getText().toString() + "\",\"" + "item category" + "\":\"" + autocomplete_item_category.getText().toString() + "\",\"" + "duration" + "\":\"" + edittext_duration.getText().toString() + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
		OkHttpClient client = new OkHttpClient();
		Request request = new Request.Builder()
		    .url(getString(R.string.database_url) + "/rest/v1/" + "templates" + "?main key=eq." + getIntent().getStringExtra("key"))
		    .addHeader("apikey", getString(R.string.database_api_key))
		    .patch(RequestBody.create(
		        MediaType.parse("application/json; charset=utf-8"),
		        new Gson().toJson(updateMap)
		    ))
		    .build();
		client.newCall(request).enqueue(new Callback() {
			    @Override
			    public void onFailure(Call call, IOException e) {
				        final String errorMessage = e.getMessage();
				        new Handler(Looper.getMainLooper()).post(new Runnable() {
					            @Override
					            public void run() {
						                uploader.dismiss();
						com.google.android.material.snackbar.Snackbar.make(linear_body, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
						            }
					        });
				    }
			    @Override
			    public void onResponse(Call call, Response response) throws IOException {
				        final String responseMessage = response.body().string(); 
				        if (response.isSuccessful()) {
					            new Handler(Looper.getMainLooper()).post(new Runnable() {
						                @Override
						                public void run() {
							                    uploader.dismiss();
							backIntent.setClass(getApplicationContext(), TemplateListActivity.class);
							ActivityOptions backIntentOp = ActivityOptions.makeCustomAnimation(AddTemplateActivity.this, R.anim.fade_in, R.anim.fade_out);
							startActivity(backIntent, backIntentOp.toBundle());
							finish();
							                }
						            });
					        } else {
					            new Handler(Looper.getMainLooper()).post(new Runnable() {
						                @Override
						                public void run() {
							                    uploader.dismiss();
							com.google.android.material.snackbar.Snackbar.make(linear_body, "Update failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
							                }
						            });
					        }
				    }
		});
	}
	
}