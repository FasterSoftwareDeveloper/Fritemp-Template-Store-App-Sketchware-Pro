package yt.fasterpanelv2.faster;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.transition.*;
import com.bumptech.glide.*;
import com.bumptech.glide.Glide;
import com.google.android.material.*;
import com.google.android.material.button.*;
import com.google.android.material.card.*;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import okhttp3.*;
import org.json.*;
import com.bumptech.glide.Glide;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.activity.result.ActivityResultCallback;

public class DeveloperOptionActivity extends AppCompatActivity {

private FasterM3BottomSheetLoader uploader;
ActivityResultLauncher<String> launcher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri) {
                    if (uri == null) {
                    } else {
                        imagePath = _saveUriToFile(uri.toString());
                        Glide.with(getApplicationContext()).load(uri).into(imageviewLandscape);
                        imageviewLandscape.setVisibility(View.VISIBLE);
                    }
                }
            });
	
	private String imagePath = "";
	private HashMap<String, Object> headerMap = new HashMap<>();
	private HashMap<String, Object> valueMap = new HashMap<>();
	private String imageUrl = "";
	private String imageDeleteToken = "";
	private String key = "";
	private HashMap<String, Object> updateDataListMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> getDataListMap = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private MaterialCardView linear_Landscape;
	private LinearLayout linear3;
	private ListView listview1;
	private RelativeLayout relativelayout2;
	private ImageView imageviewLandscape;
	private MaterialButton button_Landscape;
	private TextInputLayout layout_title;
	private TextInputLayout textinputlayout_des;
	private TextInputLayout textinputlayout_link;
	private Button button_send;
	private EditText edittext_title;
	private EditText edittext_des;
	private EditText edittext_link;
	
	private Intent intent = new Intent();
	private RequestNetwork adddatarq;
	private RequestNetwork.RequestListener _adddatarq_request_listener;
	private RequestNetwork getDataRq;
	private RequestNetwork.RequestListener _getDataRq_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.developer_option);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear2 = findViewById(R.id.linear2);
		linear_Landscape = findViewById(R.id.linear_Landscape);
		linear3 = findViewById(R.id.linear3);
		listview1 = findViewById(R.id.listview1);
		relativelayout2 = findViewById(R.id.relativelayout2);
		imageviewLandscape = findViewById(R.id.imageviewLandscape);
		button_Landscape = findViewById(R.id.button_Landscape);
		layout_title = findViewById(R.id.layout_title);
		textinputlayout_des = findViewById(R.id.textinputlayout_des);
		textinputlayout_link = findViewById(R.id.textinputlayout_link);
		button_send = findViewById(R.id.button_send);
		edittext_title = findViewById(R.id.edittext_title);
		edittext_des = findViewById(R.id.edittext_des);
		edittext_link = findViewById(R.id.edittext_link);
		adddatarq = new RequestNetwork(this);
		getDataRq = new RequestNetwork(this);
		
		button_Landscape.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				launcher.launch("image/*");
			}
		});
		
		button_send.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (imageUrl.equals("")) {
					if (imagePath.isEmpty()) {
						com.google.android.material.snackbar.Snackbar.make(linear2, "Please select a image!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					} else {
						if (edittext_title.getText().toString().isEmpty() && (edittext_des.getText().toString().isEmpty() && edittext_link.getText().toString().isEmpty())) {
							com.google.android.material.snackbar.Snackbar.make(linear2, "Fill all things!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {
									 
								}
							}).show();
						} else {
							uploader.show("Uploading image....");
							FasterCloudinaryUploader.uploadMedia(DeveloperOptionActivity.this, imagePath, new FasterCloudinaryUploader.UploadCallback() {
								@Override
								public void onSuccess(String fileUrl, String
								publicId) {
									uploader.updateMessage("Saving data...");
									imageUrl = fileUrl;
									imageDeleteToken = publicId;
									valueMap = new HashMap<>();
									headerMap = new HashMap<>();
									headerMap.put("apikey", getString(R.string.database_api_key));
									headerMap.put("Content-Type", "application/json");
									valueMap.put("title", edittext_title.getText().toString());
									valueMap.put("description", edittext_des.getText().toString());
									valueMap.put("link", edittext_link.getText().toString());
									valueMap.put("image url", imageUrl);
									valueMap.put("image delete token", imageDeleteToken);
									valueMap.put("key", "sLiDeR".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(0000001), (int)(1000000))))));
									adddatarq.setHeaders(headerMap); adddatarq.setParams(valueMap, RequestNetworkController.REQUEST_PARAM); adddatarq.startRequestNetwork(RequestNetworkController.POST, getString(R.string.database_url) + "/rest/v1/" + "slider", "", _adddatarq_request_listener);
								}
								@Override
								public void onFailure(String error) {
									uploader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear2, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								}
							});
						}
					}
				} else {
					if (edittext_title.getText().toString().isEmpty() && (edittext_des.getText().toString().isEmpty() && edittext_link.getText().toString().isEmpty())) {
						com.google.android.material.snackbar.Snackbar.make(linear2, "Fill all things!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
							@Override
							public void onClick(View _view) {
								 
							}
						}).show();
					} else {
						if (imagePath.isEmpty()) {
							uploader.updateMessage("Saving data...");
							updateDataListMap = new Gson().fromJson("{" + "\"" + "title" + "\":\"" + edittext_title.getText().toString() + "\",\"" + "description" + "\":\"" + edittext_des.getText().toString() + "\",\"" + "link" + "\":\"" + edittext_link.getText().toString() + "\",\"" + "image url" + "\":\"" + imageUrl + "\",\"" + "image delete token" + "\":\"" + imageDeleteToken + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
							OkHttpClient client = new OkHttpClient();
							Request request = new Request.Builder()
							    .url(getString(R.string.database_url) + "/rest/v1/" + "slider" + "?key=eq." + key)
							    .addHeader("apikey", getString(R.string.database_api_key))
							    .patch(RequestBody.create(
							        MediaType.parse("application/json; charset=utf-8"),
							        new Gson().toJson(updateDataListMap)
							    ))
							    .build();
							client.newCall(request).enqueue(new Callback() {
								    @Override
								    public void onFailure(Call call, IOException e) {
									        final String errorMessage = e.getMessage();
									        new Handler(Looper.getMainLooper()).post(new Runnable() {
										            @Override
										            public void run() {
											                uploader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear2, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
											            }
										        });
									    }
								    @Override
								    public void onResponse(Call call, Response response) throws IOException {
									        final String responseMessage = response.body().string(); 
									        if (response.isSuccessful()) {
										            new Handler(Looper.getMainLooper()).post(new Runnable() {
											                @Override
											                public void run() {
												                    uploader.dismiss();
												intent.setClass(getApplicationContext(), LoginActivity.class);
												ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(DeveloperOptionActivity.this, R.anim.fade_in, R.anim.fade_out);
												startActivity(intent, intentOp.toBundle());
												finish();
												                }
											            });
										        } else {
										            new Handler(Looper.getMainLooper()).post(new Runnable() {
											                @Override
											                public void run() {
												                    uploader.dismiss();
												com.google.android.material.snackbar.Snackbar.make(linear2, "Data update failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
													@Override
													public void onClick(View _view) {
														 
													}
												}).show();
												                }
											            });
										        }
									    }
							});
						} else {
							uploader.show("Deleting old image....");
							FasterCloudinaryUploader.deleteByPublicId(DeveloperOptionActivity.this, imageDeleteToken, new FasterCloudinaryUploader.UploadCallback() {
								@Override
								public void onSuccess(String msg, String nothing) {
									uploader.updateMessage("Uploading new image...");
									FasterCloudinaryUploader.uploadMedia(DeveloperOptionActivity.this, imagePath, new FasterCloudinaryUploader.UploadCallback() {
										@Override
										public void onSuccess(String fileUrl, String
										publicId) {
											uploader.updateMessage("Saving data...");
											imageUrl = fileUrl;
											imageDeleteToken = publicId;
											updateDataListMap = new Gson().fromJson("{" + "\"" + "title" + "\":\"" + edittext_title.getText().toString() + "\",\"" + "description" + "\":\"" + edittext_des.getText().toString() + "\",\"" + "link" + "\":\"" + edittext_link.getText().toString() + "\",\"" + "image url" + "\":\"" + imageUrl + "\",\"" + "image delete token" + "\":\"" + imageDeleteToken + "\"}", new TypeToken<HashMap<String, Object>>(){}.getType());
											OkHttpClient client = new OkHttpClient();
											Request request = new Request.Builder()
											    .url(getString(R.string.database_url) + "/rest/v1/" + "slider" + "?key=eq." + key)
											    .addHeader("apikey", getString(R.string.database_api_key))
											    .patch(RequestBody.create(
											        MediaType.parse("application/json; charset=utf-8"),
											        new Gson().toJson(updateDataListMap)
											    ))
											    .build();
											client.newCall(request).enqueue(new Callback() {
												    @Override
												    public void onFailure(Call call, IOException e) {
													        final String errorMessage = e.getMessage();
													        new Handler(Looper.getMainLooper()).post(new Runnable() {
														            @Override
														            public void run() {
															                uploader.dismiss();
															com.google.android.material.snackbar.Snackbar.make(linear2, "No internet connection!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																@Override
																public void onClick(View _view) {
																	 
																}
															}).show();
															            }
														        });
													    }
												    @Override
												    public void onResponse(Call call, Response response) throws IOException {
													        final String responseMessage = response.body().string(); 
													        if (response.isSuccessful()) {
														            new Handler(Looper.getMainLooper()).post(new Runnable() {
															                @Override
															                public void run() {
																                    uploader.dismiss();
																intent.setClass(getApplicationContext(), LoginActivity.class);
																ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(DeveloperOptionActivity.this, R.anim.fade_in, R.anim.fade_out);
																startActivity(intent, intentOp.toBundle());
																finish();
																                }
															            });
														        } else {
														            new Handler(Looper.getMainLooper()).post(new Runnable() {
															                @Override
															                public void run() {
																                    uploader.dismiss();
																com.google.android.material.snackbar.Snackbar.make(linear2, "Data update failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
																	@Override
																	public void onClick(View _view) {
																		 
																	}
																}).show();
																                }
															            });
														        }
													    }
											});
										}
										@Override
										public void onFailure(String error) {
											uploader.dismiss();
											com.google.android.material.snackbar.Snackbar.make(linear2, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
												@Override
												public void onClick(View _view) {
													 
												}
											}).show();
										}
									});
								}
								@Override
								public void onFailure(String error) {
									uploader.dismiss();
									com.google.android.material.snackbar.Snackbar.make(linear2, error, com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
										@Override
										public void onClick(View _view) {
											 
										}
									}).show();
								}
							});
						}
					}
				}
			}
		});
		
		_adddatarq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.equals("[]")) {
						uploader.dismiss();
					com.google.android.material.snackbar.Snackbar.make(linear2, "Data save failed!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				} else {
						uploader.dismiss();
					intent.setClass(getApplicationContext(), MainActivity.class);
					ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(DeveloperOptionActivity.this, R.anim.fade_in, R.anim.fade_out);
					startActivity(intent, intentOp.toBundle());
					finish();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_getDataRq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				getDataListMap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				listview1.setAdapter(new Listview1Adapter(getDataListMap));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
			@Override
			public void handleOnBackPressed() {
				intent.setClass(getApplicationContext(), MainActivity.class);
				ActivityOptions intentOp = ActivityOptions.makeCustomAnimation(DeveloperOptionActivity.this, R.anim.fade_in, R.anim.fade_out);
				startActivity(intent, intentOp.toBundle());
				finish();
			}
		});
		// Start: "create private loader"
		uploader = new FasterM3BottomSheetLoader(DeveloperOptionActivity.this);
		uploader.setCancelableOnOutsideClick(false);
		//End: "create private loader"
		getDataRq.startRequestNetwork(RequestNetworkController.GET, getString(R.string.database_url) + "/rest/v1/" + "slider" + "?apikey=" + getString(R.string.database_api_key), "", _getDataRq_request_listener);
	}
	
	public String _saveUriToFile(final String _uri) {
		    try {  
			        ContentResolver contentResolver = getContentResolver();  
			        Uri uri = Uri.parse(_uri);
			        InputStream inputStream = contentResolver.openInputStream(uri);  
			        File file = new File(getExternalFilesDir(null), "picked_image.jpg");  
			        FileOutputStream outputStream = new FileOutputStream(file);  
			
			        byte[] buffer = new byte[1024];  
			        int length;  
			        while ((length = inputStream.read(buffer)) > 0) {  
				            outputStream.write(buffer, 0, length);  
				        }  
			
			        outputStream.close();  
			        inputStream.close();  
			
			        return file.getAbsolutePath();
			    } catch (Exception e) {  
			        e.printStackTrace();  
			        return null;  
			    }
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.slider_cus, null);
			}
			
			final com.google.android.material.card.MaterialCardView carousel = _view.findViewById(R.id.carousel);
			final RelativeLayout relativelayout1 = _view.findViewById(R.id.relativelayout1);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			if (_data.get((int)_position).containsKey("image url")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image url").toString())).into(imageview3);
			}
			if (_data.get((int)_position).containsKey("title")) {
				textview1.setText(_data.get((int)_position).get("title").toString());
			}
			if (_data.get((int)_position).containsKey("description")) {
				textview2.setText(_data.get((int)_position).get("description").toString());
			}
			carousel.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (_data.get((int)_position).containsKey("image url")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image url").toString())).into(imageviewLandscape);
						imageviewLandscape.setVisibility(View.VISIBLE);
						imageUrl = _data.get((int)_position).get("image url").toString();
						imageDeleteToken = _data.get((int)_position).get("image delete token").toString();
					}
					if (_data.get((int)_position).containsKey("title")) {
						edittext_title.setText(_data.get((int)_position).get("title").toString());
					}
					if (_data.get((int)_position).containsKey("description")) {
						edittext_des.setText(_data.get((int)_position).get("description").toString());
					}
					if (_data.get((int)_position).containsKey("link")) {
						edittext_link.setText(_data.get((int)_position).get("link").toString());
					}
					if (_data.get((int)_position).containsKey("key")) {
						key = _data.get((int)_position).get("key").toString();
					}
				}
			});
			
			return _view;
		}
	}
}